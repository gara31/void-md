import React, { useState } from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet, ActivityIndicator } from "react-native";

function formatTime(ts) {
  return new Date(ts).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

function AudioBubble({ msg, isUser }) {
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [snd, setSnd] = useState(null);

  async function toggle() {
    if (!msg.media) return;
    const { Audio } = await import("expo-av");
    if (playing && snd) { await snd.pauseAsync(); setPlaying(false); return; }
    setLoading(true);
    try {
      if (snd) {
        await snd.playAsync();
      } else {
        const { sound } = await Audio.Sound.createAsync({ uri: msg.media });
        setSnd(sound);
        sound.setOnPlaybackStatusUpdate(s => { if (s.didJustFinish) setPlaying(false); });
        await sound.playAsync();
      }
      setPlaying(true);
    } catch (e) { console.warn(e); }
    finally { setLoading(false); }
  }

  return (
    <View style={s.audioRow}>
      <TouchableOpacity onPress={toggle} style={s.audioBtn} disabled={loading}>
        {loading
          ? <ActivityIndicator size="small" color={isUser ? "#0a0a0f" : "#00ff9d"} />
          : <Text style={[s.audioIcon, isUser && s.audioIconUser]}>{playing ? "⏸" : "▶"}</Text>
        }
      </TouchableOpacity>
      <View style={s.wave}>
        {[...Array(12)].map((_, i) => (
          <View key={i} style={[s.bar, isUser ? s.barUser : s.barBot, { height: 6 + Math.sin(i * 0.8) * 6 + 4 }]} />
        ))}
      </View>
      <Text style={[s.audioLbl, isUser && s.audioLblUser]}>{msg.ptt ? "Voice" : "Audio"}</Text>
    </View>
  );
}

export default function MessageBubble({ msg }) {
  const isUser = msg.role === "user";
  const [expanded, setExpanded] = useState(false);

  return (
    <View style={[s.row, isUser ? s.rowUser : s.rowBot]}>
      {!isUser && <View style={s.avatar}><Text style={s.avatarTxt}>V</Text></View>}
      <View style={[s.bubble, isUser ? s.bubbleUser : s.bubbleBot, expanded && s.bubbleWide]}>

        {(!msg.type || msg.type === "text") && (
          <Text style={[s.txt, isUser && s.txtUser]}>{msg.text || ""}</Text>
        )}

        {msg.type === "image" && msg.media && (
          <TouchableOpacity onPress={() => setExpanded(e => !e)}>
            <Image source={{ uri: msg.media }} style={expanded ? s.imgBig : s.imgSmall} resizeMode="cover" />
            {msg.caption && <Text style={[s.caption, isUser && s.captionUser]}>{msg.caption}</Text>}
          </TouchableOpacity>
        )}

        {msg.type === "video" && (
          <View style={s.row2}>
            <Text style={{ fontSize: 22 }}>🎬</Text>
            <Text style={[s.txt, isUser && s.txtUser, { marginLeft: 8 }]}>{msg.caption || "Video"}</Text>
          </View>
        )}

        {msg.type === "audio" && <AudioBubble msg={msg} isUser={isUser} />}

        {msg.type === "sticker" && msg.media && (
          <Image source={{ uri: msg.media }} style={s.sticker} resizeMode="contain" />
        )}

        {msg.type === "document" && (
          <View style={s.row2}>
            <Text style={{ fontSize: 22 }}>📄</Text>
            <Text style={[s.txt, isUser && s.txtUser, { flex: 1, marginLeft: 8 }]}>{msg.fileName || "Dokumen"}</Text>
          </View>
        )}

        <Text style={[s.time, isUser && s.timeUser]}>
          {formatTime(msg.time || Date.now())}{isUser ? " ✓✓" : ""}
        </Text>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  row     : { flexDirection: "row", marginVertical: 3, paddingHorizontal: 12, alignItems: "flex-end" },
  rowUser : { justifyContent: "flex-end" },
  rowBot  : { justifyContent: "flex-start" },
  row2    : { flexDirection: "row", alignItems: "center", paddingVertical: 4 },
  avatar  : { width: 28, height: 28, borderRadius: 14, backgroundColor: "#1a1a2e", alignItems: "center", justifyContent: "center", marginRight: 6 },
  avatarTxt: { color: "#00ff9d", fontSize: 13, fontWeight: "800" },
  bubble   : { maxWidth: "78%", borderRadius: 16, paddingHorizontal: 12, paddingTop: 8, paddingBottom: 6 },
  bubbleWide: { maxWidth: "90%" },
  bubbleUser: { backgroundColor: "#00c97a", borderBottomRightRadius: 4 },
  bubbleBot : { backgroundColor: "#151522", borderBottomLeftRadius: 4, borderWidth: 1, borderColor: "#1e1e30" },
  txt      : { color: "#e8e8e8", fontSize: 15, lineHeight: 21 },
  txtUser  : { color: "#0a0a0f" },
  caption  : { color: "#ccc", fontSize: 13, marginTop: 4 },
  captionUser: { color: "#0a0a0f" },
  imgSmall : { width: 200, height: 200, borderRadius: 10 },
  imgBig   : { width: 280, height: 280, borderRadius: 10 },
  sticker  : { width: 120, height: 120 },
  audioRow : { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 4 },
  audioBtn : { width: 36, height: 36, borderRadius: 18, backgroundColor: "#00ff9d22", alignItems: "center", justifyContent: "center" },
  audioIcon: { fontSize: 16, color: "#00ff9d" },
  audioIconUser: { color: "#0a0a0f" },
  wave     : { flexDirection: "row", alignItems: "center", gap: 2, height: 28 },
  bar      : { width: 3, borderRadius: 2 },
  barBot   : { backgroundColor: "#00ff9d66" },
  barUser  : { backgroundColor: "#0a0a0f66" },
  audioLbl : { color: "#888", fontSize: 11 },
  audioLblUser: { color: "#0a0a0f99" },
  time     : { color: "#666", fontSize: 10, textAlign: "right", marginTop: 4 },
  timeUser : { color: "#0a0a0f88" },
});
