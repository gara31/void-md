import { useEffect, useRef, useCallback } from "react";
import { makeWsUrl } from "./config";

export function useWebSocket(cfg, onMessage) {
  const wsRef          = useRef(null);
  const reconnectTimer = useRef(null);
  const onMessageRef   = useRef(onMessage);
  onMessageRef.current = onMessage;

  const connect = useCallback(() => {
    if (!cfg?.serverIP) return;
    try {
      const ws = new WebSocket(makeWsUrl(cfg));
      wsRef.current = ws;
      ws.onopen    = () => clearTimeout(reconnectTimer.current);
      ws.onmessage = (e) => {
        try { onMessageRef.current?.(JSON.parse(e.data)); } catch {}
      };
      ws.onclose = () => {
        reconnectTimer.current = setTimeout(connect, 5000);
      };
      ws.onerror = () => ws.close();
    } catch {
      reconnectTimer.current = setTimeout(connect, 5000);
    }
  }, [cfg?.serverIP, cfg?.serverPort, cfg?.apiToken]);

  useEffect(() => {
    connect();
    return () => {
      clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  }, [connect]);
}
