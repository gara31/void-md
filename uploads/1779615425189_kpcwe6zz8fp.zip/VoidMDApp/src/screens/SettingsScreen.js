import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Alert, ActivityIndicator } from "react-native";
import { saveConfig, makeBaseUrl } from "../config";

export default function SettingsScreen({ cfg, onSave, onBack }) {
  const [ip,    setIp]    = useState(cfg.serverIP);
  const [port,  setPort]  = useState(cfg.serverPort);
  const [token, setToken] = useState(cfg.apiToken);
  const [busy,  setBusy]  = useState(false);

  async function handleTest() {
    setBusy(true);
    try {
      const res  = await fetch(`${makeBaseUrl({ serverIP: ip, serverPort: port })}/api/status`, {
        headers: { "x-api-key": token },
        signal : AbortSignal.timeout(5000),
      });
      const data = await res.json();
      Alert.alert("✅ Terhubung!", `Bot: ${data.botName || "?"}\nPhone: +${data.botPhone || "?"}\nUptime: ${Math.round((data.uptime||0)/60)} menit`);
    } catch (e) {
      Alert.alert("❌ Gagal", `Tidak bisa konek.\n${e.message}`);
    } finally { setBusy(false); }
  }

  async function handleSave() {
    const newCfg = { ...cfg, serverIP: ip.trim(), serverPort: port.trim(), apiToken: token.trim() };
    await saveConfig(newCfg);
    onSave(newCfg);
    onBack();
  }

  return (
    <ScrollView style={s.wrap} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
      <View style={s.header}>
        <TouchableOpacity onPress={onBack} style={s.back}>
          <Text style={s.backTxt}>←</Text>
        </TouchableOpacity>
        <Text style={s.title}>Pengaturan Koneksi</Text>
      </View>
      <Text style={s.desc}>Ubah IP, port, dan token tanpa rebuild APK.</Text>

      <Text style={s.lbl}>IP Server</Text>
      <TextInput style={s.inp} value={ip} onChangeText={setIp} placeholder="38.45.65.8" placeholderTextColor="#555" autoCapitalize="none" />

      <Text style={s.lbl}>Port</Text>
      <TextInput style={s.inp} value={port} onChangeText={setPort} placeholder="2006" placeholderTextColor="#555" keyboardType="numeric" />

      <Text style={s.lbl}>API Token</Text>
      <TextInput style={s.inp} value={token} onChangeText={setToken} placeholder="voidmd-secret" placeholderTextColor="#555" autoCapitalize="none" />

      <View style={s.preview}>
        <Text style={s.prevLbl}>URL aktif:</Text>
        <Text style={s.prevUrl}>http://{ip}:{port}/api/</Text>
      </View>

      <TouchableOpacity style={s.testBtn} onPress={handleTest} disabled={busy}>
        {busy ? <ActivityIndicator color="#00ff9d" /> : <Text style={s.testTxt}>🔌 Test Koneksi</Text>}
      </TouchableOpacity>

      <TouchableOpacity style={s.saveBtn} onPress={handleSave}>
        <Text style={s.saveTxt}>💾 Simpan & Kembali</Text>
      </TouchableOpacity>

      <Text style={s.sid}>Session: {cfg.sessionId}</Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  wrap   : { flex: 1, backgroundColor: "#0a0a0f" },
  content: { padding: 20, paddingBottom: 40 },
  header : { flexDirection: "row", alignItems: "center", marginBottom: 20, marginTop: 8 },
  back   : { marginRight: 12, padding: 4 },
  backTxt: { color: "#00ff9d", fontSize: 22, fontWeight: "bold" },
  title  : { color: "#fff", fontSize: 20, fontWeight: "700" },
  desc   : { color: "#888", fontSize: 13, marginBottom: 28, lineHeight: 19 },
  lbl    : { color: "#aaa", fontSize: 12, fontWeight: "600", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.8 },
  inp    : { backgroundColor: "#151520", borderWidth: 1, borderColor: "#2a2a3a", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, color: "#fff", fontSize: 15, marginBottom: 18 },
  preview: { backgroundColor: "#0d0d1a", borderRadius: 8, padding: 12, marginBottom: 24, borderWidth: 1, borderColor: "#1e1e30" },
  prevLbl: { color: "#555", fontSize: 11, marginBottom: 4 },
  prevUrl: { color: "#00ff9d", fontSize: 13 },
  testBtn: { borderWidth: 1, borderColor: "#00ff9d", borderRadius: 10, paddingVertical: 13, alignItems: "center", marginBottom: 12 },
  testTxt: { color: "#00ff9d", fontSize: 15, fontWeight: "600" },
  saveBtn: { backgroundColor: "#00ff9d", borderRadius: 10, paddingVertical: 13, alignItems: "center", marginBottom: 24 },
  saveTxt: { color: "#0a0a0f", fontSize: 15, fontWeight: "700" },
  sid    : { color: "#333", fontSize: 11, textAlign: "center" },
});
