import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View, Text, FlatList, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform,
  ActivityIndicator, StatusBar,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import MessageBubble from "../components/MessageBubble";
import { sendMessage, fetchStatus, fetchHistory } from "../api";
import { useWebSocket } from "../useWebSocket";

const QUICK = [".menu", ".help", ".ping", ".status", ".profile"];

export default function ChatScreen({ cfg, onOpenSettings }) {
  const [messages, setMessages]   = useState([]);
  const [input, setInput]         = useState("");
  const [sending, setSending]     = useState(false);
  const [botStatus, setBotStatus] = useState(null);
  const [error, setError]         = useState(null);
  const listRef                   = useRef(null);

  useEffect(() => {
    let alive = true;
    async function check() {
      try {
        const d = await fetchStatus(cfg);
        if (alive) { setBotStatus(d); setError(null); }
      } catch (e) {
        if (alive) { setBotStatus(null); setError("Tidak bisa terhubung. Cek Settings."); }
      }
    }
    check();
    const t = setInterval(check, 30000);
    return () => { alive = false; clearInterval(t); };
  }, [cfg]);

  useEffect(() => {
    fetchHistory(cfg, 50)
      .then(d => { if (d.messages?.length) setMessages(d.messages); })
      .catch(() => {});
  }, [cfg]);

  const handleWs = useCallback((data) => {
    if (data.type === "bot_reply" && data.sessionId === cfg.sessionId) {
      setMessages(prev => prev.find(m => m.id === data.data.id) ? prev : [...prev, data.data]);
    }
  }, [cfg.sessionId]);

  useWebSocket(cfg, handleWs);

  useEffect(() => {
    if (messages.length) setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  }, [messages.length]);

  async function handleSend() {
    const text = input.trim();
    if (!text || sending) return;
    const userMsg = { id: `u_${Date.now()}`, role: "user", type: "text", text, time: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setSending(true);
    setError(null);
    try {
      const result = await sendMessage(cfg, text);
      if (result.replies?.length) {
        setMessages(prev => {
          const ids = new Set(prev.map(m => m.id));
          return [...prev, ...result.replies.filter(r => !ids.has(r.id))];
        });
      }
    } catch (e) {
      setError(`Gagal: ${e.message}`);
      setMessages(prev => [...prev, { id: `err_${Date.now()}`, role: "bot", type: "text", text: `⚠️ ${e.message}`, time: Date.now() }]);
    } finally {
      setSending(false);
    }
  }

  const connected = botStatus?.connected;

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0f" />

      {/* Header */}
      <View style={s.header}>
        <View style={s.hLeft}>
          <View style={[s.dot, connected ? s.dotG : s.dotR]} />
          <View>
            <Text style={s.hTitle}>{botStatus?.botName || "Void-MD Bot"}</Text>
            <Text style={s.hSub}>{connected ? `+${botStatus?.botPhone}  •  Online` : error || "Menghubungkan..."}</Text>
          </View>
        </View>
        <TouchableOpacity onPress={onOpenSettings} style={s.settBtn}>
          <Text style={s.settIco}>⚙</Text>
        </TouchableOpacity>
      </View>

      {/* Quick commands */}
      <View style={s.quickBar}>
        {QUICK.map(cmd => (
          <TouchableOpacity key={cmd} style={s.chip} onPress={() => setInput(cmd)}>
            <Text style={s.chipTxt}>{cmd}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={item => item.id || String(item.time)}
          renderItem={({ item }) => <MessageBubble msg={item} />}
          contentContainerStyle={s.list}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
          ListEmptyComponent={
            <View style={s.empty}>
              <Text style={{ fontSize: 48 }}>🤖</Text>
              <Text style={s.emptyTitle}>Void-MD siap!</Text>
              <Text style={s.emptySub}>Ketik .menu untuk mulai</Text>
            </View>
          }
        />

        {/* Input bar */}
        <View style={s.bar}>
          <TextInput
            style={s.input}
            value={input}
            onChangeText={setInput}
            placeholder="Ketik pesan atau command..."
            placeholderTextColor="#555"
            multiline
            maxLength={1000}
          />
          <TouchableOpacity
            style={[s.sendBtn, (!input.trim() || sending) && s.sendOff]}
            onPress={handleSend}
            disabled={!input.trim() || sending}
          >
            {sending
              ? <ActivityIndicator size="small" color="#0a0a0f" />
              : <Text style={s.sendIco}>➤</Text>
            }
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const G = "#00ff9d";
const s = StyleSheet.create({
  safe   : { flex: 1, backgroundColor: "#0a0a0f" },
  header : { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 12, backgroundColor: "#0d0d18", borderBottomWidth: 1, borderBottomColor: "#1a1a2a" },
  hLeft  : { flexDirection: "row", alignItems: "center", gap: 10 },
  dot    : { width: 10, height: 10, borderRadius: 5 },
  dotG   : { backgroundColor: G },
  dotR   : { backgroundColor: "#ff4444" },
  hTitle : { color: "#fff", fontSize: 16, fontWeight: "700" },
  hSub   : { color: "#666", fontSize: 11, marginTop: 1 },
  settBtn: { padding: 6 },
  settIco: { color: "#666", fontSize: 20 },
  quickBar: { flexDirection: "row", paddingHorizontal: 12, paddingVertical: 8, gap: 8, backgroundColor: "#0a0a0f", borderBottomWidth: 1, borderBottomColor: "#111120" },
  chip   : { backgroundColor: "#151522", borderRadius: 12, paddingHorizontal: 10, paddingVertical: 5, borderWidth: 1, borderColor: "#00ff9d33" },
  chipTxt: { color: G, fontSize: 12, fontWeight: "600" },
  list   : { paddingTop: 12, paddingBottom: 8 },
  empty  : { alignItems: "center", marginTop: 80, gap: 8 },
  emptyTitle: { color: "#fff", fontSize: 18, fontWeight: "700" },
  emptySub  : { color: "#555", fontSize: 13 },
  bar    : { flexDirection: "row", alignItems: "flex-end", paddingHorizontal: 12, paddingVertical: 10, backgroundColor: "#0d0d18", borderTopWidth: 1, borderTopColor: "#1a1a2a", gap: 8 },
  input  : { flex: 1, backgroundColor: "#151522", borderRadius: 22, paddingHorizontal: 16, paddingVertical: 10, color: "#fff", fontSize: 15, maxHeight: 120, borderWidth: 1, borderColor: "#1e1e30" },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: G, alignItems: "center", justifyContent: "center" },
  sendOff: { backgroundColor: "#1a2a1a" },
  sendIco: { color: "#0a0a0f", fontSize: 18, fontWeight: "800" },
});
