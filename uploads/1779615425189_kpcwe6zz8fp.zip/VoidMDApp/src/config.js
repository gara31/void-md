import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "voidmd_config";

export const DEFAULT_CONFIG = {
  serverIP   : "38.45.65.8",
  serverPort : "2006",
  apiToken   : "voidmd-secret",
  sessionId  : "app_user_" + Math.random().toString(36).slice(2, 8),
};

export async function loadConfig() {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
  } catch {}
  return { ...DEFAULT_CONFIG };
}

export async function saveConfig(cfg) {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
  } catch (e) {
    console.warn("saveConfig error:", e);
  }
}

export function makeBaseUrl(cfg) {
  return `http://${cfg.serverIP}:${cfg.serverPort}`;
}

export function makeWsUrl(cfg) {
  return `ws://${cfg.serverIP}:${cfg.serverPort}?token=${cfg.apiToken}`;
}
