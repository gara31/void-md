import { makeBaseUrl } from "./config";

export async function fetchStatus(cfg) {
  const res = await fetch(`${makeBaseUrl(cfg)}/api/status`, {
    headers: { "x-api-key": cfg.apiToken },
  });
  if (!res.ok) throw new Error(`Status ${res.status}`);
  return res.json();
}

export async function sendMessage(cfg, text) {
  const res = await fetch(`${makeBaseUrl(cfg)}/api/chat/send`, {
    method : "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key"   : cfg.apiToken,
    },
    body: JSON.stringify({
      message  : text,
      sessionId: cfg.sessionId,
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

export async function fetchHistory(cfg, limit = 50) {
  const res = await fetch(
    `${makeBaseUrl(cfg)}/api/chat/history?sessionId=${cfg.sessionId}&limit=${limit}`,
    { headers: { "x-api-key": cfg.apiToken } }
  );
  if (!res.ok) throw new Error(`History ${res.status}`);
  return res.json();
}
