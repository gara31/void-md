import React, { useState, useEffect } from "react";
import { View, ActivityIndicator, StyleSheet } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import ChatScreen     from "./src/screens/ChatScreen";
import SettingsScreen from "./src/screens/SettingsScreen";
import { loadConfig } from "./src/config";

export default function App() {
  const [cfg,    setCfg]    = useState(null);
  const [screen, setScreen] = useState("chat");

  useEffect(() => { loadConfig().then(setCfg); }, []);

  if (!cfg) {
    return (
      <View style={s.loading}>
        <ActivityIndicator size="large" color="#00ff9d" />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      {screen === "settings"
        ? <SettingsScreen cfg={cfg} onSave={setCfg} onBack={() => setScreen("chat")} />
        : <ChatScreen     cfg={cfg} onOpenSettings={() => setScreen("settings")} />
      }
    </SafeAreaProvider>
  );
}

const s = StyleSheet.create({
  loading: { flex: 1, backgroundColor: "#0a0a0f", alignItems: "center", justifyContent: "center" },
});
