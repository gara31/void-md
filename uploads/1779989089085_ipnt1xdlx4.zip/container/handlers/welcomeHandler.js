import { WAMessageStubType }        from "gara";
import { getCachedGroupMetadata }   from "./metadataCache.js";
import { groupStore }               from "../db/groupStore.js";
import { createCanvas, loadImage, registerFont } from "canvas";
import { createRequire }            from "module";
import { existsSync }               from "fs";
import path                         from "path";

const require = createRequire(import.meta.url);
registerFont("./fonts/unifont.otf",       { family: "Unifont"      });
registerFont("./fonts/unifont_upper.otf", { family: "UnifontUpper" });
const emojiData = require("emoji-datasource-apple/emoji.json");

const BG_URL      = "https://raw.githubusercontent.com/gara31/void-md/main/uploads/1779081958516_dgaxvjdh88h.jpg";
const FALLBACK_PP = "https://c.termai.cc/i48/GNf3g9b.jpg";
const EMOJI_BASE  = path.dirname(require.resolve("emoji-datasource-apple/package.json"));

const emojiMap = new Map(
  emojiData
    .filter(e => e.has_img_apple)
    .map(e => [e.unified.toLowerCase(), e])
);

function getUnified(char) {
  const pts  = [...char].map(c => c.codePointAt(0).toString(16).padStart(4, "0"));
  const full = pts.join("-");
  return emojiMap.has(full) ? full : emojiMap.has(pts[0]) ? pts[0] : null;
}

const imgCache = new Map();
async function emojiImg(unified) {
  if (imgCache.has(unified)) return imgCache.get(unified);
  const p   = path.join(EMOJI_BASE, "img", "apple", "64", `${unified}.png`);
  const img = existsSync(p) ? await loadImage(p).catch(() => null) : null;
  imgCache.set(unified, img);
  return img;
}

const EMOJI_RE = /(\p{Emoji_Presentation}|\p{Extended_Pictographic})/gu;

function parseParts(text) {
  const parts = [];
  let last = 0, m;
  EMOJI_RE.lastIndex = 0;
  while ((m = EMOJI_RE.exec(text)) !== null) {
    if (m.index > last) parts.push({ t: true,  v: text.slice(last, m.index) });
    parts.push({ t: false, v: m[0] });
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push({ t: true, v: text.slice(last) });
  return parts;
}

function measureFull(ctx, parts, sz) {
  return parts.reduce((w, p) => w + (p.t ? ctx.measureText(p.v).width : sz + 2), 0);
}

async function drawText(ctx, text, x, y, sz = 28) {
  const parts = parseParts(text);
  const align = ctx.textAlign;
  const total = measureFull(ctx, parts, sz);
  let cx = align === "center" ? x - total / 2 : align === "right" ? x - total : x;
  ctx.textAlign = "left";
  for (const p of parts) {
    if (p.t) {
      ctx.fillText(p.v, cx, y);
      cx += ctx.measureText(p.v).width;
    } else {
      const u   = getUnified(p.v);
      const img = u ? await emojiImg(u) : null;
      if (img) { ctx.drawImage(img, cx, y - sz * 0.78, sz, sz); cx += sz + 2; }
      else     { ctx.fillText(p.v, cx, y); cx += ctx.measureText(p.v).width; }
    }
  }
  ctx.textAlign = align;
}

const add = new Set([
  WAMessageStubType.GROUP_PARTICIPANT_ADD,
  WAMessageStubType.GROUP_PARTICIPANT_ADD_REQUEST_JOIN,
  WAMessageStubType.GROUP_PARTICIPANT_INVITE,
  WAMessageStubType.GROUP_PARTICIPANT_LINKED_GROUP_JOIN,
]);

const remove = new Set([
  WAMessageStubType.GROUP_PARTICIPANT_REMOVE,
  WAMessageStubType.GROUP_PARTICIPANT_LEAVE,
]);

function ensureRoundRect(ctx) {
  if (typeof ctx.roundRect === "function") return;
  ctx.roundRect = function (x, y, w, h, r) {
    const R = typeof r === "number" ? { tl: r, tr: r, br: r, bl: r } : r;
    this.beginPath();
    this.moveTo(x + R.tl, y);
    this.lineTo(x + w - R.tr, y);
    this.quadraticCurveTo(x + w, y, x + w, y + R.tr);
    this.lineTo(x + w, y + h - R.br);
    this.quadraticCurveTo(x + w, y + h, x + w - R.br, y + h);
    this.lineTo(x + R.bl, y + h);
    this.quadraticCurveTo(x, y + h, x, y + h - R.bl);
    this.lineTo(x, y + R.tl);
    this.quadraticCurveTo(x, y, x + R.tl, y);
    this.closePath();
    return this;
  };
}

async function fetchAvatar(gara, jid) {
  try {
    const url = await gara.profilePictureUrl(jid, "image");
    const res = await fetch(url);
    if (!res.ok) throw 0;
    return Buffer.from(await res.arrayBuffer());
  } catch {
    return Buffer.from(await (await fetch(FALLBACK_PP)).arrayBuffer());
  }
}

async function buildWelcomeImage({ avatarBuf, displayName, groupName, isLeave }) {
  const W = 900, H = 420;
  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext("2d");
  ensureRoundRect(ctx);

  const C = {
    text    : "#f0eaff",
    sub     : "rgba(200,185,230,0.75)",
    lavender: "#b8a8e8",
    rose    : "#e8909a",
    mint    : "#78d4b8",
  };

  const accent = isLeave ? C.rose : C.mint;

  try {
    const bg    = await loadImage(BG_URL);
    const scale = Math.max(W / bg.width, H / bg.height);
    const dw    = bg.width * scale;
    const dh    = bg.height * scale;
    ctx.drawImage(bg, (W - dw) / 2, (H - dh) / 2, dw, dh);
  } catch {
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0,   "#0e0b1f");
    grad.addColorStop(0.4, "#251640");
    grad.addColorStop(1,   "#3d1530");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);
  }

  const overlay = ctx.createLinearGradient(0, 0, 0, H);
  overlay.addColorStop(0,   "rgba(10,6,28,0.62)");
  overlay.addColorStop(0.5, "rgba(16,10,38,0.55)");
  overlay.addColorStop(1,   "rgba(10,6,28,0.68)");
  ctx.fillStyle = overlay;
  ctx.fillRect(0, 0, W, H);

  const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.1, W / 2, H / 2, H * 0.75);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(10,6,28,0.28)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  const cX = 28, cY = 44, cW = W - 56, cH = H - 60, cR = 36;

  // ── Telinga kucing ──
  const earW = 52, earH = 46, earGap = 34;
  const earLX = cX + earGap;
  const earRX = cX + cW - earGap - earW;
  const earTop = cY - earH + 4;

  function catCardPath(inset = 0) {
    const x = cX + inset, y = cY + inset;
    const w = cW - inset * 2, h = cH - inset * 2;
    const r = Math.max(cR - inset, 8);
    const ex = inset * 0.5;
    ctx.beginPath();
    // Telinga kiri
    ctx.moveTo(earLX + ex, earTop + ex);
    ctx.lineTo(earLX + ex + earW * 0.15, y);
    // Top kiri → telinga kanan
    ctx.lineTo(earRX - ex + earW * 0.15, y);
    // Telinga kanan
    ctx.lineTo(earRX - ex + earW, earTop + ex);
    ctx.lineTo(earRX - ex + earW - earW * 0.15, y);
    // Top kanan → pojok kanan atas
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    // Kanan
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    // Bawah
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    // Kiri
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    // Kembali ke telinga kiri
    ctx.lineTo(earLX + ex + earW * 0.85, y);
    ctx.lineTo(earLX + ex, earTop + ex);
    ctx.closePath();
  }

  // Fill card
  catCardPath(0);
  const cardBg = ctx.createLinearGradient(cX, cY, cX, cY + cH);
  cardBg.addColorStop(0, "rgba(255,255,255,0.08)");
  cardBg.addColorStop(1, "rgba(255,255,255,0.02)");
  ctx.fillStyle = cardBg;
  ctx.fill();

  // Border utama
  catCardPath(0);
  const borderGrad = ctx.createLinearGradient(cX, cY, cX + cW, cY + cH);
  borderGrad.addColorStop(0,   C.lavender + "88");
  borderGrad.addColorStop(0.5, accent + "bb");
  borderGrad.addColorStop(1,   C.lavender + "88");
  ctx.strokeStyle = borderGrad;
  ctx.lineWidth   = 2;
  ctx.shadowBlur  = 16;
  ctx.shadowColor = accent + "66";
  ctx.stroke();
  ctx.shadowBlur  = 0;

  // Inner border tipis
  catCardPath(8);
  ctx.strokeStyle = "rgba(255,255,255,0.07)";
  ctx.lineWidth   = 1;
  ctx.stroke();

  // Isi dalam telinga (warna accent transparan)
  function earPath(lx, top, w, h, inset = 0) {
    ctx.beginPath();
    ctx.moveTo(lx + inset, top + inset);
    ctx.lineTo(lx + inset + w * 0.15, cY + inset);
    ctx.lineTo(lx + inset + w * 0.85, cY + inset);
    ctx.lineTo(lx + inset + w, top + inset);
    ctx.closePath();
  }
  earPath(earLX, earTop, earW, earH);
  ctx.fillStyle   = accent + "33";
  ctx.shadowBlur  = 10;
  ctx.shadowColor = accent + "55";
  ctx.fill();
  ctx.shadowBlur  = 0;
  ctx.strokeStyle = accent + "99";
  ctx.lineWidth   = 1.5;
  ctx.stroke();

  earPath(earRX, earTop, earW, earH);
  ctx.fillStyle   = accent + "33";
  ctx.shadowBlur  = 10;
  ctx.shadowColor = accent + "55";
  ctx.fill();
  ctx.shadowBlur  = 0;
  ctx.strokeStyle = accent + "99";
  ctx.lineWidth   = 1.5;
  ctx.stroke();

  const ppX = 176, ppY = H / 2, ppR = 96;

  const ringG = ctx.createLinearGradient(ppX - ppR, ppY - ppR, ppX + ppR, ppY + ppR);
  ringG.addColorStop(0,   C.lavender);
  ringG.addColorStop(0.5, accent);
  ringG.addColorStop(1,   C.mint);
  ctx.beginPath();
  ctx.arc(ppX, ppY, ppR + 7, 0, Math.PI * 2);
  ctx.strokeStyle = ringG;
  ctx.lineWidth   = 4;
  ctx.shadowBlur  = 30;
  ctx.shadowColor = accent + "99";
  ctx.stroke();
  ctx.shadowBlur  = 0;

  ctx.beginPath();
  ctx.arc(ppX, ppY, ppR + 14, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(255,255,255,0.18)";
  ctx.lineWidth   = 1;
  ctx.stroke();

  ctx.save();
  ctx.beginPath();
  ctx.arc(ppX, ppY, ppR, 0, Math.PI * 2);
  ctx.clip();
  try {
    const pp = await loadImage(avatarBuf);
    ctx.drawImage(pp, ppX - ppR, ppY - ppR, ppR * 2, ppR * 2);
    ctx.fillStyle = "rgba(200,185,230,0.10)";
    ctx.fillRect(ppX - ppR, ppY - ppR, ppR * 2, ppR * 2);
  } catch {
    ctx.fillStyle = "rgba(200,185,230,0.4)";
    ctx.fillRect(ppX - ppR, ppY - ppR, ppR * 2, ppR * 2);
  }
  ctx.restore();

  const shimG = ctx.createLinearGradient(ppX - ppR, ppY - ppR, ppX + ppR, ppY + ppR);
  shimG.addColorStop(0,   "rgba(255,255,255,0.18)");
  shimG.addColorStop(0.5, "rgba(255,255,255,0.04)");
  shimG.addColorStop(1,   "rgba(255,255,255,0.10)");
  ctx.save();
  ctx.beginPath();
  ctx.arc(ppX, ppY, ppR, 0, Math.PI * 2);
  ctx.clip();
  ctx.fillStyle = shimG;
  ctx.fillRect(ppX - ppR, ppY - ppR, ppR * 2, ppR * 2);
  ctx.restore();

  const tX    = ppX + ppR + 48;
  const maxTW = W - tX - 50;

  ctx.font      = "bold 12px monospace, 'Unifont', 'UnifontUpper'";
  ctx.fillStyle = accent;
  ctx.textAlign = "left";
  ctx.shadowBlur  = 10;
  ctx.shadowColor = accent;
  await drawText(ctx, isLeave ? "GOODBYE" : "WELCOME", tX, ppY - 82, 12);
  ctx.shadowBlur  = 0;

  ctx.beginPath();
  ctx.moveTo(tX, ppY - 68);
  ctx.lineTo(tX + 230, ppY - 68);
  ctx.strokeStyle = accent + "44";
  ctx.lineWidth   = 1;
  ctx.stroke();

  ctx.font        = "bold 58px monospace, 'Unifont', 'UnifontUpper'";
  ctx.fillStyle   = C.text;
  ctx.textAlign   = "left";
  ctx.shadowBlur  = 18;
  ctx.shadowColor = "rgba(182,162,220,0.5)";
  const nameStr   = String(displayName || "Unknown");
  const nameParts = parseParts(nameStr);
  let fitted      = nameStr;
  let fittedParts = nameParts;
  while (measureFull(ctx, fittedParts, 54) > maxTW && fitted.length > 4) {
    fitted      = fitted.slice(0, -1);
    fittedParts = parseParts(fitted);
  }
  if (fitted !== nameStr) fitted += "…";
  await drawText(ctx, fitted, tX, ppY - 20, 54);
  ctx.shadowBlur = 0;

  ctx.font      = "22px monospace, 'Unifont', 'UnifontUpper'";
  ctx.fillStyle = C.sub;
  ctx.textAlign = "left";
  await drawText(ctx, isLeave ? "has left the group" : "has joined the group", tX, ppY + 22, 20);

  const gnStr    = String(groupName || "grup");
  ctx.font       = "bold 22px monospace, 'Unifont', 'UnifontUpper'";
  let gnFitted   = gnStr;
  let gnFParts   = parseParts(gnStr);
  while (measureFull(ctx, gnFParts, 20) > maxTW && gnFitted.length > 4) {
    gnFitted = gnFitted.slice(0, -1);
    gnFParts = parseParts(gnFitted);
  }
  if (gnFitted !== gnStr) gnFitted += "…";

  ctx.fillStyle   = accent;
  ctx.shadowBlur  = 12;
  ctx.shadowColor = accent + "88";
  ctx.textAlign   = "left";
  await drawText(ctx, gnFitted, tX, ppY + 68, 20);
  ctx.shadowBlur  = 0;

  const divY    = H - 62;
  const divGrad = ctx.createLinearGradient(cX + 10, 0, cX + cW - 10, 0);
  divGrad.addColorStop(0,   C.lavender + "22");
  divGrad.addColorStop(0.5, accent + "44");
  divGrad.addColorStop(1,   C.lavender + "22");
  ctx.beginPath();
  ctx.roundRect(cX + 10, divY, cW - 20, 1.5, 2);
  ctx.fillStyle = divGrad;
  ctx.fill();

  ctx.font      = "18px monospace, 'Unifont', 'UnifontUpper'";
  ctx.fillStyle = "rgba(160,150,200,0.55)";
  ctx.textAlign = "right";
  await drawText(
    ctx,
    new Date().toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" }),
    cX + cW - 18,
    divY + 22,
    16
  );
  ctx.textAlign = "left";

  return canvas.toBuffer("image/png");
}

function resolveText(template, members, subject) {
  return template
    .replace(/<members>/gi, members)
    .replace(/<subject>/gi, subject);
}

function resolveParticipants(params) {
  return (params ?? []).map(p => {
    if (typeof p === "string") {
      try {
        const parsed = JSON.parse(p);
        const num = parsed?.phoneNumber || parsed?.id || p;
        return String(num).replace(/@.*/, "");
      } catch {
        return p.replace(/@.*/, "");
      }
    }
    if (typeof p === "object" && p !== null) {
      const num = p?.phoneNumber || p?.id || "";
      return String(num).replace(/@.*/, "");
    }
    return String(p).replace(/@.*/, "");
  }).filter(Boolean);
}

function resolveName(gara, number) {
  const jid = number + "@s.whatsapp.net";

  const rpgUser = rpg?.getUser?.(jid);
  if (rpgUser?.name && rpgUser.name !== number) return rpgUser.name;

  const store = gara.store?.contacts ?? gara.contacts ?? {};
  const entry = store[jid];
  if (entry?.notify)       return entry.notify;
  if (entry?.name)         return entry.name;
  if (entry?.verifiedName) return entry.verifiedName;

  return null;
}

export async function handleStubMessage(gara, rawMsg) {
  try {
    const type = rawMsg.messageStubType;
    const jid  = rawMsg.key.remoteJid;

    const isAdd    = add.has(type);
    const isRemove = remove.has(type);
    if (!isAdd && !isRemove) return;

    const data = groupStore.get(jid);
    if (!data.welcome && !data.leave) return;

    const meta = await getCachedGroupMetadata(gara, jid).catch(() => null);
    if (!meta) return;

    const numbers  = resolveParticipants(rawMsg.messageStubParameters);
    if (!numbers.length) return;

    const subject     = meta.subject ?? "grup";
    const mentions    = numbers.map(n => n + "@s.whatsapp.net");
    const members     = numbers.map(n => `@${n}`).join(", ");
    const avatarBuf   = await fetchAvatar(gara, mentions[0]);
    const displayName = resolveName(gara, numbers[0]) ?? rawMsg.pushName ?? numbers[0];

    if (isAdd && data.welcome) {
      const caption = data.wtxt
        ? resolveText(data.wtxt, members, subject)
        : `Hai ${members}!\nSelamat datang di *${subject}* 🎉`;

      const img = await buildWelcomeImage({ avatarBuf, displayName, groupName: subject, isLeave: false });
      await gara.sendMessage(jid, { image: img, caption, mentions });
    }

    if (isRemove && data.leave) {
      const caption = data.ltxt
        ? resolveText(data.ltxt, members, subject)
        : `Sayonara ${members}... 👋`;

      const img = await buildWelcomeImage({ avatarBuf, displayName, groupName: subject, isLeave: true });
      await gara.sendMessage(jid, { image: img, caption, mentions });
    }
  } catch (e) {
    console.error("[welcomeHandler]", e.message);
  }
}
