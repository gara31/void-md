import { getBinaryNodeChild, getBinaryNodeChildren, getContentType } from "gara";
import { lidStore, normJid } from "../db/lidStore.js";
import { getCachedGroupMetadata, invalidateGroupMetadata } from "./metadataCache.js";

export function isLid(jid) {
  return typeof jid === "string" && jid.endsWith("@lid");
}

export function resolveJid(jid) {
  if (!jid) return jid;
  return isLid(jid) ? lidStore.toId(jid) : jid;
}

export function getGroupAdmins(participants) {
  return participants
    .filter(p => p.admin !== null && p.admin !== undefined)
    .map(p => p.jid || p.id || p.lid || "")
    .filter(Boolean);
}

export function isSuperAdmin(participants, jid) {
  const norm = jid.split("@")[0];
  return participants.some(p => {
    const num    = (p.jid || p.id || p.lid || "").split("@")[0];
    const lidNum = (p.lid || "").split("@")[0];
    return (num === norm || lidNum === norm) && p.admin === "superadmin";
  });
}

export function isAdminInList(adminList, jid) {
  const num = jid.split("@")[0];
  return adminList.some(a => a.split("@")[0] === num);
}

const lidFetchCache = new Map();
const lidFetchTtl = 5 * 60 * 1000;

export async function fetchLidParticipants(gara, groupId) {
  try {
    const now    = Date.now();
    const cached = lidFetchCache.get(groupId);
    if (cached && now - cached.ts < lidFetchTtl) return cached.data;

    const group = await getBinaryNodeChild(
      await gara.query({
        tag    : "iq",
        attrs  : { type: "get", xmlns: "w:g2", to: groupId },
        content: [{ tag: "query", attrs: { request: "interactive" } }],
      }),
      "group"
    );

    const participants = getBinaryNodeChildren(group, "participant").map(({ attrs }) => ({
      id   : attrs.phone_number,
      lid  : attrs.lid || attrs.jid,
      admin: attrs.type || null,
    }));

    const toSave = participants.filter(
      p => p.lid && p.id &&
           p.lid.endsWith("@lid") &&
           p.id.endsWith("@s.whatsapp.net")
    );
    if (toSave.length > 0) lidStore.save(toSave);

    lidFetchCache.set(groupId, { data: participants, ts: now });
    return participants;
  } catch (e) {
    console.error("[detector] fetchLidParticipants error:", e.message);
    return null;
  }
}

async function resolveLidToPN(gara, lidJid) {
  try {
    const pn = await gara.signalRepository.lidMapping.getPNForLID(lidJid);
    if (pn) {
      lidStore.save({ lid: lidJid, id: pn });
      return pn;
    }
  } catch {}
  return lidJid;
}

export function detectSender(gara, m) {
  const from      = m.key.remoteJid;
  const isGroup   = from?.endsWith("@g.us");
  const isStatus  = from === "status@broadcast";
  const rawSender = isGroup ? (m.key.participant ?? m.participant ?? from) : from;

  const participantAlt = m.key?.participantAlt;
  const remoteJidAlt   = m.key?.remoteJidAlt;

  if (rawSender && participantAlt) {
    if (isLid(rawSender) && !isLid(participantAlt))
      lidStore.save({ lid: rawSender, id: participantAlt });
    else if (!isLid(rawSender) && isLid(participantAlt))
      lidStore.save({ lid: participantAlt, id: rawSender });
  }

  if (from && remoteJidAlt && !isGroup) {
    if (isLid(from) && !isLid(remoteJidAlt))
      lidStore.save({ lid: from, id: remoteJidAlt });
    else if (!isLid(from) && isLid(remoteJidAlt))
      lidStore.save({ lid: remoteJidAlt, id: from });
  }

  const sender    = resolveJid(rawSender);
  const senderLid = isLid(rawSender) ? rawSender : lidStore.toLid(rawSender);
  const pushName  = m.pushName || null;
  if (pushName && pushName !== ".") lidStore.updateName(rawSender, pushName);

  const fromMe = m.key.fromMe ?? false;
  const botId  = normJid(gara.user?.id ?? "") ?? "";

  if (isLid(rawSender) && sender.endsWith("@lid")) {
    resolveLidToPN(gara, rawSender).catch(() => {});
  }

  return {
    from,
    sender,
    senderLid,
    senderRaw : rawSender,
    wasLid    : isLid(rawSender),
    pushName,
    fromMe,
    isBot     : fromMe,
    isOwner   : global.isOwner ? global.isOwner(sender) : false,
    isSelf    : normJid(sender) === botId,
    isGroup,
    isStatus,
    isPrivate : !isGroup && !isStatus,
  };
}

export async function detectRole(gara, m, groupMeta = null) {
  const { from, sender, senderRaw, isGroup } = detectSender(gara, m);

  let isAdmin    = false;
  let isBotAdmin = false;
  let meta       = groupMeta;

  if (isGroup) {
    try {
      if (!meta) meta = await getCachedGroupMetadata(gara, from);

      const participants = meta.participants;
      const botId        = normJid(gara.user?.id ?? "");
      const botNumber    = botId.split("@")[0];

      let lidParticipants = null;
      if (meta.addressingMode === "lid") {
        lidParticipants = await fetchLidParticipants(gara, from).catch(() => null);
      }

      const effectiveParticipants = lidParticipants ?? participants;
      const adminList = getGroupAdmins(effectiveParticipants);
      const senderNum = sender.split("@")[0];
      const rawNum    = senderRaw.split("@")[0];
      const senderResolved    = lidStore.toId(senderRaw);
      const senderResolvedNum = senderResolved.split("@")[0];

      isAdmin = isAdminInList(adminList, sender) ||
                isAdminInList(adminList, senderRaw) ||
                isAdminInList(adminList, senderResolved) ||
                effectiveParticipants.some(p =>
                  p.admin !== null && p.admin !== undefined &&
                  (
                    (p.jid || "").split("@")[0] === senderNum ||
                    (p.lid || "").split("@")[0] === rawNum ||
                    (p.id  || "").split("@")[0] === senderResolvedNum ||
                    (p.lid || "").split("@")[0] === senderNum
                  )
                );

      isBotAdmin = adminList.some(a => a.split("@")[0] === botNumber) ||
                   effectiveParticipants.some(p =>
                     p.admin !== null && p.admin !== undefined &&
                     ((p.jid || "").split("@")[0] === botNumber ||
                      (p.lid || "").split("@")[0] === botNumber ||
                      (p.id  || "").split("@")[0] === botNumber)
                   );
    } catch (e) {
      console.error("[detectRole] error:", e.message);
    }
  }

  return { isAdmin, isBotAdmin, groupMeta: meta };
}

export async function getFullGroupInfo(gara, groupId) {
  try {
    const meta         = await getCachedGroupMetadata(gara, groupId);
    const participants = meta.participants;
    const botId        = normJid(gara.user?.id ?? "");
    const botNumber    = botId.split("@")[0];

    const adminList  = getGroupAdmins(participants);
    const admins     = participants.filter(p => p.admin !== null && p.admin !== undefined);
    const members    = participants.filter(p => !p.admin);
    const botIsAdmin = adminList.some(a => a.split("@")[0] === botNumber);

    return {
      meta,
      participants,
      admins,
      members,
      adminList,
      botIsAdmin,
      totalCount  : participants.length,
      adminCount  : admins.length,
      memberCount : members.length,
    };
  } catch (e) {
    console.error("[getFullGroupInfo] error:", e.message);
    return null;
  }
}

export function registerLidDetector(gara) {
  gara.ev.on("group-participants.update", async ({ id, participants, action }) => {
    try {
      invalidateGroupMetadata(id);
      lidFetchCache.delete(id);
      const meta = await getCachedGroupMetadata(gara, id).catch(() => null);
      if (!meta || meta.addressingMode !== "lid") return;
      const result = await fetchLidParticipants(gara, id);
      if (result) {
        console.log(
          `\x1b[36m[LidDetector]\x1b[0m` +
          ` Grup \x1b[33m${id.replace("@g.us", "")}\x1b[0m` +
          ` [${action}] — disimpan \x1b[32m${result.length}\x1b[0m mapping`
        );
      }
    } catch (e) {
      console.error("[LidDetector] group-participants.update error:", e.message);
    }
  });

  gara.ev.on("groups.update", async (updates) => {
    for (const update of updates) {
      try {
        invalidateGroupMetadata(update.id);
        lidFetchCache.delete(update.id);
        const meta = await getCachedGroupMetadata(gara, update.id).catch(() => null);
        if (!meta || meta.addressingMode !== "lid") continue;
        await fetchLidParticipants(gara, update.id);
      } catch (e) {
        console.error("[LidDetector] groups.update error:", e.message);
      }
    }
  });

  console.log("\x1b[36m[LidDetector]\x1b[0m \x1b[32mAktif ✓\x1b[0m");
}

export function getMentions(m) {
  const type  = getContentType(m.raw.message);
  if (!type) return [];
  const inner = m.raw.message[type];
  const ctx   = inner?.contextInfo ?? inner?.message?.extendedTextMessage?.contextInfo ?? {};

  const fromQuoted = [
    ...(ctx.quotedMessage?.extendedTextMessage?.text ?? ctx.quotedMessage?.conversation ?? "")
      .matchAll(/@(\d+)/g),
  ]
    .map(r => r[1])
    .filter(n => n.length >= 6 && n.length <= 15)
    .map(n => n + "@s.whatsapp.net");

  if (fromQuoted.length)        return fromQuoted;
  if (ctx.mentionedJid?.length) return ctx.mentionedJid;

  const fromReply = ctx.participantPn ?? ctx.participant;
  if (fromReply) return [fromReply];
  return [];
}

export async function resolveMentions(raw, gara, jid, meta) {
  if (meta?.addressingMode === "lid") await fetchLidParticipants(gara, jid);
  return Promise.all(raw.map(j => (isLid(j) ? resolveJid(j) : j)));
}

export async function toApiJid(jid, meta, gara, groupJid) {
  if (meta?.addressingMode !== "lid") return jid;
  let lid = lidStore.toLid(jid);
  if (lid.endsWith("@lid")) return lid;
  await fetchLidParticipants(gara, groupJid);
  lid = lidStore.toLid(jid);
  if (lid.endsWith("@lid")) return lid;
  throw new Error(`Tidak bisa resolve LID untuk ${jid}.`);
}
