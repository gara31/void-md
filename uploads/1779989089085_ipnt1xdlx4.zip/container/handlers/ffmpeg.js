import ff          from "fluent-ffmpeg";
import { PassThrough } from "stream";
import fs     from "fs";
import os     from "os";
import crypto from "crypto";
import path   from "path";

const tmpdir = os.tmpdir();
const rand   = () => crypto.randomBytes(6).readUIntLE(0, 6).toString(36);

export async function processMedia(inputBuffer, args = [], format = "mp3") {
  return new Promise((resolve, reject) => {
    const inputStream  = new PassThrough();
    const outputStream = new PassThrough();
    const chunks       = [];

    inputStream.end(inputBuffer);

    let command = ff(inputStream);

    if (["png", "jpg", "jpeg", "webp"].includes(format)) {
      command = command.inputFormat("image2pipe");
    }

    if (Array.isArray(args) && args.length > 0) {
      command = command.outputOptions(args);
    }

    if (["png", "jpg", "jpeg", "webp"].includes(format)) {
      command
        .videoCodec("png")
        .format("image2pipe")
        .outputOptions(["-frames:v", "1"]);
    } else if (["mp3", "ogg"].includes(format)) {
      command
        .noVideo()
        .audioCodec("libmp3lame")
        .outputOptions(["-b:a", "128k", "-ar", "44100"]);
    } else if (["mp4", "mov"].includes(format)) {
      command
        .videoCodec("libx264")
        .outputOptions(["-preset", "fast"]);
    } else {
      command.format(format);
    }

    command
      .on("error", reject)
      .on("end", () => resolve(Buffer.concat(chunks)))
      .pipe(outputStream, { end: true });

    outputStream.on("data", (chunk) => chunks.push(chunk));
  });
}

export async function generateWaveform(inputBuffer, bars = 64) {
  return new Promise((resolve, reject) => {
    const inputStream = new PassThrough();
    inputStream.end(inputBuffer);

    const chunks = [];

    ff(inputStream)
      .audioChannels(1)
      .audioFrequency(16000)
      .format("s16le")
      .on("error", reject)
      .on("end", () => {
        const rawData  = Buffer.concat(chunks);
        const samples  = rawData.length / 2;

        const amplitudes = [];
        for (let i = 0; i < samples; i++) {
          const val = rawData.readInt16LE(i * 2);
          amplitudes.push(Math.abs(val) / 32768);
        }

        const blockSize = Math.floor(amplitudes.length / bars);
        const avg       = [];
        for (let i = 0; i < bars; i++) {
          const block = amplitudes.slice(i * blockSize, (i + 1) * blockSize);
          avg.push(block.reduce((a, b) => a + b, 0) / block.length);
        }

        const max        = Math.max(...avg);
        const normalized = avg.map((v) => Math.floor((v / max) * 100));

        const buf = Buffer.from(new Uint8Array(normalized));
        resolve(buf.toString("base64"));
      })
      .pipe()
      .on("data", (chunk) => chunks.push(chunk));
  });
}

export async function convertToOpus(inputBuffer) {
  return new Promise((resolve, reject) => {
    const inStream  = new PassThrough();
    const outStream = new PassThrough();
    const chunks    = [];

    inStream.end(inputBuffer);

    ff(inStream)
      .noVideo()
      .audioCodec("libopus")
      .format("ogg")
      .audioBitrate("48k")
      .audioChannels(1)
      .audioFrequency(48000)
      .outputOptions([
        "-map_metadata", "-1",
        "-application",  "voip",
        "-compression_level", "10",
        "-page_duration", "20000",
      ])
      .on("error", reject)
      .on("end", () => resolve(Buffer.concat(chunks)))
      .pipe(outStream, { end: true });

    outStream.on("data", (chunk) => chunks.push(chunk));
  });
}

export async function toMp3(buffer) {
  const tmpIn  = path.join(tmpdir, `${rand()}.mp4`);
  const tmpOut = path.join(tmpdir, `${rand()}.mp3`);

  fs.writeFileSync(tmpIn, buffer);

  await new Promise((resolve, reject) => {
    ff(tmpIn)
      .noVideo()
      .audioCodec("libmp3lame")
      .outputOptions(["-b:a", "128k", "-ar", "44100"])
      .toFormat("mp3")
      .on("error", reject)
      .on("end", () => resolve(true))
      .save(tmpOut);
  });

  const result = fs.readFileSync(tmpOut);
  fs.unlinkSync(tmpIn);
  fs.unlinkSync(tmpOut);
  return result;
}
