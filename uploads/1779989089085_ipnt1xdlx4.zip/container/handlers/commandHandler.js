import { readdirSync, statSync } from "fs";
import { pathToFileURL }         from "url";
import { join }                  from "path";

const commands = new Map();

async function loadFile(filePath) {
  const url = pathToFileURL(filePath).href + "?t=" + Date.now();
  const mod  = await import(url);
  return Object.values(mod).filter(v => v && typeof v === "object");
}

function getJsFiles(dir) {
  const results = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) {
      results.push(...getJsFiles(full));
    } else if (name.endsWith(".js")) {
      results.push(full);
    }
  }
  return results;
}

export async function loadCommands() {
  const baseDir = join(process.cwd(), "commands");
  const files   = getJsFiles(baseDir);
  let loaded = 0;
  let failed = 0;

  for (const filePath of files) {
    try {
      const exports = await loadFile(filePath);
      for (const cmd of exports) {
        if (!Array.isArray(cmd.cmd) || typeof cmd.run !== "function") continue;

        const normalized = {
          cmd  : cmd.cmd,
          run  : cmd.run.bind(cmd),
          tag  : cmd.tag  || "general",
          desc : cmd.desc || "",
          _raw : cmd,
          _file: filePath,
        };

        for (const name of cmd.cmd) commands.set(name.toLowerCase(), normalized);
        loaded++;
      }
    } catch (err) {
      failed++;
      const shortPath = filePath.replace(process.cwd(), "");
      console.error(`  ❌ Gagal load: ${shortPath}\n     ${err.message}`);
    }
  }

  console.log(`  📦 Total: ${commands.size} alias dari ${loaded} command${failed > 0 ? ` | ⚠️ ${failed} file gagal` : ""}\n`);
}

export async function reloadCommands(targetFile = null) {
  if (targetFile) {
    const baseDir  = join(process.cwd(), "commands");
    const allFiles = getJsFiles(baseDir);
    const filePath = allFiles.find(f => f.endsWith(targetFile));
    if (!filePath) return;

    for (const [name, cmd] of commands) {
      if (cmd._file === filePath) commands.delete(name);
    }

    try {
      const exports = await loadFile(filePath);
      for (const cmd of exports) {
        if (!Array.isArray(cmd.cmd) || typeof cmd.run !== "function") continue;
        const normalized = {
          cmd  : cmd.cmd,
          run  : cmd.run.bind(cmd),
          tag  : cmd.tag  || "general",
          desc : cmd.desc || "",
          _raw : cmd,
          _file: filePath,
        };
        for (const name of cmd.cmd) commands.set(name.toLowerCase(), normalized);
      }
    } catch (err) {
      console.error(`  ❌ Reload gagal: ${targetFile}\n     ${err.message}`);
    }
  } else {
    commands.clear();
    await loadCommands();
  }
}

function getMediaType(m) {
  if (m.isImage)    return "image";
  if (m.isVideo)    return "video";
  if (m.isAudio)    return "audio";
  if (m.isSticker)  return "sticker";
  if (m.isDocument) return "document";
  return null;
}

export async function runCommand(name, m) {
  const cmd = commands.get(name.toLowerCase());
  if (!cmd) return false;

  const raw         = cmd._raw;
  const currentType = getMediaType(m);

  const mentionList = Array.isArray(m.mentionList) ? m.mentionList : [];

  const modelList = Array.isArray(raw.model)
    ? raw.model
    : (typeof raw.model === "string" ? [raw.model] : []);

  const modelMsg = typeof raw.model === "string"
    ? raw.model
    : (modelList.length > 0
        ? `❗Kirim/reply media yang sesuai!\nYang diizinkan: ${modelList.join(", ")}`
        : "❗Kirim/reply media yang sesuai!");

  const checks = [
    { condition: raw.isOwner    && !m.isOwner,                                                              message: typeof raw.isOwner    === "string" ? raw.isOwner    : msg.common.onlyOwner   },
    { condition: raw.isGroup    && !m.isGroup,                                                              message: typeof raw.isGroup    === "string" ? raw.isGroup    : msg.common.onlyGroup    },
    { condition: raw.isPrivate  && m.isGroup,                                                               message: typeof raw.isPrivate  === "string" ? raw.isPrivate  : msg.common.onlyPrivate  },
    { condition: raw.isAdmin    && !m.isAdmin,                                                              message: typeof raw.isAdmin    === "string" ? raw.isAdmin    : msg.common.onlyAdmin    },
    { condition: raw.isBotAdmin && !m.isBotAdmin,                                                           message: typeof raw.isBotAdmin === "string" ? raw.isBotAdmin : msg.common.botNotAdmin  },
    { condition: raw.isQuoted   && !m.quoted,                                                               message: typeof raw.isQuoted   === "string" ? raw.isQuoted   : msg.common.needQuoted   },
    { condition: raw.isMention  && mentionList.length < 1,                                                  message: typeof raw.isMention  === "string" ? raw.isMention  : msg.common.needMention  },
    { condition: raw.isMedia    && !m.isImage && !m.isVideo && !m.isAudio && !m.isSticker && !m.isDocument, message: typeof raw.isMedia    === "string" ? raw.isMedia    : msg.common.needMedia    },
    { condition: raw.isImage    && !m.isImage,                                                              message: typeof raw.isImage    === "string" ? raw.isImage    : msg.common.needImage    },
    { condition: raw.isVideo    && !m.isVideo,                                                              message: typeof raw.isVideo    === "string" ? raw.isVideo    : msg.common.needVideo    },
    { condition: raw.isAudio    && !m.isAudio,                                                              message: typeof raw.isAudio    === "string" ? raw.isAudio    : msg.common.needAudio    },
    { condition: raw.isSticker  && !m.isSticker,                                                            message: typeof raw.isSticker  === "string" ? raw.isSticker  : msg.common.needSticker  },
    { condition: raw.isArgs     && !(m.args && m.args.length > 0 && m.args[0] !== ""),                      message: typeof raw.isArgs     === "string" ? raw.isArgs     : msg.common.needArgs     },
    { condition: Array.isArray(raw.formats) && raw.formats.length > 0 && !raw.formats.some(f => m.q.toLowerCase().includes(f.toLowerCase())), message: `❗url yang dikasih bukan url yang didukung\nurl yang bisa dipakai:\n- ${(raw.formats || []).join("\n- ")}` },
    { condition: modelList.length > 0 && (!currentType || !modelList.includes(currentType)),                message: modelMsg },
  ];

  for (const { condition, message } of checks) {
    if (condition) {
      await m.reply(message);
      return true;
    }
  }

  try {
    await cmd.run(m);
    return true;
  } catch (err) {
    console.error(`❌ Error [${name}]: ${err.message}`);
    await m.reply(msg.common.error(err));
    return false;
  }
}

export function getCommands() { return commands; }

export function getMenuList() {
  const map = new Map();
  for (const cmd of new Set(commands.values())) {
    const tag = cmd.tag || "general";
    if (!map.has(tag)) map.set(tag, []);
    const list = map.get(tag);
    if (!list.find(x => x.cmd === cmd.cmd[0])) {
      list.push({ cmd: cmd.cmd[0], desc: cmd.desc || "" });
    }
  }
  return map;
}
