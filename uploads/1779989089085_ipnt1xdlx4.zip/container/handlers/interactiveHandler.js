import { createRequire } from "module";
import { generateWAMessageFromContent, generateWAMessageContent } from "gara";
const require = createRequire(import.meta.url);

const AKI_ANSWERS = { "1": 0, "2": 1, "3": 2, "4": 3, "5": 4 };
const AKI_VALID   = new Set(["0", "1", "2", "3", "4", "5"]);

function buildAkiText(aki) {
  return (
    `*!-======[ AKINATOR ]======-!*\n\n` +
    `❓ Pertanyaan ${aki.step + 1}:\n*${aki.question}*\n\n` +
    `📊 Progress: ${Math.round(aki.progress)}%\n\n` +
    `*Jawab dengan angka:*\n` +
    `1️⃣ Ya\n2️⃣ Tidak\n3️⃣ Tidak Tahu\n4️⃣ Mungkin\n5️⃣ Mungkin Tidak\n0️⃣ Kembali\n\n` +
    `> Ketik *${prefix}akistop* untuk berhenti`
  );
}

async function uploadImage(gara, url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const buf = Buffer.from(await res.arrayBuffer());
    const generated = await generateWAMessageContent(
      { image: buf, mimetype: "image/jpeg" },
      { upload: gara.waUploadToServer }
    );
    return generated?.imageMessage ?? null;
  } catch {
    return null;
  }
}

async function handleAkinator(m, gameState) {
  const msg = m.body?.trim();
  if (!AKI_VALID.has(msg)) return false;

  const aki = gameState.data?.aki;
  if (!aki) {
    deleteGame(m.jid);
    return true;
  }

  try {
    if (msg === "0") {
      if (aki.step === 0) {
        await m.reply("Tidak bisa kembali, ini pertanyaan pertama!");
        return true;
      }
      await aki.cancelAnswer();
      await m.reply(buildAkiText(aki));
      return true;
    }

    await aki.answer(AKI_ANSWERS[msg]);

    if (aki.isWin) {
      deleteGame(m.jid);

      let header;
      if (aki.sugestion_photo) {
        const imageMessage = await uploadImage(m.gara, aki.sugestion_photo);
        header = imageMessage
          ? { imageMessage, hasMediaAttachment: true }
          : { title: "🧞 Akinator" };
      } else {
        header = { title: "🧞 Akinator" };
      }

      const footerText =
        `- Aku tahu siapa yang kamu pikirkan!\n\n` +
        `- Nama: *${aki.sugestion_name}*\n` +
        `- Deskripsi: ${aki.sugestion_desc || "-"}\n\n` +
        `Mainkan lagi dengan *${prefix}akinator*`;

      const built = generateWAMessageFromContent(
        m.jid,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header,
                body: { text: "" },
                footer: { text: footerText },
                nativeFlowMessage: { buttons: [] },
                contextInfo: {
                  stanzaId: m.raw.key.id,
                  participant: m.raw.key.participant || m.jid,
                  quotedMessage: m.raw.message,
                },
              },
            },
          },
        },
        {
          quoted: m.raw,
          userJid: m.raw.key.participant ?? m.jid,
        }
      );

      await m.gara.relayMessage(m.jid, built.message, { messageId: built.key.id });

    } else {
      gameState.data.step     = aki.step;
      gameState.data.progress = aki.progress;
      gameState.data.question = aki.question;
      await m.reply(buildAkiText(aki));
    }
  } catch (err) {
    console.error("[Akinator answer error]", err.message);
    deleteGame(m.jid);
    await m.reply(`Terjadi error pada Akinator, game dihentikan.\n${err.message}`);
  }

  return true;
}

async function handleTebak(m, gameState) {
  const { data } = gameState;
  const userAnswer = m.body?.trim().toLowerCase();

  if (!userAnswer) return false;

  if (Date.now() >= data.endTime) {
    deleteGame(m.jid);
    await m.reply(`⏰ *Waktu habis!*\n\nJawaban yang benar: *${data.answer}*`);
    return true;
  }

  if (userAnswer === data.answer.toLowerCase()) {
    deleteGame(m.jid);
    await m.reply(
      `✅ *Benar!* Selamat @${m.sender.replace("@s.whatsapp.net", "")} 🎉\n\nJawaban: *${data.answer}*`,
      { mentions: [m.sender] }
    );
  } else {
    const sisa = Math.ceil((data.endTime - Date.now()) / 1000);
    await m.reply(`❌ Salah! Sisa waktu: *${sisa}* detik`);
  }

  return true;
}

export async function handleInteractive(gara, m) {
  try {
    const game = getGame(m.jid);
    if (!game) return;

    const { type } = game;

    if (type === "akinator") {
      return await handleAkinator(m, game);
    }

    const TEBAK_TYPES = new Set([
      "tebakkata", "tekateki", "tebakangka", "tebakhewan",
      "tebakgambar", "tebakbola", "caklontong", "tebaklirik",
    ]);

    if (TEBAK_TYPES.has(type)) {
      return await handleTebak(m, game);
    }

  } catch (err) {
    console.error("[interactiveHandler error]", err.message);
  }
}
