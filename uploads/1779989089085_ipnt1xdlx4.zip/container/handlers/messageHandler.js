import { runCommand }     from "./commandHandler.js";
import { getContentType } from "gara";
import { detectSender, detectRole } from "./detector.js";
import { getCachedGroupMetadata } from "./metadataCache.js";
import { handleInteractive } from "./interactiveHandler.js";
import { handleReaction }    from "./reactionHandler.js";
import { handleStubMessage } from "./welcomeHandler.js";
import { lidStore } from "../db/lidStore.js";
import { handleAfk } from "./afkHandler.js";
import { handleAntilink } from "./antilinkHandler.js";
import { verifyStore }   from "../db/verifyStore.js";
import chalk from "chalk";
import util  from "util";
import { exec } from "child_process";

const _exec = util.promisify(exec);

const msgStoreMax = 500;
const msgStore = new Map();

export function saveToMsgStore(rawMsg) {
  if (!rawMsg?.key?.id || !rawMsg?.message) return;
  const jid = rawMsg.key.remoteJid;
  if (!jid) return;
  const key = `${jid}:${rawMsg.key.id}`;
  msgStore.set(key, rawMsg);

  if (msgStore.size > msgStoreMax) {
    const firstKey = msgStore.keys().next().value;
    msgStore.delete(firstKey);
  }
}

export function getStoredMessage(jid, msgId) {
  if (!jid || !msgId) return null;
  return msgStore.get(`${jid}:${msgId}`) ?? null;
}

const mediaTypes = new Set([
  "imageMessage", "videoMessage", "audioMessage", "stickerMessage", "documentMessage"
]);

const mediaTypeMap = {
  imageMessage   : "image",
  videoMessage   : "video",
  audioMessage   : "audio",
  documentMessage: "document",
  stickerMessage : "sticker",
};

function logMessage(type, id, sender, text, pushName) {
  const tag      = type === "GROUP"
    ? chalk.bgGreen.black(` GROUP `)
    : chalk.bgMagenta.white(` PRIVATE `);
  const botLabel = chalk.bgYellow.black(` MAIN BOT `);
  const time     = new Date().toLocaleTimeString("id-ID", { hour12: false, timeZone: "Asia/Jakarta" });

  const from    = type === "GROUP"
    ? (id?.replace("@g.us", "") ?? "?") + "@g.us"
    : (sender ?? "?") + "@s.whatsapp.net";
  const msgText = String(text ?? "").slice(0, 80);
  const user    = pushName || sender || "?";

  console.log(`${tag} ${botLabel} ${chalk.gray(time)}`);
  console.log(`${chalk.gray("├")} ${chalk.white("User")} ${chalk.gray(":")} ${chalk.magentaBright(user)}`);
  console.log(`${chalk.gray("├")} ${chalk.white("From")} ${chalk.gray(":")} ${chalk.cyan(from)}`);
  console.log(`${chalk.gray("└")} ${chalk.white("Msg ")} ${chalk.gray(":")} ${chalk.white(msgText)}\n`);
}

function extractText(message) {
  if (!message) return "";
  const type = getContentType(message);
  if (!type) return "";
  const _m = message[type];
  return (
    (type === "conversation"               ? _m                                          : null) ??
    (type === "extendedTextMessage"        ? _m?.text                                   : null) ??
    (type === "imageMessage"               ? _m?.caption                                : null) ??
    (type === "videoMessage"               ? _m?.caption                                : null) ??
    (type === "documentMessage"            ? _m?.caption ?? _m?.fileName                : null) ??
    (type === "audioMessage"               ? (_m?.ptt ? "[voice note]" : "[audio]")     : null) ??
    (type === "stickerMessage"             ? "[sticker]"                                : null) ??
    (type === "contactMessage"             ? _m?.displayName                            : null) ??
    (type === "contactsArrayMessage"       ? "[contacts]"                               : null) ??
    (type === "locationMessage"            ? ("[lokasi] " + (_m?.name ?? "")).trim()    : null) ??
    (type === "liveLocationMessage"        ? "[live location]"                          : null) ??
    (type === "pollCreationMessage"        ? _m?.name                                   : null) ??
    (type === "pollCreationMessageV3"      ? _m?.name                                   : null) ??
    (type === "ephemeralMessage"           ?
      _m?.message?.extendedTextMessage?.text ??
      _m?.message?.imageMessage?.caption ??
      _m?.message?.videoMessage?.caption ??
      _m?.message?.conversation                                                          : null) ??
    (type === "viewOnceMessage"            ?
      _m?.message?.imageMessage?.caption ??
      _m?.message?.videoMessage?.caption ??
      "[view once]"                                                                      : null) ??
    (type === "viewOnceMessageV2"          ?
      _m?.message?.imageMessage?.caption ??
      _m?.message?.videoMessage?.caption ??
      "[view once]"                                                                      : null) ??
    (type === "interactiveResponseMessage" ?
      (() => {
        try { return JSON.parse(_m?.nativeFlowResponseMessage?.paramsJson)?.id ?? null; }
        catch { return null; }
      })()                                                                               : null) ??
    (type === "templateButtonReplyMessage" ? _m?.selectedId                             : null) ??
    (type === "buttonsResponseMessage"     ? _m?.selectedButtonId                       : null) ??
    (type === "listResponseMessage"        ? _m?.singleSelectReply?.selectedRowId       : null) ??
    (type === "reactionMessage"            ? _m?.text                                   : null) ??
    ""
  );
}

function extractQuoted(rawMsg) {
  const type = getContentType(rawMsg.message);
  if (!type) return { quoted: null, quotedSender: null, quotedType: null, quotedText: null, quotedKey: null };

  const ctxInfo = rawMsg.message?.[type]?.contextInfo ?? null;
  if (!ctxInfo?.quotedMessage) return { quoted: null, quotedSender: null, quotedType: null, quotedText: null, quotedKey: null };

  let quoted         = ctxInfo.quotedMessage;
  const quotedSender = ctxInfo.participant ?? null;
  let quotedType     = getContentType(quoted) ?? null;
  const quotedText   = extractText(quoted) || null;
  const quotedKey    = {
    id       : ctxInfo.stanzaId,
    remoteJid: rawMsg.key.remoteJid,
    fromMe   : ctxInfo.participant
      ? false
      : (ctxInfo.stanzaId ? false : true),
    ...(ctxInfo.participant ? { participant: ctxInfo.participant } : {}),
  };

  if (quotedType === "interactiveMessage") {
    const header = quoted?.interactiveMessage?.header;
    if (header?.imageMessage) {
      quoted     = { ...quoted, imageMessage: header.imageMessage };
      quotedType = "imageMessage";
    } else if (header?.videoMessage) {
      quoted     = { ...quoted, videoMessage: header.videoMessage };
      quotedType = "videoMessage";
    }
  }

  return { quoted, quotedSender, quotedType, quotedText, quotedKey };
}

async function sendTyping(gara, jid, ms = 800) {
  await gara.sendPresenceUpdate("composing", jid);
  await sleep(ms);
  await gara.sendPresenceUpdate("paused", jid);
}

function buildM(gara, rawMsg, extras) {
  const {
    jid, sender, isGroup, isPrivate, pushName,
    isAdmin, isBotAdmin, isOwnerSender,
    groupMeta, groupName, groupMembers, groupAdmins, memberCount,
    msgType, isImage, isVideo, isAudio, isSticker, isDocument, isMedia,
    quoted, quotedSender, quotedType, quotedText, quotedKey,
    mentionList, isMention,
    botNumber, body, bodyLower,
  } = extras;

  const rawType        = getContentType(rawMsg.message) ?? "";
  const rawContent     = rawMsg.message?.[rawType] ?? null;
  const mediaFromQuoted = !mediaTypes.has(rawType) && mediaTypes.has(quotedType);

  const m = {
    raw      : rawMsg,
    key      : rawMsg.key,
    gara,

    jid,
    from     : jid,
    sender,
    pushName,
    body,
    bodyLower,
    args     : [],
    q        : "",
    url      : [],
    quotedUrl: [],

    type      : msgType,
    isImage,
    isVideo,
    isAudio,
    isSticker,
    isDocument,
    isMedia,
    isBot     : rawMsg.key.fromMe ?? false,

    isGroup,
    isPrivate,
    isAdmin,
    isBotAdmin,
    isOwner   : isOwnerSender,

    groupMeta,
    groupName,
    groupMembers,
    groupAdmins,
    memberCount,

    mentionList,
    isMention,
    botNumber,

    quoted,
    quotedSender,
    quotedType,
    quotedText,
    quotedKey,
    isQuoted  : !!quoted,

    reply: async (content, opts = {}) => {
      if (typeof content === "string") {
        return send(gara, jid, rawMsg, content, opts?.mentions ?? []);
      }
      if (content?.text !== undefined && !content.image && !content.video) {
        return send(gara, jid, rawMsg, content.text, content.mentions ?? opts?.mentions ?? []);
      }
      const hasImage = content.image !== undefined;
      const hasVideo = content.video !== undefined;
      if (hasImage || hasVideo) {
        const src  = hasImage ? content.image : content.video;
        const mime = content.mimetype ?? (hasVideo ? "video/mp4" : "image/jpeg");
        return sendMedia(gara, jid, rawMsg, src?.url ?? src, mime, content.caption ?? "", content.mentions ?? opts?.mentions ?? []);
      }
      return gara.sendMessage(jid, content, { quoted: rawMsg, ...opts });
    },

    send: async (content, opts = {}) => {
      if (typeof content === "string") {
        return send(gara, jid, null, content, opts?.mentions ?? []);
      }
      return gara.sendMessage(jid, content, opts);
    },

    react: async (emoji) => {
      return gara.sendMessage(jid, { react: { text: emoji, key: rawMsg.key } });
    },

    edit: async (sentKey, newText) => {
      return gara.sendMessage(jid, { text: newText, edit: sentKey });
    },

    download: async () => {
      if (mediaFromQuoted) {
        if (!quoted) throw new Error("Tidak ada pesan quoted");
        const dlType = mediaTypeMap[quotedType];
        if (!dlType) throw new Error(`Tipe quoted ${quotedType} tidak support download`);
        return download(quoted[quotedType], dlType);
      }
      if (!rawContent) throw new Error("Tidak ada media di pesan ini");
      const dlType = mediaTypeMap[rawType];
      if (!dlType) throw new Error(`Tipe media ${rawType} tidak support download`);
      return download(rawContent, dlType);
    },

    downloadQuoted: async () => {
      if (!quoted) throw new Error("Tidak ada pesan quoted");
      const dlType = mediaTypeMap[quotedType];
      if (!dlType) throw new Error(`Tipe quoted ${quotedType} tidak support download`);
      return download(quoted[quotedType], dlType);
    },

    sendAudio: async (url) => {
      return sendAudio(gara, jid, rawMsg, url);
    },

    read: async () => {
      return gara.readMessages([rawMsg.key]);
    },
  };

  return m;
}

export async function handleMessage(gara, rawMsg) {
  try {
    if (rawMsg.messageStubType) {
      await handleStubMessage(gara, rawMsg);
      return;
    }

    const botNum = gara.user?.id?.split(":")[0];
    const isBotOwnMessage = rawMsg.key.fromMe ?? false;
    const isBotSelfChat   = isBotOwnMessage && isOwner(botNum);

    if (isBotOwnMessage && !cfg.selfMode && !isBotSelfChat) return;

    if (!rawMsg.message) return;

    const { from: jid, sender: senderRaw, isGroup, isStatus, wasLid, pushName } =
      detectSender(gara, rawMsg);

    if (!jid)     return;
    if (isStatus) return;

    let sender = senderRaw;
    if (senderRaw?.endsWith("@lid")) {
      try {
        const pn = await gara.signalRepository.lidMapping.getPNForLID(senderRaw);
        if (pn) {
          lidStore.save({ lid: senderRaw, id: pn });
          sender = pn;
        }
      } catch (e) {}
    }

    const rawType = getContentType(rawMsg.message);
    if (
      rawType === "protocolMessage" ||
      rawType === "senderKeyDistributionMessage"
    ) return;

    saveToMsgStore(rawMsg);

    if (rawType === "reactionMessage") {
      const reactionGroupMeta = isGroup
        ? await getCachedGroupMetadata(gara, jid).catch(() => null)
        : null;
      const reactionRole = isGroup && reactionGroupMeta
        ? await detectRole(gara, rawMsg, reactionGroupMeta)
        : { isAdmin: false, isBotAdmin: false };

      const reactionMembers = reactionGroupMeta?.participants ?? [];
      const reactionAdmins  = reactionMembers.filter(p => p.admin != null);

      const mReact = buildM(gara, rawMsg, {
        jid,
        sender,
        isGroup,
        isPrivate   : !isGroup,
        pushName,
        isAdmin     : reactionRole.isAdmin || isOwner(sender),
        isBotAdmin  : reactionRole.isBotAdmin,
        isOwnerSender: isOwner(sender),
        groupMeta   : reactionGroupMeta,
        groupName   : reactionGroupMeta?.subject ?? "",
        groupMembers: reactionMembers,
        groupAdmins : reactionAdmins,
        memberCount : reactionMembers.length,
        mentionList : [],
        isMention   : false,
        botNumber   : gara.user?.id?.split(":")[0] + "@s.whatsapp.net",
        msgType     : rawType,
        isImage     : false,
        isVideo     : false,
        isAudio     : false,
        isSticker   : false,
        isDocument  : false,
        isMedia     : false,
        quoted      : null,
        quotedSender: null,
        quotedType  : null,
        quotedText  : null,
        quotedKey   : null,
        body        : "",
        bodyLower   : "",
      });

      await handleReaction(gara, rawMsg, mReact);
      return;
    }

    let body = extractText(rawMsg.message)?.trim() ?? "";

    if (!body) {
      const t = getContentType(rawMsg.message);
      const qCaption =
        rawMsg.message?.[t]?.contextInfo?.quotedMessage?.imageMessage?.caption ??
        rawMsg.message?.[t]?.contextInfo?.quotedMessage?.videoMessage?.caption ??
        null;
      if (qCaption) body = qCaption.trim();
    }

    const senderNum = sender.replace("@s.whatsapp.net", "");

    const logBody = (body || `[${rawType}]`).replace(/@(\d+)/g, (_, num) => {
      const resolved = lidStore.toId(num + "@lid");
      const pn = resolved.endsWith("@lid") ? num : resolved.replace("@s.whatsapp.net", "");
      return "@" + pn;
    });

    const stillLid = wasLid && sender.endsWith("@lid");
    if (!isBotOwnMessage && logBody !== `[undefined]`) logMessage(
      isGroup ? "GROUP" : "PRIVAT",
      isGroup ? jid : sender,
      senderNum + (stillLid ? chalk.gray(" [lid]") : ""),
      logBody,
      pushName
    );

    if (isGroup && !isOwner(sender)) {
      const { groupStore } = await import("../db/groupStore.js");
      if (groupStore.get(jid).mute) return;
    }

    if (!cfg.public && !isOwner(sender)) return;
    if (cfg.public === "onlygc" && !isGroup && !isOwner(sender)) return;

    let isAdmin      = false;
    let isBotAdmin   = false;
    let groupMeta    = null;
    let groupName    = "";
    let groupMembers = [];
    let groupAdmins  = [];
    let memberCount  = 0;

    if (isGroup) {
      try { groupMeta = await getCachedGroupMetadata(gara, jid); } catch {}
      const role = await detectRole(gara, rawMsg, groupMeta);
      isAdmin      = role.isAdmin || isOwner(sender);
      isBotAdmin   = role.isBotAdmin;
      groupName    = groupMeta?.subject ?? "";
      groupMembers = groupMeta?.participants ?? [];
      groupAdmins  = groupMembers.filter(p => p.admin != null);
      memberCount  = groupMembers.length;
    }

    const { quoted, quotedSender, quotedType, quotedText, quotedKey } = extractQuoted(rawMsg);

    const msgType     = rawType;
    const type        = getContentType(rawMsg.message);
    const mentionList = rawMsg.message?.[type]?.contextInfo?.mentionedJid ?? [];
    const botNumber   = gara.user?.id?.split(":")[0] + "@s.whatsapp.net";
    const isMention   = mentionList.includes(botNumber) ||
                        mentionList.includes(gara.user?.id);

    const isImage    = rawType === "imageMessage"    || quotedType === "imageMessage" || !!quoted?.imageMessage;
    const isVideo    = rawType === "videoMessage"    || quotedType === "videoMessage" || !!quoted?.videoMessage;
    const isAudio    = rawType === "audioMessage"    || quotedType === "audioMessage";
    const isSticker  = rawType === "stickerMessage"  || quotedType === "stickerMessage";
    const isDocument = rawType === "documentMessage" || quotedType === "documentMessage";
    const isMedia    = isImage || isVideo || isAudio || isSticker || isDocument;

    const m = buildM(gara, rawMsg, {
      jid, sender, isGroup, isPrivate: !isGroup, pushName,
      isAdmin, isBotAdmin, isOwnerSender: isOwner(sender),
      groupMeta, groupName, groupMembers, groupAdmins, memberCount,
      msgType, isImage, isVideo, isAudio, isSticker, isDocument, isMedia,
      quoted, quotedSender, quotedType, quotedText, quotedKey,
      mentionList, isMention,
      botNumber,
      body, bodyLower: body.toLowerCase(),
    });

    if (cfg.autoRead) await gara.readMessages([rawMsg.key]);

    if (!isBotOwnMessage && body) {
  const xpResult = rpg.addExp(sender, Math.ceil(Math.random() * 10), pushName);
  if (xpResult.leveledUp) {
    await m.reply(
      "Selamat, kamu naik level!\n\n" +
      `Level: ${xpResult.before} => *${xpResult.after}*\n` +
      `Role: *${xpResult.user.role}*\n` +
      `Total XP: ${Number(xpResult.user.exp).toLocaleString("id-ID")}\n\n` +
      "Ketik .profile untuk lihat progress kamu!"
    );
  }
}

    await handleAfk(m);

    const isEvalAsync = body.startsWith("> ");
    const isEvalSync  = body.startsWith("=> ");
    const isExec      = body.startsWith("$ ");

    if ((isEvalAsync || isEvalSync || isExec) && isOwner(sender)) {
      const code = isEvalSync ? body.slice(3).trim() : body.slice(2).trim();
      if (!code) return;

      if (isExec) {
        try {
          const { stdout, stderr } = await _exec(code);
          return m.reply(String(stdout || stderr || "(tidak ada output)").slice(0, 3000));
        } catch (e) {
          return m.reply(String(e).slice(0, 3000));
        }
      }

      try {
        let result = isEvalSync
          ? await eval("(async () => { return " + code + " })()")
          : await eval("(async () => { " + code + " })()");
        if (typeof result !== "string") result = util.inspect(result, { depth: 3 });
        if (result && result !== "undefined")
          return m.reply(String(result).slice(0, 3000));
      } catch (e) {
        return m.reply(String(e).slice(0, 3000));
      }
      return;
    }

    if (await handleAntilink(gara, m, rawMsg)) return;

    if (rawType === "contactMessage") {
      if (!verifyStore.isEnabled() || verifyStore.isVerified(sender)) return;
      if (!verifyStore.isPending(sender)) return;
      const contact = rawMsg.message.contactMessage;
      const result  = verifyStore.tryVerifyContact(
        sender,
        contact?.displayName ?? "",
        contact?.vcard ?? ""
      );
      if (result.ok) {
        await m.reply(verifyStore.msgSuccess(result.displayName));
      } else {
        await m.reply(verifyStore.msgWrongContact(result));
      }
      return;
    }

    if (body.startsWith(prefix)) {
      if (verifyStore.isEnabled() && !isOwner(sender) && !verifyStore.isVerified(sender)) {
        verifyStore.setPending(sender);
        await m.reply({ video: { url: "https://raw.githubusercontent.com/gara31/void-md/main/uploads/1779863918028_s2i1d4hiage.mp4" }, mimetype: "video/mp4", caption: verifyStore.msgNeedVerify() });
        return;
      }
      const split       = body.slice(prefix.length).trim().split(/\s+/);
      const commandName = split.shift().toLowerCase();
      const args        = split;
      m.args = args;
      m.q    = args.join(" ");
      m.cmd  = commandName;

      m.url       = parseLink(m.q);
      m.quotedUrl = parseLink(m.quotedText || "");

      if (!m.q && m.quotedText) {
        const urlMatch = m.quotedText.match(/https?:\/\/[^\s]+/);
        if (urlMatch) {
          m.q    = m.quotedText.trim();
          m.args = m.q.split(/\s+/);
        }
      }

      await sendTyping(gara, jid, 800);
      await runCommand(commandName, m);
      return;
    }

    for (const [kw, res] of Object.entries(cfg.autoReply ?? {})) {
      if (m.bodyLower.includes(kw.toLowerCase())) {
        await sendTyping(gara, jid, 800);
        await m.reply(res);
        return;
      }
    }

    if (body) await handleInteractive(gara, m);

  } catch (err) {
    console.error(chalk.red("[MSG ERROR]"), err.message);
  }
}
