
import { getContentType }                          from "gara";
import { detectRole, fetchLidParticipants }        from "./detector.js";
import { getCachedGroupMetadata }                  from "./metadataCache.js";
import { runCommand }                              from "./commandHandler.js";
import { lidStore }                                from "../db/lidStore.js";
import { getStoredMessage }                        from "./messageHandler.js";
import chalk                                       from "chalk";

async function resolveTargetLid(lid, gara, jid) {
  if (!lid) return null;
  if (!lid.endsWith("@lid")) return lid;

  let resolved = lidStore.toId(lid);
  if (resolved && !resolved.endsWith("@lid")) return resolved;

  try {
    await fetchLidParticipants(gara, jid);
  } catch {}

  resolved = lidStore.toId(lid);
  return (resolved && !resolved.endsWith("@lid")) ? resolved : null;
}

function extractMsgText(msg) {
  if (!msg) return "";
  const type = getContentType(msg);
  if (!type) return "";
  const m = msg[type];
  return m?.text ?? m?.caption ?? (type === "conversation" ? m : null) ?? "";
}

function logReaction(emoji, cmd, sender, jid) {
  const time = new Date().toLocaleTimeString("id-ID", { hour12: false });
  console.log(
    `${chalk.gray(time)} ${chalk.bgMagenta.black(" REACT ")} ` +
    `${chalk.cyan(jid?.replace("@g.us", "") ?? "?")} ` +
    `${chalk.gray(">")} ${chalk.yellow(sender?.replace("@s.whatsapp.net", "") ?? "?")} ` +
    `${chalk.gray("→")} ${chalk.green(cmd)} ${chalk.white(emoji)}`
  );
}

const REACTION_MAP = [
  {
    emojis: [
      "🦶","🦶🏻","🦶🏼","🦶🏽","🦶🏾","🦶🏿",
      "🦵","🦵🏻","🦵🏼","🦵🏽","🦵🏾","🦵🏿","🦿",
    ],
    cmd: "kick",
    prepare(m, rd) {
      const target = rd.targetJid;
      if (!target) return;

      m.raw.message = {
        extendedTextMessage: {
          text: "",
          contextInfo: { mentionedJid: [target] },
        },
      };
      m.mentionList = [target];
      m.args        = [target];
      m.q           = target;
    },
  },
  {
    emojis: ["🗑️","🗑","❌"],
    cmd: "delete",
    prepare(m, rd) { m._reactionTargetKey = rd.targetKey; },
  },
  {
    emojis: ["🖼️","🖨️","🤳","🤳🏻","🤳🏼","🤳🏽","🤳🏾","🤳🏿"],
    cmd: "sticker",
    prepare(m, rd) {
      if (!rd.targetMsg) {
        m._earlyExit = async () => m.reply("❗pesan terlalu lama, bot belum sempat menyimpannya");
        return;
      }
      const tType = getContentType(rd.targetMsg.message);
      m.isImage    = tType === "imageMessage";
      m.isVideo    = tType === "videoMessage";
      m.isSticker  = tType === "stickerMessage";
      m.isMedia    = m.isImage || m.isVideo || m.isSticker;
      m.quoted     = rd.targetMsg.message;
      m.quotedType = tType;
      m.download   = async () => download(rd.targetMsg.message[tType], tType.replace("Message", ""));
      m.downloadQuoted = m.download;
    },
  },
  {
    emojis: ["🔈","🔉","🔊","🎙️","🎤"],
    cmd: "tts",
    prepare(m, rd) {
      m.q    = rd.targetText ?? "";
      m.args = rd.targetText ? rd.targetText.split(/\s+/) : [];
    },
  },
  {
    emojis: ["🔎","🔍"],
    cmd: "ai",
    prepare(m, rd) {
      m.q    = rd.targetText ?? "";
      m.args = rd.targetText ? rd.targetText.split(/\s+/) : [];
    },
  },
  {
    emojis: ["🌐","🆔"],
    cmd: "translate",
    prepare(m, rd) {
      m.q    = rd.targetText ?? "";
      m.args = rd.targetText ? rd.targetText.split(/\s+/) : [];
    },
  },
];

const emojiLookup = new Map();
for (const entry of REACTION_MAP) {
  for (const e of entry.emojis) emojiLookup.set(e, entry);
}

export async function handleReaction(gara, rawMsg, m) {
  try {
    const reactionMsg = rawMsg.message?.reactionMessage;
    if (!reactionMsg) return;

    const emoji   = reactionMsg.text;
    const jid     = rawMsg.key.remoteJid;
    const isGroup = jid?.endsWith("@g.us") ?? false;

    const reactorJid = rawMsg.key.participantAlt
      ?? (rawMsg.key.participant?.endsWith("@lid")
          ? (lidStore.toId(rawMsg.key.participant) ?? rawMsg.key.participant)
          : rawMsg.key.participant)
      ?? m.sender;

    let targetJid = null;
    if (reactionMsg.key?.fromMe) {
      targetJid = gara.user?.id?.split(":")[0] + "@s.whatsapp.net";
    } else {
      const targetLid = reactionMsg.key?.participant;
      if (targetLid) {
        targetJid = await resolveTargetLid(targetLid, gara, jid);

        if (!targetJid) targetJid = targetLid;
      }
    }

    let targetMsg  = null;
    let targetText = "";
    const targetMsgId = reactionMsg.key?.id;
    if (targetMsgId) {

      const stored = getStoredMessage(jid, targetMsgId);
      if (stored) {
        targetMsg  = stored;
        targetText = extractMsgText(stored.message)?.trim() ?? "";
      } else {

        try {
          const loaded = await gara.loadMessage?.(jid, targetMsgId);
          if (loaded) {
            targetMsg  = loaded;
            targetText = extractMsgText(loaded.message)?.trim() ?? "";
          }
        } catch {}
      }
    }

    if (!emoji) return;
    const entry = emojiLookup.get(emoji);
    if (!entry) return;

    let groupMeta    = m.groupMeta;
    let isAdmin      = m.isAdmin;
    let isBotAdmin   = m.isBotAdmin;
    let groupMembers = m.groupMembers ?? [];
    let groupAdmins  = m.groupAdmins  ?? [];

    if (isGroup && !groupMeta) {
      try { groupMeta = await getCachedGroupMetadata(gara, jid); } catch {}
      if (groupMeta) {
        const role   = await detectRole(gara, rawMsg, groupMeta);
        isAdmin      = role.isAdmin || isOwner(reactorJid);
        isBotAdmin   = role.isBotAdmin;
        groupMembers = groupMeta.participants ?? [];
        groupAdmins  = groupMembers.filter(p => p.admin != null);
      }
    }

    const rd = {
      emoji, reactorJid, targetJid,
      targetKey: {
        ...reactionMsg.key,
        remoteJid: jid,
      },
      targetText, targetMsg,
    };

    m.sender       = reactorJid;
    m.isAdmin      = isAdmin || isOwner(reactorJid);
    m.isBotAdmin   = isBotAdmin;
    m.isGroup      = isGroup;
    m.isPrivate    = !isGroup;
    m.groupMeta    = groupMeta;
    m.groupMembers = groupMembers;
    m.groupAdmins  = groupAdmins;
    m.memberCount  = groupMembers.length;
    m.cmd          = entry.cmd;

    if (typeof entry.prepare === "function") {
      entry.prepare(m, rd);
    }

    if (typeof m._earlyExit === "function") {
      await m._earlyExit();
      return;
    }

    if (!rd.targetMsg && !rd.targetText) {
      await m.reply("❗pesan terlalu lama, bot belum sempat menyimpannya");
      return;
    }

    logReaction(emoji, entry.cmd, reactorJid, jid);
    await runCommand(entry.cmd, m);

  } catch (err) {
    console.error(chalk.red("[REACT ERROR]"), err.message, err.stack);
  }
}

