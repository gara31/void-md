import { afkStore } from "../db/afkStore.js";

function durStr(ms) {
  const mnt = Math.floor(ms / 60000);
  const dtk = Math.floor((ms % 60000) / 1000);
  return mnt > 0 ? `${mnt} menit ${dtk} detik` : `${dtk} detik`;
}

export async function handleAfk(m) {
  if (!m.isGroup) return false;

  const { sender, mentionList, quotedSender, body } = m;

  const myAfk = afkStore.get(sender);
  if (myAfk && !body.startsWith(global.prefix + "afk")) {
    afkStore.del(sender);
    await m.reply(
      `Selamat datang kembali @${sender.split("@")[0]}! Kamu AFK selama ${durStr(Date.now() - myAfk.time)}`,
      { mentions: [sender] }
    );
    return false;
  }

  const seen = new Set();

  const check = async (jid) => {
    if (!jid || jid === sender) return;
    const resolved = global.resolveJid(jid) ?? jid;
    if (seen.has(resolved)) return;
    seen.add(resolved);
    const data = afkStore.get(resolved);
    if (!data) return;
    await m.reply(
      `Dia sedang AFK dengan alasan *${data.reason}*\nsejak ${durStr(Date.now() - data.time)} lalu`,
      { mentions: [resolved] }
    );
  };

  if (quotedSender) await check(quotedSender);

  if (mentionList?.length > 0) {
    for (const jid of mentionList) await check(jid);
  }
}
