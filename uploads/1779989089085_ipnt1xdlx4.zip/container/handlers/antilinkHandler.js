import { groupStore } from "../db/groupStore.js";

export async function handleAntilink(gara, m, rawMsg) {
  if (!m.isGroup)      return false;
  if (m.isBot)         return false;
  if (m.isOwnerSender) return false;
  if (m.isAdmin)       return false;
  if (!m.isBotAdmin)   return false;

  const data = groupStore.get(m.jid);
  if (!data.antilink)  return false;

  const urls = parseLink(m.body);
  if (!urls.length)    return false;

  const isViolation = urls.some(u => data.links.some(banned => u.includes(banned)));
  if (!isViolation)    return false;

  const senderNum = m.sender.split("@")[0];
  const maxWarn   = 3;

  data.warn[senderNum] = (data.warn[senderNum] ?? 0) + 1;
  const count = data.warn[senderNum];
  groupStore.set(m.jid, { warn: data.warn });

  try { await gara.sendMessage(m.jid, { delete: rawMsg.key }); } catch {}

  if (count >= maxWarn) {
    data.warn[senderNum] = 0;
    groupStore.set(m.jid, { warn: data.warn });
    await m.reply(
      `@${senderNum} Kamu dikeluarkan karena melanggar peraturan grup untuk tidak mengirim link hingga peringatan terakhir!`,
      { mentions: [m.sender] }
    );
    try { await gara.groupParticipantsUpdate(m.jid, [m.sender], "remove"); } catch {}
  } else {
    await m.reply(
      `@${senderNum} Kamu terdeteksi mengirimkan link! Harap ikuti peraturan disini untuk tidak mengirim link!\n` +
      `Peringatan: *${count}/${maxWarn}*`,
      { mentions: [m.sender] }
    );
  }

  return true;
}
