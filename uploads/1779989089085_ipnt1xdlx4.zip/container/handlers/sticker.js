/**
 * Create By Mhankbarbar
 * re-code By Rifza
 * re-code ulang By Gara
 */

import fs     from "fs";
import os     from "os";
import crypto from "crypto";
import ff     from "fluent-ffmpeg";
import webp   from "node-webpmux";
import path   from "path";

const tmpdir = os.tmpdir();
const rand   = () => crypto.randomBytes(6).readUIntLE(0, 6).toString(36);

export async function imageToWebp(media) {
  const tmpIn  = path.join(tmpdir, `${rand()}.jpg`);
  const tmpOut = path.join(tmpdir, `${rand()}.webp`);

  fs.writeFileSync(tmpIn, media);

  await new Promise((resolve, reject) => {
    ff(tmpIn)
      .on("error", reject)
      .on("end", () => resolve(true))
      .addOutputOptions([
        "-vcodec", "libwebp",
        "-vf",
        "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
      ])
      .toFormat("webp")
      .save(tmpOut);
  });

  const buff = fs.readFileSync(tmpOut);
  fs.unlinkSync(tmpIn);
  fs.unlinkSync(tmpOut);
  return buff;
}

export async function videoToWebp(media) {
  const tmpIn  = path.join(tmpdir, `${rand()}.mp4`);
  const tmpOut = path.join(tmpdir, `${rand()}.webp`);

  fs.writeFileSync(tmpIn, media);

  await new Promise((resolve, reject) => {
    ff(tmpIn)
      .on("error", reject)
      .on("end", () => resolve(true))
      .addOutputOptions([
        "-vcodec", "libwebp",
        "-vf",
        "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse",
        "-loop",    "0",
        "-ss",      "00:00:00",
        "-t",       "00:00:05",
        "-preset",  "default",
        "-an",
        "-vsync",   "0",
      ])
      .toFormat("webp")
      .save(tmpOut);
  });

  const buff = fs.readFileSync(tmpOut);
  fs.unlinkSync(tmpIn);
  fs.unlinkSync(tmpOut);
  return buff;
}

export async function writeExifImg(media, metadata, converted = false) {
  const wMedia = converted ? media : await imageToWebp(media);
  const tmpIn  = path.join(tmpdir, `${rand()}.webp`);
  const tmpOut = path.join(tmpdir, `${rand()}.webp`);

  fs.writeFileSync(tmpIn, wMedia);

  if (metadata.packname || metadata.author) {
    const img  = new webp.Image();
    const json = {
      "sticker-pack-id"       : "https://github.com/gara31",
      "sticker-pack-name"     : metadata.packname,
      "sticker-pack-publisher": metadata.author,
      emojis                  : metadata.categories ?? [""],
    };

    const exifAttr = Buffer.from([
      0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
    ]);
    const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
    const exif     = Buffer.concat([exifAttr, jsonBuff]);
    exif.writeUIntLE(jsonBuff.length, 14, 4);

    await img.load(tmpIn);
    fs.unlinkSync(tmpIn);
    img.exif = exif;
    await img.save(tmpOut);
    return tmpOut;
  }
}

export async function writeExifVid(media, metadata, converted = false) {
  const wMedia = converted ? media : await videoToWebp(media);
  const tmpIn  = path.join(tmpdir, `${rand()}.webp`);
  const tmpOut = path.join(tmpdir, `${rand()}.webp`);

  fs.writeFileSync(tmpIn, wMedia);

  if (metadata.packname || metadata.author) {
    const img  = new webp.Image();
    const json = {
      "sticker-pack-id"       : "https://github.com/gara31",
      "sticker-pack-name"     : metadata.packname,
      "sticker-pack-publisher": metadata.author,
      emojis                  : metadata.categories ?? [""],
    };

    const exifAttr = Buffer.from([
      0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
    ]);
    const jsonBuff = Buffer.from(JSON.stringify(json), "utf-8");
    const exif     = Buffer.concat([exifAttr, jsonBuff]);
    exif.writeUIntLE(jsonBuff.length, 14, 4);

    await img.load(tmpIn);
    fs.unlinkSync(tmpIn);
    img.exif = exif;
    await img.save(tmpOut);
    return tmpOut;
  }
}

export async function webpToMp4(media) {
  const fileUrl = await uguu(media);
  const params  = new URLSearchParams({ url: fileUrl, from: "webp", to: "mp4", key: api.xterm.key });
  const result  = await fetch(`${api.xterm.url}/api/tools/convert?${params}`).then(r => r.json());

  if (!result?.data) throw new Error("Konversi gagal dari API");
  return result.data;
}
