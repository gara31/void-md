import { userStore } from "./userStore.js";

function toPersonalJid(jid) {
  return jid.replace(/@.+/, "") + "@s.whatsapp.net";
}

function normalizePhone(num) {
  num = String(num).replace(/\D/g, "");
  if (num.startsWith("62")) return num.slice(2);
  if (num.startsWith("0"))  return num.slice(1);
  return num;
}

const _pending = new Map();
const PENDING_TTL_MS = 10 * 60 * 1000;

export const verifyStore = {
  isEnabled() {
    return cfg?.verify?.enabled === true;
  },

  isVerified(jid) {
    if (!this.isEnabled()) return true;
    if (isOwner(jid.replace(/@.+/, ""))) return true;
    return userStore.getUser(toPersonalJid(jid))?.verified === true;
  },

  setVerified(jid) {
    const user = userStore.getUser(toPersonalJid(jid));
    user.verified = true;
    userStore.save();
    _pending.delete(toPersonalJid(jid));
  },

  setPending(jid) {
    _pending.set(toPersonalJid(jid), Date.now());
  },

  isPending(jid) {
    const ts = _pending.get(toPersonalJid(jid));
    if (!ts) return false;
    if (Date.now() - ts > PENDING_TTL_MS) {
      _pending.delete(toPersonalJid(jid));
      return false;
    }
    return true;
  },

  tryVerifyContact(jid, displayName, vcard) {
    const svNumber  = cfg?.verify?.sv_number ?? "";
    const svKeyword = cfg?.verify?.sv_keyword ?? "gara";
    const keywords  = Array.isArray(svKeyword) ? svKeyword : [svKeyword];

    const waidMatch  = vcard?.match(/waid=(\d+)/);
    const telMatch   = vcard?.match(/TEL[^:]*:[+\d][\d\s\-]+/);
    const sentNumber = waidMatch
      ? waidMatch[1]
      : telMatch ? telMatch[0].split(":").pop().replace(/[^\d]/g, "") : "";

    const numberOk = svNumber && sentNumber &&
      normalizePhone(sentNumber) === normalizePhone(svNumber);

    const nameOk = keywords.every(kw =>
      displayName?.toLowerCase().includes(kw.toLowerCase())
    );

    if (numberOk && nameOk) {
      this.setVerified(jid);
      return { ok: true, displayName };
    }
    return { ok: false, numberOk, nameOk, sentNumber, displayName };
  },

  msgNeedVerify() {
    const svNumber  = cfg?.verify?.sv_number  ?? "";
    const svKeyword = cfg?.verify?.sv_keyword ?? "gara";
    const raw       = Array.isArray(svKeyword) ? svKeyword.join(" dan ") : svKeyword;
    const svName    = cfg?.verify?.sv_name    ?? raw + " Owner";

    return [
      `*HARAP IKUTIN INSTRUKSI VIDEO DIATAS!*`,
      ``,
      `*CARA VERIFIKASI*`,
      `- Simpan nomor: *${svNumber}*`,
      `- Nama kontak harus mengandung kata *"${raw}"*`,
      ``,
      `*CONTOH NAMA KONTAK*`,
      `- gara own bot`,
      `- gara hosting`,
      `- ${raw.split(" ")[0]}`,
      ``,
      `*LANGKAH*`,
      `1. Simpan nomor *${svNumber}* di HP kamu`,
      `2. Beri nama kontak yang mengandung kata *"${raw}"*`,
      `3. Kirim / Share kontak tersebut ke sini sebagai bukti`,
      ``,
      `Verifikasi memerlukan waktu 3 menit, segera verifikasi`,
    ].join("\n");
  },

  msgSuccess(displayName) {
    return [
      `✅ *Verifikasi Berhasil*`,
      ``,
      `*DETAIL*`,
      `- Kontak: *${displayName}*`,
      `- Status: Terverifikasi`,
      ``,
      `Kamu sudah bisa menggunakan semua fitur bot ini`,
      `Ketik *${prefix}menu* untuk melihat daftar fitur.`,
    ].join("\n");
  },

  msgWrongContact(result) {
    const svNumber  = cfg?.verify?.sv_number  ?? "";
    const svKeyword = cfg?.verify?.sv_keyword ?? "gara";
    const raw       = Array.isArray(svKeyword) ? svKeyword.join(" dan ") : svKeyword;
    const svName    = cfg?.verify?.sv_name    ?? raw + " Owner";
    const { numberOk, nameOk, sentNumber, displayName } = result;

    const lines = [
      `⚠️ *Verifikasi Gagal*`,
      ``,
      `*DETAIL KESALAHAN*`,
    ];

    if (!numberOk) lines.push(`- Nomor: *${sentNumber || "?"}* bukan nomor owner Bot`);
    if (!nameOk)   lines.push(`\n- Nama: *"${displayName}"* tidak mengandung kata *"${raw}"*`);

    lines.push(
      ``,
      `*PASTIKAN*`,
      `- Nomor yang disimpan: *${svNumber}*`,
      `- Nama kontak mengandung kata *"${raw}"*`,
      `- Contoh nama: _${svName}_`,
      ``,
      `1. Simpan nomor *${svNumber}* di HP kamu`,
      `2. Beri nama kontak yang mengandung kata *"${raw}"*`,
      `3. Kirim ulang kontak tersebut ke sini`,
    );

    return lines.join("\n");
  },

  msgExpired() {
    return [
      `*Waktu Verifikasi Habis*`,
      ``,
      `*DETAIL*`,
      `- Status: Sesi kedaluwarsa (3 menit)`,
      ``,
      `Gunakan salah satu fitur bot untuk memulai verifikasi ulang.`,
    ].join("\n");
  },
};
