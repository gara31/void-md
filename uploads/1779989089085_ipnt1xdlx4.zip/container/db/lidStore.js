import fs   from "fs";
import path from "path";

const DB_DIR  = "./db";
const DB_PATH = path.join(DB_DIR, "lids.json");

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

function loadFromFile() {
  try {
    if (fs.existsSync(DB_PATH)) {
      return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
    }
  } catch (e) {
    console.error("[lidStore] Gagal load lids.json:", e.message);
  }
  return [];
}

let _store = loadFromFile();

function saveToFile() {
  try {
    const tmp = DB_PATH + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(_store, null, 2));
    fs.renameSync(tmp, DB_PATH);
  } catch (e) {
    console.error("[lidStore] Gagal simpan lids.json:", e.message);
  }
}

export function normJid(jid) {
  if (!jid || typeof jid !== "string") return null;
  const atIdx = jid.lastIndexOf("@");
  if (atIdx === -1) return null;
  const server   = jid.slice(atIdx + 1);
  const userPart = jid.slice(0, atIdx);
  const user     = userPart.split(":")[0];
  return `${user}@${server}`;
}

export const lidStore = {
  getAll: () => _store,
  count:  () => _store.length,

  find(jid) {
    if (!jid) return null;
    const norm = normJid(jid);
    if (!norm) return null;
    return _store.find(e => normJid(e.lid) === norm || normJid(e.id) === norm) || null;
  },

  toId(lidJid) {
    const entry = this.find(lidJid);
    return entry?.id || lidJid;
  },

  toLid(idJid) {
    const entry = this.find(idJid);
    return entry?.lid || idJid;
  },

  save(data) {
    const items = Array.isArray(data) ? data : [data];
    let added = 0, updated = 0, skipped = 0;

    for (const item of items) {
      if (!item?.lid || !item?.id) { skipped++; continue; }
      const normLid = normJid(item.lid);
      const normId  = normJid(item.id);
      if (!normLid || !normId)                 { skipped++; continue; }
      if (!normLid.endsWith("@lid"))           { skipped++; continue; }
      if (!normId.endsWith("@s.whatsapp.net")) { skipped++; continue; }

      const idx = _store.findIndex(e => normJid(e.lid) === normLid);
      if (idx === -1) {
        _store.push({ lid: normLid, id: normId, name: item.name || null, savedAt: Date.now() });
        added++;
      } else {
        const old = _store[idx];
        const newName = item.name || old.name;
        if (old.id !== normId || old.name !== newName) {
          _store[idx] = { ...old, id: normId, name: newName, savedAt: Date.now() };
          updated++;
        } else skipped++;
      }
    }

    if (added > 0 || updated > 0) {
      saveToFile();
      console.log(
        `\x1b[36m[lidStore]\x1b[0m` +
        (added   ? ` \x1b[32m+${added} added\x1b[0m`    : "") +
        (updated ? ` \x1b[33m~${updated} updated\x1b[0m` : "") +
        (skipped ? ` \x1b[90m${skipped} skipped\x1b[0m`  : "")
      );
    }
    return { added, updated, skipped };
  },

  updateName(jid, name) {
    if (!jid || !name || name === ".") return false;
    const entry = this.find(jid);
    if (!entry || entry.name === name) return false;
    return this.save({ lid: entry.lid, id: entry.id, name }).updated > 0;
  },

  remove(jid) {
    const norm   = normJid(jid);
    const before = _store.length;
    _store = _store.filter(e => normJid(e.lid) !== norm && normJid(e.id) !== norm);
    if (_store.length !== before) { saveToFile(); return true; }
    return false;
  },

  reload() {
    _store = loadFromFile();
    console.log(`\x1b[36m[lidStore]\x1b[0m Reloaded (${_store.length} entries)`);
  },
};
