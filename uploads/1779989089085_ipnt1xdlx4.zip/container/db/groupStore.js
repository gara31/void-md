import fs from "fs";

const path = "./db/group.json";

let db = (() => {
  try { return JSON.parse(fs.readFileSync(path, "utf-8")); } catch { return {}; }
})();

function save() {
  const tmp = path + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, path);
}

function get(jid) {
  db[jid] ??= {
    welcome  : false,
    leave    : false,
    wtxt     : "",
    ltxt     : "",
    antilink : false,
    links    : ["chat.whatsapp.com"],
    warn     : {},
  };
  db[jid].antilink ??= false;
  db[jid].links    ??= ["chat.whatsapp.com"];
  db[jid].warn     ??= {};
  db[jid].mute     ??= false;
  return db[jid];
}

function set(jid, patch) {
  db[jid] = { ...get(jid), ...patch };
  save();
}

export const groupStore = { get, set, save };
