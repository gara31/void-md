import fs   from "fs";
import path from "path";

const dbPath = "./db/users.json";

const roles = [
  ["Legend"      , 90],
  ["Master Woods", 80],
  ["Master Fap"  , 60],
  ["Amberhill"   , 50],
  ["Rosenvale"   , 40],
  ["Farmount"    , 30],
  ["Black Woods" , 20],
  ["Kitten Town" , 10],
  ["Beginner"    ,  0],
];

const growth = Math.pow(Math.PI / Math.E, 1.618) * Math.E * 0.75;
const multi  = 69;

let _db = (() => {
  try { return JSON.parse(fs.readFileSync(dbPath, "utf-8")); } catch { return {}; }
})();

function _save() {
  try {
    const tmp = dbPath + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(_db, null, 2));
    fs.renameSync(tmp, dbPath);
  } catch (e) {
    console.error("[userStore] Gagal simpan:", e.message);
  }
}

function xpRange(level) {
  level = Math.floor(level);
  const min = level === 0 ? 0 : Math.round(Math.pow(level, growth) * multi) + 1;
  const max = Math.round(Math.pow(level + 1, growth) * multi);
  return { min, max, xp: max - min };
}

function canLevelUp(level, exp) {
  if (level < 0 || !isFinite(exp) || exp <= 0) return false;
  let lv = 0;
  do lv++;
  while (xpRange(lv).min <= exp);
  return level < lv - 1;
}

function getRoleByLevel(level) {
  return (roles.find(([, min]) => level >= min) ?? roles[roles.length - 1])[0];
}

function ensureUser(jid, pushName = "") {
  if (!_db[jid]) {
    _db[jid] = { jid, name: pushName || jid.split("@")[0], exp: 0, level: 0, role: "Beginner", balance: 100 };
    _save();
  }
  _db[jid].exp     ??= 0;
  _db[jid].level   ??= 0;
  _db[jid].role    ??= "Beginner";
  _db[jid].balance ??= 100;
  return _db[jid];
}

export const userStore = {
  roles: Object.fromEntries(roles.map(([name, min]) => [name, min])),
  xpRange,

  getUser(jid, pushName = "") {
    return ensureUser(jid, pushName);
  },

  addExp(jid, amount, pushName = "") {
    const user   = ensureUser(jid, pushName);
    const before = user.level;

    user.exp += amount;
    while (canLevelUp(user.level, user.exp)) user.level++;
    user.role = getRoleByLevel(user.level);

    if (pushName && pushName !== "." && pushName !== user.name)
      user.name = pushName;

    _save();
    return { leveledUp: user.level > before, before, after: user.level, user };
  },

  getAll() { return _db; },

  getBalance(jid) {
    const user = ensureUser(jid);
    return user.balance;
  },

  addBalance(jid, amount) {
    const user = ensureUser(jid);
    user.balance += amount;
    _save();
    return user.balance;
  },

  deductBalance(jid, amount) {
    const user = ensureUser(jid);
    if (user.balance < amount) return false;
    user.balance -= amount;
    _save();
    return user.balance;
  },

  setBalance(jid, amount) {
    const user = ensureUser(jid);
    user.balance = amount;
    _save();
    return user.balance;
  },

  save() {
    _save();
  },
};
