import { userStore } from "./userStore.js";

export const afkStore = {
  set(jid, reason) {
    const user = userStore.getUser(jid);
    user.afk = { time: Date.now(), reason: reason || "ngkk tau" };
    userStore._save?.();
    _forceSave(jid, user);
  },

  get(jid) {
    const num = jid.split("@")[0];
    const db  = userStore.getAll();
    const key = Object.keys(db).find(k => k.split("@")[0] === num);
    return key ? db[key]?.afk ?? null : null;
  },

  has(jid) {
    return !!this.get(jid);
  },

  del(jid) {
    const num = jid.split("@")[0];
    const db  = userStore.getAll();
    const key = Object.keys(db).find(k => k.split("@")[0] === num);
    if (!key || !db[key]?.afk) return;
    delete db[key].afk;
    _forceSave(key, db[key]);
  },
};

import fs from "fs";
function _forceSave(jid, userData) {
  try {
    const dbPath = "./db/users.json";
    const raw = (() => { try { return JSON.parse(fs.readFileSync(dbPath, "utf-8")); } catch { return {}; } })();
    raw[jid] = userData;
    const tmp = dbPath + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(raw, null, 2));
    fs.renameSync(tmp, dbPath);
  } catch (e) {
    console.error("[afkStore] Gagal simpan:", e.message);
  }
}
