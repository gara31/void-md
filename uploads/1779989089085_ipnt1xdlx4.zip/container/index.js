import "./global.js";

import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
  generateWAMessageContent,
  getContentType,
  fetchLatestBaileysVersion,
} from "gara";
import { randomBytes } from "crypto";
import { Boom }    from "@hapi/boom";
import pino        from "pino";
import readline    from "readline";
import chalk       from "chalk";
import fs          from "fs";
import { handleMessage }       from "./handlers/messageHandler.js";
import { getStoredMessage }    from "./handlers/messageHandler.js";
import { loadCommands }        from "./handlers/commandHandler.js";
import { registerLidDetector } from "./handlers/detector.js";
import { convertToOpus, generateWaveform } from "./handlers/ffmpeg.js";
import { lidStore } from "./db/lidStore.js";

const logger       = pino({ level: "silent" });
const question     = (rl, text) => new Promise((resolve) => rl.question(text, resolve));
const processedIds = new Set();

const generateMessageIDV2 = (userId = "") => {
  const hash = randomBytes(8).toString("hex").toUpperCase();
  const rand = randomBytes(8).toString("hex").toUpperCase();
  return (hash + rand).slice(0, 22);
};

let isReconnecting = false;

async function connect() {
  const { state, saveCreds } = await useMultiFileAuthState(session);
  const { version } = await fetchLatestBaileysVersion();

  const gara = makeWASocket({
    version,
    logger,
    printQRInTerminal  : false,
    browser            : Browsers.ubuntu("Chrome"),
    auth               : state,
    retryRequestDelayMs: 5000,
    maxMsgRetryCount   : 2,
    getMessage         : async (key) => {
      const stored = getStoredMessage(key.remoteJid, key.id);
      return stored?.message ?? undefined;
    },
    syncFullHistory    : false,
  });

  const _origSendMessage = gara.sendMessage.bind(gara);
  gara.sendMessage = async (id, config, etc = {}) => {
    const isPTT = config.ptt === true;
    if (config.audio) {
      const source = config.audio?.url
        ? await fetch(config.audio.url).then(r => r.arrayBuffer()).then(b => Buffer.from(b))
        : config.audio;

      if (isPTT) {
        config.mimetype = "audio/ogg; codecs=opus";
        const buffer = await convertToOpus(Buffer.from(source));
        config.audio  = buffer;

        const message = await generateWAMessageContent(config, {
          upload: gara.waUploadToServer,
        });
        const type = getContentType(message);
        message[type].waveform = await generateWaveform(buffer);

        if (etc.quoted) {
          message[type].contextInfo = {
            stanzaId     : etc.quoted.key.id,
            participant  : etc.quoted.key.participant || etc.quoted.key.remoteJid,
            quotedMessage: etc.quoted.message,
          };
        }

        const msgId = generateMessageIDV2(gara.user.id);
        await gara.relayMessage(id, message, { messageId: msgId });
        return { key: { id: msgId, fromMe: true, remoteJid: id } };
      } else {
        config.mimetype = "audio/mp4";
        config.audio    = Buffer.from(source);
        return _origSendMessage(id, config, etc);
      }
    }
    return _origSendMessage(id, config, etc);
  };

  gara.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      isReconnecting = false;
      console.log(chalk.green.bold(`
        
     ${botname} Terhubung!          
     Siap menerima pesan...         
        `));
    }

    if (connection === "close") {
      const reason      = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldRecon = reason !== DisconnectReason.loggedOut;
      console.log(chalk.red(`\nKoneksi terputus. Kode: ${reason}`));

      gara.ev.removeAllListeners();

      if (shouldRecon && !isReconnecting) {
        isReconnecting = true;
        console.log(chalk.yellow("Reconnecting...\n"));
        setTimeout(connect, 3000);
      } else if (!shouldRecon) {
        console.log(chalk.red("Logged out. Hapus folder session lalu restart.\n"));
      }
    }
  });

  gara.ev.on("creds.update", saveCreds);

  // Presence store
  global.presenceStore = global.presenceStore ?? new Map();
  gara.ev.on("presence.update", ({ id, presences }) => {
    for (const [jid, data] of Object.entries(presences)) {
      // Resolve @lid ke @s.whatsapp.net kalau ada
      const resolved = jid.endsWith("@lid") ? lidStore.toId(jid) : jid;
      presenceStore.set(resolved, { ...data, rawJid: jid });
      // Simpan juga dengan key asli biar bisa dicari dua cara
      if (resolved !== jid) presenceStore.set(jid, { ...data, rawJid: jid });
    }
  });

  registerLidDetector(gara);

  gara.ev.on("messages.upsert", async ({ messages, type }) => {
    try {
      if (type !== "notify" && type !== "append") return;

      const botNum = gara.user?.id?.split(":")[0];

      for (const rawMsg of messages) {
        try {
          if (type === "append") {
            const isStub      = !!rawMsg.messageStubType;
            const fromMe      = rawMsg.key?.fromMe ?? false;
            const isSelfMode  = fromMe && cfg.selfMode;
            const isBotOwner  = fromMe && isOwner(botNum);
            if (!isStub && !isSelfMode && !isBotOwner) continue;
          }

          const id = rawMsg.key?.id;
          if (!id) continue;
          if (processedIds.has(id)) continue;
          processedIds.add(id);
          setTimeout(() => processedIds.delete(id), 60_000);
          await handleMessage(gara, rawMsg);
        } catch (msgErr) {
          console.error("[messages.upsert]", msgErr.message);
        }
      }
    } catch (outerErr) {
      console.error("[messages.upsert outer]", outerErr.message);
    }
  });

  return gara;
}

async function startBot() {
  try {
    console.clear();
    console.log(chalk.cyan.bold(`
                                     
     ${chalk.white.bold(botname.padEnd(33))}
     ${chalk.dim("WhatsApp Bot  -  Spesial Edition")}         
         
    `));

    await loadCommands();

    if (fs.existsSync(session) && !fs.existsSync(`${session}/creds.json`)) {
      fs.rmSync(session, { recursive: true, force: true });
    }

    const rl = readline.createInterface({
      input : process.stdin,
      output: process.stdout,
    });

    let formatNomor = "";
    const needPairing = !fs.existsSync(`${session}/creds.json`);

    if (needPairing) {
      const nomor = await question(
        rl,
        chalk.yellow("\n╭─────────────────────────────────────────╮\n│  Masukkan nomor WA kamu (contoh: 628xxx)│\n╰─────────────────────────────────────────╯\n› ")
      );
      formatNomor = nomor.replace(/[^0-9]/g, "");
    }

    rl.close();

    const gara = await connect();

    if (needPairing && !gara.authState.creds.registered) {
      await sleep(2000);
      try {
        const code = await gara.requestPairingCode(formatNomor, "VOID9999");
        const formatted = code.match(/.{1,4}/g)?.join("-") ?? code;
        console.log(chalk.bold.rgb(255, 136, 0)(`
        
     CODE PAIRING KAMU DI BAWAH 
                                        
         ${chalk.greenBright.bold(formatted.padEnd(30))}
                                        
     ${chalk.dim("WA - Perangkat Tertaut - Tautkan")}    
     ${chalk.dim("dengan nomor telepon")}               
  
        `));
      } catch (e) {
        console.log(chalk.red("Gagal dapat pairing code, restart bot dan coba lagi."));
        console.error(e.message);
      }
    }
  } catch (error) {
    console.error(chalk.red("[ERROR]"), error);
  }
}

startBot();
process.on("uncaughtException", (e) => console.error(chalk.red("[UNCAUGHT ERROR]"), e));
