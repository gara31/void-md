import fs   from "fs";
import path from "path";
import { fileURLToPath } from "url";
import {
  generateWAMessageFromContent,
  generateWAMessageContent,
  downloadContentFromMessage,
} from "gara";
import { convertToOpus, generateWaveform } from "./handlers/ffmpeg.js";
import { imageToWebp, videoToWebp, writeExifImg, writeExifVid } from "./handlers/sticker.js";
import { uguu } from "./settings/uguu.js";
import { userStore } from "./db/userStore.js";
import { lidStore, normJid } from "./db/lidStore.js";
import {
  fetchLidParticipants, resolveJid, isLid,
  getGroupAdmins, isSuperAdmin, isAdminInList,
  getFullGroupInfo,
  getMentions, resolveMentions, toApiJid,
} from "./handlers/detector.js";

global.uguu      = uguu;
global.rpg       = userStore;
global.wallet    = userStore;
global.userStore = userStore;

global.fol = {
  0: "./handlers/",
  1: "./utils/",
  2: "./commands/",
  3: "./settings/",
  4: "./session/",
  5: "./db/",
};

const CONFIG_PATH = path.resolve(path.dirname(fileURLToPath(import.meta.url)), fol[3] + "config.json");
const _conf       = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf-8"));
await import("./settings/messages.js");

global.owner       = _conf.owner;
global.botname     = _conf.botname;
global.botfullname = _conf.botfullname;
global.botnickname = _conf.botnickname;
global.ownername   = _conf.ownername;
global.prefix      = _conf.prefix;
global.session     = _conf.session;
global.cfg         = _conf.cfg;
global.api         = _conf.api;

global.saveConfig = () => {
  try {
    const raw  = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf-8"));
    raw.cfg    = global.cfg;
    raw.prefix = global.prefix;
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(raw, null, 2));
  } catch (e) {
    console.error("[saveConfig] gagal:", e.message);
  }
};

global.imageToWebp  = imageToWebp;
global.videoToWebp  = videoToWebp;
global.writeExifImg = writeExifImg;
global.writeExifVid = writeExifVid;

global.lidStore        = lidStore;
global.normJid         = normJid;
global.fetchLidParticipants = fetchLidParticipants;
global.resolveJid      = resolveJid;
global.isLid           = isLid;
global.getGroupAdmins  = getGroupAdmins;
global.isSuperAdmin    = isSuperAdmin;
global.isAdminInList   = isAdminInList;
global.getFullGroupInfo = getFullGroupInfo;
global.getMentions     = getMentions;
global.resolveMentions = resolveMentions;
global.toApiJid        = toApiJid;

global.sleep = (ms) => new Promise((r) => setTimeout(r, ms));

global.isOwner = (number) => {
  const clean = String(number).replace(/[^0-9]/g, "").replace(/@.+/, "");
  return global.owner.includes(clean);
};

global.from = {
  group : "@g.us",
  sender: "@s.whatsapp.net",
};

global.toJid = (num) => num.replace(/[^0-9]/g, "") + global.from.sender;
global.toNum = (jid) => jid.replace(global.from.sender, "").replace(global.from.group, "");

global.download = async (msgContent, type) => {
  const stream = await downloadContentFromMessage(msgContent, type);
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
};

global.editMsg = async (gara, jid, sentKey, newText) => {
  await gara.sendMessage(jid, { text: newText, edit: sentKey });
};

global.send = async (gara, jid, quotedMsg, text, mentions = []) => {
  try {
    const built = generateWAMessageFromContent(
      jid,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body  : { text: "" },
              footer: { text: String(text ?? "") },
              nativeFlowMessage: { buttons: [] },
              ...(mentions.length > 0 ? { contextInfo: { mentionedJid: mentions } } : {}),
            },
          },
        },
      },
      {
        quoted : quotedMsg,
        userJid: quotedMsg?.key?.participant ?? quotedMsg?.key?.remoteJid ?? jid,
      }
    );
    await gara.relayMessage(jid, built.message, { messageId: built.key.id });
  } catch {
    await gara.sendMessage(
      jid,
      { text: String(text ?? ""), ...(mentions.length > 0 ? { mentions } : {}) },
      { quoted: quotedMsg }
    );
  }
};

global.sendMedia = async (gara, jid, quotedMsg, src, mime, caption, mentions = []) => {
  const isVideo = mime?.startsWith("video");

  let buf;
  if (Buffer.isBuffer(src)) {
    buf = src;
  } else {
    const res = await fetch(src);
    if (!res.ok) throw new Error("Gagal fetch media");
    buf = Buffer.from(await res.arrayBuffer());
  }

  const generated = await generateWAMessageContent(
    isVideo ? { video: buf, mimetype: mime ?? "video/mp4" }
             : { image: buf, mimetype: mime ?? "image/jpeg" },
    { upload: gara.waUploadToServer }
  );

  const mediaMsg = isVideo
    ? (generated?.videoMessage ?? null)
    : (generated?.imageMessage ?? null);

  const header = mediaMsg
    ? (isVideo
        ? { videoMessage: mediaMsg, hasMediaAttachment: true }
        : { imageMessage: mediaMsg, hasMediaAttachment: true })
    : { title: "" };

  const built = generateWAMessageFromContent(
    jid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header,
            body  : { text: "" },
            footer: { text: String(caption ?? "") },
            nativeFlowMessage: { buttons: [] },
            contextInfo: {
              stanzaId     : quotedMsg.key.id,
              participant  : quotedMsg.key.participant || quotedMsg.key.remoteJid,
              quotedMessage: quotedMsg.message,
              ...(mentions.length > 0 ? { mentionedJid: mentions } : {}),
            },
          },
        },
      },
    },
    {
      quoted  : quotedMsg,
      userJid : quotedMsg.key.participant ?? quotedMsg.key.remoteJid ?? jid,
    }
  );

  await gara.relayMessage(jid, built.message, { messageId: built.key.id });
};

global.sendAudio = async (gara, jid, quotedMsg, url) => {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Gagal download audio: ${res.status}`);
  const buf       = Buffer.from(await res.arrayBuffer());
  const converted = await convertToOpus(buf);
  const waveform  = await generateWaveform(converted);

  const msgContent = await generateWAMessageContent(
    { audio: converted, mimetype: "audio/ogg; codecs=opus", ptt: true },
    { upload: gara.waUploadToServer }
  );

  const type = Object.keys(msgContent)[0];
  msgContent[type].waveform = waveform;

  if (quotedMsg) {
    msgContent[type].contextInfo = {
      stanzaId     : quotedMsg.key.id,
      participant  : quotedMsg.key.participant || quotedMsg.key.remoteJid,
      quotedMessage: quotedMsg.message,
    };
  }

  await gara.relayMessage(jid, msgContent, {});
};

global._limitCache = new Map();
global.checkLimit  = (jid, cmdName, limit = 5) => {
  if (isOwner(jid)) return true;
  const key   = `${jid}:${cmdName}`;
  const now   = Date.now();
  const entry = global._limitCache.get(key) || { count: 0, reset: now + 60_000 };
  if (now > entry.reset) { entry.count = 0; entry.reset = now + 60_000; }
  if (entry.count >= limit) return false;
  entry.count++;
  global._limitCache.set(key, entry);
  return true;
};

global.gameStore = new Map();
global.setGame    = (jid, type, data) => global.gameStore.set(jid, { type, data, startTime: Date.now() });
global.getGame    = (jid) => global.gameStore.get(jid) ?? null;
global.deleteGame = (jid) => global.gameStore.delete(jid);
global.hasGame    = (jid) => global.gameStore.has(jid);

global.formatBytes = (bytes) => {
  if (bytes < 1024)        return bytes + " B";
  if (bytes < 1048576)     return (bytes / 1024).toFixed(2) + " KB";
  if (bytes < 1073741824)  return (bytes / 1048576).toFixed(2) + " MB";
  return (bytes / 1073741824).toFixed(2) + " GB";
};

global.formatDuration = (ms) => {
  if (typeof ms !== "number" || !Number.isFinite(ms)) throw new TypeError("Expected a finite number");
  return {
    days   : Math.trunc(ms / 86_400_000),
    hours  : Math.trunc((ms / 3_600_000) % 24),
    minutes: Math.trunc((ms / 60_000) % 60),
    seconds: Math.trunc((ms / 1000) % 60),
    ms     : Math.trunc(ms % 1000),
  };
};

global.getWaktu = (timezone = "Asia/Jakarta") => {
  const days   = ["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"];
  const months = ["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
  const now    = new Date(new Date().toLocaleString("en-US", { timeZone: timezone }));
  const weton  = ["Legi","Pahing","Pon","Wage","Kliwon"][(now.getDay() + now.getMonth() + now.getFullYear()) % 5];
  const hh     = String(now.getHours()).padStart(2, "0");
  const mm     = String(now.getMinutes()).padStart(2, "0");
  const ss     = String(now.getSeconds()).padStart(2, "0");
  return `${days[now.getDay()]} ${weton}, ${String(now.getDate()).padStart(2,"0")} ${months[now.getMonth()]} ${now.getFullYear()}, ${hh}:${mm}:${ss}`;
};

global.dateFormatter = (time, timezone = "Asia/Jakarta") => {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).formatToParts(new Date(time));
  const p = (type) => parts.find(x => x.type === type).value;
  return `${p("day")}/${p("month")}/${p("year")} ${p("hour")}:${p("minute")}:${p("second")}`;
};

global.parseTimeString = (timeStr) => {
  const units = {
    s:1000, second:1000, seconds:1000, detik:1000,
    m:60000, minute:60000, minutes:60000, menit:60000,
    h:3600000, hour:3600000, hours:3600000, jam:3600000,
    d:86400000, day:86400000, days:86400000, hari:86400000,
    w:604800000, week:604800000, weeks:604800000, minggu:604800000,
    mo:2592000000, month:2592000000, bulan:2592000000,
    y:31536000000, year:31536000000, tahun:31536000000,
  };
  const regex = /(\d+)\s*(second|seconds|detik|minute|minutes|menit|hour|hours|jam|day|days|hari|week|weeks|minggu|month|mo|bulan|year|tahun|s|m|h|d|w|y)/gi;
  let total = 0, found = false, match;
  while ((match = regex.exec(timeStr)) !== null) {
    found = true;
    const unit = match[2].toLowerCase();
    if (!units[unit]) return false;
    total += parseInt(match[1]) * units[unit];
  }
  return found && total > 0 ? total : false;
};

global.getSystemStats = () => {
  const mem = process.memoryUsage();
  const up  = process.uptime() * 1000;
  const { days, hours, minutes, seconds } = formatDuration(up);
  return {
    ram   : { used: formatBytes(mem.heapUsed), total: formatBytes(mem.heapTotal), rss: formatBytes(mem.rss) },
    uptime: `${days}d ${hours}j ${minutes}m ${seconds}s`,
    pid   : process.pid,
  };
};

global.compareTwoStrings = (a, b) => {
  a = a.replace(/\s+/g, "");
  b = b.replace(/\s+/g, "");
  if (a === b) return 1;
  if (a.length < 2 || b.length < 2) return 0;
  const bigrams = new Map();
  for (let i = 0; i < a.length - 1; i++) {
    const bg = a.substring(i, i + 2);
    bigrams.set(bg, (bigrams.get(bg) || 0) + 1);
  }
  let hit = 0;
  for (let i = 0; i < b.length - 1; i++) {
    const bg = b.substring(i, i + 2);
    if (bigrams.get(bg) > 0) { bigrams.set(bg, bigrams.get(bg) - 1); hit++; }
  }
  return (2 * hit) / (a.length + b.length - 2);
};

global.findBestMatch = (query, list) => {
  const ratings = list.map(t => ({ target: t, rating: compareTwoStrings(query, t) }));
  const best    = ratings.reduce((a, b) => b.rating > a.rating ? b : a);
  return { ratings, bestMatch: best };
};

global.parseLink = (text = "") => {
  return (
    text.match(/(https?:\/\/)?[^\s]+\.(com|net|org|id|co|io|ai|app|dev|tech|xyz|info|me|tv|live|online|site|store|shop|link)(\/[^\s]*)?/gi) ||
    text.match(/https?:\/\/[^\s)]+/g) ||
    []
  ).map(u => (u.startsWith("http") ? u : "https://" + u).replace(/['"`<>]/g, ""));
};

global.getRandomItem  = (arr) => arr[Math.floor(Math.random() * arr.length)];
global.getRandomValue = (min, max) => min + Math.random() * (max - min);

export default true;
