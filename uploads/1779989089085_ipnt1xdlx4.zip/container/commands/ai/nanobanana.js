export default {
  cmd   : ["edit", "imageedit"],
  tag   : "ai",
  desc  : "Edit gambar dengan AI menggunakan prompt",
  isArgs: "❗Contoh: _!edit jadikan seperti anime_",

  async run(m) {
    if (!m.isImage) return m.reply("❗ kirim atau reply foto dulu baru kasih promptnya");
    await m.reply(msg.common.wait);

    try {
      const imageUrl  = await uguu(await m.download());
      const res       = await fetch(`https://api-faa.my.id/faa/editfoto?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(m.q)}`);
      const ct        = res.headers.get("content-type") ?? "";

      if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`);

      let image;
      if (ct.includes("application/json")) {
        const data = await res.json();
        if (!data.status) throw new Error(data?.message || "API gagal");
        image = { url: data.result ?? data.url ?? data.image };
      } else if (ct.startsWith("image/")) {
        image = Buffer.from(await res.arrayBuffer());
      } else {
        throw new Error("respon API tidak dikenal");
      }

      await m.reply({ image });
    } catch (e) {
      m.reply(msg.common.error(e));
    }
  },
};
