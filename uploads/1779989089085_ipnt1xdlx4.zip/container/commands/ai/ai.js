async function callGpt(prompt) {
  const res = await fetch(`${api.xterm.url}/api/chat/gpt?key=${api.xterm.key}`, {
    method : "POST",
    headers: { "Content-Type": "application/json" },
    body   : JSON.stringify({ messages: [{ role: "user", content: prompt }] }),
  }).then(r => r.json()).catch(() => null);
  return res?.response ?? null;
}

async function callBard(prompt) {
  const res = await fetch(`${api.xterm.url}/api/chat/bard?query=${encodeURIComponent(prompt)}&key=${api.xterm.key}`)
    .then(r => r.json()).catch(() => null);
  return res?.chatUi ?? null;
}

export default {
  cmd   : ["ai"],
  tag   : "ai",
  desc  : "Chat dengan AI",
  isArgs: "❗ketik pertanyaannya dulu!",

  async run(m) {
    await m.reply(msg.common.wait);

    const result = await callGpt(m.q) ?? await callBard(m.q);

    if (!result) return m.reply("❗ AI sedang tidak tersedia, coba lagi nanti.");

    await m.reply(result);
  },
};