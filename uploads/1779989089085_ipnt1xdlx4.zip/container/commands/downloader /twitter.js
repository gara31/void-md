import axios from "axios";
import * as cheerio from "cheerio";

async function scrapeTwitter(url) {
  const { data: html } = await axios.get("https://snaptwitter.com/");
  const $tok = cheerio.load(html);
  const token = $tok('input[name="token"]').attr("value") || "";

  const res = await axios.post(
    "https://snaptwitter.com/action.php",
    new URLSearchParams({ url, token }).toString(),
    { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
  );

  const $ = cheerio.load(res.data.data);
  const downloadLink = $(".abuttons a").attr("href");

  if (!downloadLink || downloadLink === "undefined") throw new Error("link video tidak ditemukan");

  return { downloadLink };
}

export default {
  cmd: ["twitter", "tw", "twdl", "x"],
  tag: "downloader",
  desc: "Download video Twitter / X",
  isArgs: "mana url twitter nya",
  formats: ["twitter.com", "x.com", "t.co"],

  async run(m) {
    await m.reply(msg.common.wait);

    let data;
    try {
      data = await scrapeTwitter(m.q.trim());
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    await m.reply({ video: { url: data.downloadLink } });
  },
};
