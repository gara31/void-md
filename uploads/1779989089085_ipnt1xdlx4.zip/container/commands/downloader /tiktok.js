import * as cheerio from "cheerio";

async function savetik(url) {
  const body = new URLSearchParams({
    q: url,
    cursor: "0",
    page: "0",
    lang: "id",
  }).toString();

  const res = await fetch("https://savetik.io/api/ajaxSearch", {
    method: "POST",
    headers: {
      "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
      "x-requested-with": "XMLHttpRequest",
      "user-agent": "Mozilla/5.0",
      origin: "https://savetik.io",
      referer: "https://savetik.io/id/download-tiktok-photos",
      accept: "*/*",
    },
    body,
  });

  const json = await res.json();
  const html = typeof json.data === "string" ? json.data : "";

  if (!html) throw new Error("Gagal mengambil data.");

  const $ = cheerio.load(html);

  const mp4 =
    $('a:contains("Unduh MP4 [1]")').attr("href") ||
    $('a:contains("Unduh MP4 [2]")').attr("href") ||
    $('a:contains("Unduh MP4 HD")').attr("href") ||
    null;

  const mp3 = $('a:contains("Unduh MP3")').attr("href") || null;

  const images = [];
  $(".photo-list ul.download-box li").each((_, el) => {
    const img = $(el).find("a[title='Unduh Gambar']").attr("href");
    if (img) images.push(img);
  });

  if (!mp4 && images.length === 0) throw new Error("Media tidak ditemukan.");

  return {
    type: images.length > 0 ? "slideshow" : "video",
    urls: images.length > 0 ? images : [mp4],
    audio: mp3 || null,
  };
}

export default {
  cmd: ["tt", "ttdl", "tiktok"],
  tag: "downloader",
  desc: "Download video atau slideshow TikTok",
  isArgs: "❗mana url tiktok nya",
  formats: ["tiktok.com", "vm.tiktok", "vt.tiktok", "douyin.com"],

  async run(m) {
    await m.reply(msg.common.wait);

    let data;
    try {
      data = await savetik(m.q.trim());
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    if (data.type === "video") {
      await m.reply({ video: { url: data.urls[0] } });
    } else if (data.type === "slideshow") {
      for (const imgUrl of data.urls) {
        await m.reply({ image: { url: Array.isArray(imgUrl) ? imgUrl[0] : imgUrl } });
        await sleep(1000);
      }
    }

    if (data.audio) {
      await m.reply({ audio: { url: data.audio }, mimetype: "audio/mpeg" });
    }
  },
};
