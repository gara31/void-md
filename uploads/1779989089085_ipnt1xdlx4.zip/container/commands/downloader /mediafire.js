import axios from "axios";

async function mediafireScrape(url) {
  const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Referer": "https://www.mediafire.com/",
  };

  const res = await axios.get(url, { timeout: 30000, headers });
  const html = res.data;

  const extract = (html) => {
    const nameMatch = html.match(/<div class="filename">([^<]+)<\/div>|<h1 class="filename">([^<]+)<\/h1>|<title>([^-]+) -/i);
    const fileName = nameMatch ? (nameMatch[1] || nameMatch[2] || nameMatch[3] || "").trim() : "Unknown";

    const sizeMatch = html.match(/<li>File size: <span>([^<]+)<\/span><\/li>|(\d+\.?\d*\s*[KMGT]?B)/i);
    const fileSize = sizeMatch ? (sizeMatch[1] || sizeMatch[2] || "").trim() : "Unknown";

    let downloadLink = null;

    const m1 = html.match(/href="(https?:\/\/download\d+\.mediafire\.com[^"]+)"/i);
    if (m1) downloadLink = m1[1];

    if (!downloadLink) {
      const m2 = html.match(/data-scrambled-url="([^"]+)"/i);
      if (m2) {
        try { downloadLink = Buffer.from(m2[1], "base64").toString("utf-8"); } catch {}
      }
    }

    if (!downloadLink) {
      const m3 = html.match(/kNO\s*=\s*"([^"]+)"/i);
      if (m3) downloadLink = m3[1];
    }

    return { fileName, fileSize, downloadLink };
  };

  let info = extract(html);

  if (!info.downloadLink) {
    const btnMatch = html.match(/id="downloadButton"[^>]*onclick="([^"]+)"/i);
    if (btnMatch) {
      const urlInFunc = btnMatch[1].match(/(https?:\/\/[^'"\s]+)/i);
      if (urlInFunc) info.downloadLink = urlInFunc[1];
    }

    if (!info.downloadLink) {
      try {
        const fallback = await axios.post(url, {}, { timeout: 20000, headers: { ...headers, "Content-Type": "application/x-www-form-urlencoded", "Referer": url } });
        const fallbackInfo = extract(fallback.data);
        if (fallbackInfo.downloadLink) info.downloadLink = fallbackInfo.downloadLink;
      } catch {}
    }
  }

  if (!info.downloadLink) throw new Error("link download tidak ditemukan");

  const extMatch = info.fileName?.match(/\.([a-zA-Z0-9]+)$/);
  const fileExtension = extMatch ? extMatch[1].toLowerCase() : "";
  const mimeTypeMap = {
    zip: "application/zip",
    rar: "application/x-rar-compressed",
    mp4: "video/mp4",
    mp3: "audio/mpeg",
    pdf: "application/pdf",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    txt: "text/plain",
    exe: "application/x-msdownload",
    apk: "application/vnd.android.package-archive",
  };

  return {
    fileName: info.fileName,
    fileSize: info.fileSize,
    downloadLink: info.downloadLink,
    mimeType: mimeTypeMap[fileExtension] || "application/octet-stream",
    fileExtension,
  };
}

export default {
  cmd: ["mediafire", "mediafiredl", "mf"],
  tag: "downloader",
  desc: "Download file dari MediaFire",
  isArgs: "❗mana url mediafire nya",
  formats: ["mediafire.com"],

  async run(m) {
    await m.reply(msg.common.wait);

    let data;
    try {
      data = await mediafireScrape(m.q.trim());
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    const fileName = data.fileName.includes(".") ? data.fileName : `${data.fileName}.zip`;

    await m.reply({
      document: { url: data.downloadLink },
      mimetype: data.mimeType,
      fileName,
    });
  },
};
