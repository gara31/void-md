async function method1_xterm(url) {
  const res = await fetch(`${api.xterm.url}/api/downloader/facebook?url=${url}&key=${api.xterm.key}`).then(r => r.json());
  if (!res.data || !res.data.urls) throw new Error(res.message || "gagal ambil video");
  return { videoUrl: res.data.urls.hd || res.data.urls.sd };
}

export default {
  cmd: ["fb", "fbdl", "facebook"],
  tag: "downloader",
  desc: "Download video Facebook",
  isArgs: "❗mana url facebook nya",
  formats: ["facebook.com", "fb.watch", "fb.com"],

  async run(m) {
    await m.reply(msg.common.wait);

    let data;
    try {
      data = await method1_xterm(m.q.trim());
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    if (!data.videoUrl) return m.reply(msg.common.notFound);
    await m.reply({ video: { url: data.videoUrl }, mimetype: "video/mp4" });
  },
};
