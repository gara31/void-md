import vm from "vm";
import axios from "axios";
import * as cheerio from "cheerio";

async function method1_scraper(url) {
  const token = await axios.post(
    "https://savevid.net/api/userverify",
    `url=${encodeURIComponent(url)}`,
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36",
        "Referer": "https://savevid.net/id/instagram-video-downloader",
      },
    }
  ).then(r => r.data.token);

  const res = await axios.post(
    "https://v3.savevid.net/api/ajaxSearch",
    `q=${encodeURIComponent(url)}&t=media&lang=id&v=v2&cftoken=${token}`,
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Accept": "*/*",
      },
    }
  );

  const code = res.data.data;

  if (typeof code === "string" && code.includes("<ul")) {
    const $ = cheerio.load(code);
    const images = [];
    $("li").each((_, el) => {
      const href = $(el).find('a[id^="photo_dl_"]').attr("href");
      if (href && href.includes("snapcdn")) images.push(href);
    });
    if (!images.length) throw new Error("Tidak ada konten valid dari Scraper");
    return { type: "slideshow", urls: images };
  }

  const results = [];
  const sandbox = {
    String, Array, Object, Number, Boolean, Math, Date, RegExp, JSON,
    parseInt, parseFloat, isNaN, isFinite,
    decodeURI, decodeURIComponent, encodeURI, encodeURIComponent,
    window: { location: { hostname: "savevid.net" } },
    document: {
      write: (html) => results.push(html),
      getElementById: () => ({ set innerHTML(html) { results.push(html); } }),
      body: {},
      createElement: () => ({
        setAttribute() {}, appendChild() {},
        set innerHTML(html) { results.push(html); },
      }),
    },
    console,
  };

  vm.createContext(sandbox);
  vm.runInContext(code, sandbox);

  const allHTML = results.join("");
  const urls = (allHTML.match(/https?:\/\/[^\s"'<>]+/g) || []).filter(u => u.includes("snapcdn"));
  const videos = urls.filter(u => u.includes(".mp4") || u.includes("download"));

  if (!videos[0] && !videos[1]) throw new Error("Tidak ada konten valid dari Scraper");
  return { type: "video", urls: [videos[1] || videos[0]] };
}

async function method2_betabotz(url) {
  const res = await fetch(`https://api.betabotz.eu.org/api/download/igdowloader?url=${url}&apikey=gara`).then(r => r.json());
  if (!res.message || !res.message.length) throw new Error("Tidak ada data dari BetaBotz");
  const urls = res.message.map(i => i._url).filter(Boolean);
  if (!urls.length) throw new Error("Tidak ada konten valid dari BetaBotz");
  return { type: "video", urls };
}

export default {
  cmd: ["ig", "igdl", "instagram"],
  tag: "downloader",
  desc: "Download foto atau video Instagram",
  isArgs: "❗mana url instagram nya",
  formats: ["instagram.com", "instagr.am"],

  async run(m) {
    await m.reply(msg.common.wait);

    const url = m.q.trim();
    const methods = [
      { name: "Scraper",  fn: () => method1_scraper(url) },
      { name: "BetaBotz", fn: () => method2_betabotz(url) },
    ];

    let data;
    for (let i = 0; i < methods.length; i++) {
      try {
        data = await methods[i].fn();
        break;
      } catch (e) {
        if (i === methods.length - 1) return m.reply(msg.common.error(e));
      }
    }

    if (data.type === "video") {
      await m.reply({ video: { url: data.urls[0] } });
    } else if (data.type === "slideshow") {
      for (const imgUrl of data.urls) {
        await m.reply({ image: { url: imgUrl } });
        await sleep(1000);
      }
    }
  },
};
