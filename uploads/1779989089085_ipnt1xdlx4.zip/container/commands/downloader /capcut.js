import axios from "axios";
import { CookieJar } from "tough-cookie";
import { wrapper } from "axios-cookiejar-support";
import * as cheerio from "cheerio";

const jar = new CookieJar();
const client = wrapper(axios.create({ jar }));

async function getTemplateId(url) {
  const res = await client.get(encodeURI(url), {
    headers: {
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
      "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
      "upgrade-insecure-requests": "1",
    },
    maxRedirects: 10,
    validateStatus: (s) => s >= 200 && s < 400,
  });

  const redirectedUrl = res.request.res.responseUrl || url;

  const m1 = redirectedUrl.match(/\/template-detail\/(?:[a-zA-Z0-9-]+)?\/(\d+)|\/templates\/(\d+)/);
  if (m1) return m1[1] || m1[2];

  const m2 = redirectedUrl.match(/\/template-detail\/([a-zA-Z0-9-]+)/);
  if (m2) return m2[1];

  const templateIdParam = new URLSearchParams(new URL(redirectedUrl).search).get("template_id");
  if (templateIdParam) return templateIdParam;

  return null;
}

async function capcutdl(url) {
  const templateId = await getTemplateId(url);
  if (!templateId) throw new Error("template id tidak ditemukan");

  const res = await axios.get(`https://www.capcut.com/templates/${templateId}`, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    },
  });

  const $ = cheerio.load(res.data);
  let videoData = null;

  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      videoData = JSON.parse($(el).html());
      return false;
    } catch {}
  });

  if (!videoData || !videoData.contentUrl) throw new Error("link video tidak ditemukan");
  return videoData;
}

export default {
  cmd: ["capcut", "capcutdl"],
  tag: "downloader",
  desc: "Download video CapCut",
  isArgs: "mana url capcut nya",
  formats: ["capcut.com"],

  async run(m) {
    await m.reply(msg.common.wait);

    let data;
    try {
      data = await capcutdl(m.q.trim());
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    await m.reply({ video: { url: data.contentUrl } });
  },
};
