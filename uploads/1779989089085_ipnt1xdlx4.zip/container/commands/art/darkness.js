import { createCanvas, loadImage } from "canvas";

export default {
  cmd    : ["darkness", "dark"],
  tag    : "art",
  desc   : "Gelapkan gambar",
  isImage: "❗kirim atau reply gambar dulu!",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const amount = parseInt(m.args[0]) || 75;
      if (amount < 0 || amount > 255) return m.reply("❗ amount harus antara 0-255");

      const buf    = await m.download();
      const img    = await loadImage(buf);
      const canvas = createCanvas(img.width, img.height);
      const ctx    = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0);

      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < imgData.data.length; i += 4) {
        imgData.data[i]     = Math.max(0, imgData.data[i]     - amount);
        imgData.data[i + 1] = Math.max(0, imgData.data[i + 1] - amount);
        imgData.data[i + 2] = Math.max(0, imgData.data[i + 2] - amount);
      }
      ctx.putImageData(imgData, 0, 0);

      const result = canvas.toBuffer("image/png");
      const url    = await uguu(result);

      await m.reply({ image: { url }, caption: "" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};