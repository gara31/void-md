import sharp from "sharp";

export default {
  cmd    : ["blur"],
  tag    : "art",
  desc   : "Blur gambar",
  isImage: "❗kirim atau reply gambar dulu!",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const buf    = await m.download();
      const result = await sharp(buf)
        .blur(10)
        .toBuffer();

      await m.reply({ image: result, caption: "" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};