import axios           from "axios";
import * as path       from "path";
import { Jimp }        from "jimp";
import { fileTypeFromBuffer } from "file-type";
import FormData        from "form-data";

class CompressImageAPI {
  constructor() {
    this.api      = null;
    this.server   = null;
    this.taskId   = null;
    this.token    = null;
    this.height   = null;
    this.width    = null;
  }

  async getTaskId() {
    const { data: html } = await axios.get("https://www.iloveimg.com/blur-face", { timeout: 10000 });

    const tokenMatches = html.match(/(ey[a-zA-Z0-9?%-_/]+)/g);
    if (!tokenMatches || tokenMatches.length < 2) throw new Error("Token tidak ditemukan");
    this.token = tokenMatches[1];

    const configMatch = html.match(/var ilovepdfConfig = ({.*?});/s);
    if (!configMatch) throw new Error("Server config tidak ditemukan");

    const configJson = JSON.parse(configMatch[1]);
    const servers    = configJson.servers;
    if (!Array.isArray(servers) || servers.length === 0) throw new Error("Server list kosong");

    this.server = servers[Math.floor(Math.random() * servers.length)];
    this.taskId = html.match(/taskId\s*=\s*'(\w+)/)?.[1];
    if (!this.taskId) throw new Error("Task ID tidak ditemukan");

    this.api = axios.create({ baseURL: `https://${this.server}.iloveimg.com`, timeout: 30000 });
    this.api.defaults.headers.common["Authorization"] = `Bearer ${this.token}`;
  }

  async uploadFromFile(fileBuffer, fileName) {
    const fileType = await fileTypeFromBuffer(fileBuffer);
    if (!fileType || !fileType.mime.startsWith("image/")) throw new Error("File bukan gambar yang valid");

    const image   = await Jimp.read(fileBuffer);
    this.width    = image.bitmap.width;
    this.height   = image.bitmap.height;

    const form = new FormData();
    form.append("name",           fileName);
    form.append("chunk",          "0");
    form.append("chunks",         "1");
    form.append("task",           this.taskId);
    form.append("preview",        "1");
    form.append("pdfinfo",        "0");
    form.append("pdfforms",       "0");
    form.append("pdfresetforms",  "0");
    form.append("v",              "web.0");
    form.append("file", fileBuffer, { filename: fileName, contentType: fileType.mime });

    const response = await this.api.post("/v1/upload", form, {
      headers: { ...form.getHeaders(), "Content-Length": form.getLengthSync() },
    });
    return response.data;
  }

  async processImage(serverFilename, originalFilename) {
    const form = new FormData();
    form.append("packaged_filename",          "iloveimg-blurred");
    form.append("width",                      this.width);
    form.append("height",                     this.height);
    form.append("level",                      "recommended");
    form.append("mode",                       "include");
    form.append("task",                       this.taskId);
    form.append("tool",                       "blurfaceimage");
    form.append("files[0][server_filename]",  serverFilename);
    form.append("files[0][filename]",         originalFilename);

    await this.api.post("/v1/process", form, {
      headers: { ...form.getHeaders(), "Content-Length": form.getLengthSync() },
    });

    const downloadResponse = await this.api.get(`/v1/download/${this.taskId}`, { responseType: "arraybuffer" });
    return downloadResponse.data;
  }
}

export default {
  cmd    : ["blurface", "bf"],
  tag    : "art",
  desc   : "Blur wajah dalam gambar otomatis",
  isImage: "❗kirim atau reply gambar dulu!",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const buf      = await m.download();
      const fileType = await fileTypeFromBuffer(buf);
      const fileName = `image.${fileType?.ext || "jpg"}`;

      const compressor = new CompressImageAPI();
      await compressor.getTaskId();

      const uploadResult = await compressor.uploadFromFile(buf, fileName);
      if (!uploadResult?.server_filename) throw new Error("Gagal upload gambar");

      const result = await compressor.processImage(uploadResult.server_filename, fileName);
      const url    = await uguu(Buffer.from(result));

      await m.reply({ image: { url }, caption: "" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};