import { createCanvas, loadImage } from "canvas";

export default {
  cmd    : ["circle"],
  tag    : "art",
  desc   : "Crop gambar jadi lingkaran",
  isImage: "❗kirim atau reply gambar dulu!",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const buf    = await m.download();
      const img    = await loadImage(buf);
      const canvas = createCanvas(img.width, img.height);
      const ctx    = canvas.getContext("2d");

      ctx.drawImage(img, 0, 0);
      ctx.globalCompositeOperation = "destination-in";
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, Math.min(canvas.width, canvas.height) / 2, 0, Math.PI * 2);
      ctx.closePath();
      ctx.fill();

      const result = canvas.toBuffer("image/png");
      const url    = await uguu(result);

      await m.reply({ image: { url }, caption: "" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};