import { createCanvas, loadImage } from "canvas";
import assets from "@putuofc/assetsku";

export default {
  cmd    : ["beautiful"],
  tag    : "art",
  desc   : "Beautiful effect pada gambar",
  isImage: "❗kirim atau reply gambar dulu!",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const buf    = await m.download();
      const img    = await loadImage(buf);
      const base   = await loadImage(assets.image.get("BEAUTIFUL"));
      const canvas = createCanvas(376, 400);
      const ctx    = canvas.getContext("2d");

      ctx.drawImage(base, 0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 258, 28, 84, 95);
      ctx.drawImage(img, 258, 229, 84, 95);

      const result = canvas.toBuffer("image/png");
      const url    = await uguu(result);

      await m.reply({ image: { url }, caption: "" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};