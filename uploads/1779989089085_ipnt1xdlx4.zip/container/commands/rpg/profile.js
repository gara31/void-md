import { createCanvas, loadImage, registerFont } from "canvas";
import { createRequire }                          from "module";
import { existsSync }                             from "fs";
import path                                       from "path";
import sharp                                      from "sharp";

const require   = createRequire(import.meta.url);
registerFont("./fonts/unifont.otf",       { family: "Unifont" });
registerFont("./fonts/unifont_upper.otf", { family: "UnifontUpper" });
const emojiData = require("emoji-datasource-apple/emoji.json");

const FALLBACK_PP = "https://c.termai.cc/i48/GNf3g9b.jpg";
const EMOJI_BASE  = path.dirname(require.resolve("emoji-datasource-apple/package.json"));

const emojiMap = new Map(
  emojiData
    .filter(e => e.has_img_apple)
    .map(e => [e.unified.toLowerCase(), e])
);

function getUnified(char) {
  const pts  = [...char].map(c => c.codePointAt(0).toString(16).padStart(4, "0"));
  const full = pts.join("-");
  return emojiMap.has(full) ? full : emojiMap.has(pts[0]) ? pts[0] : null;
}

const imgCache = new Map();
async function emojiImg(unified) {
  if (imgCache.has(unified)) return imgCache.get(unified);
  const p   = path.join(EMOJI_BASE, "img", "apple", "64", `${unified}.png`);
  const img = existsSync(p) ? await loadImage(p).catch(() => null) : null;
  imgCache.set(unified, img);
  return img;
}

const EMOJI_RE = /(\p{Emoji_Presentation}|\p{Extended_Pictographic})/gu;

function parseParts(text) {
  const parts = [];
  let last = 0, m;
  EMOJI_RE.lastIndex = 0;
  while ((m = EMOJI_RE.exec(text)) !== null) {
    if (m.index > last) parts.push({ t: true,  v: text.slice(last, m.index) });
    parts.push({ t: false, v: m[0] });
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push({ t: true, v: text.slice(last) });
  return parts;
}

function measureFull(ctx, parts, sz) {
  return parts.reduce((w, p) => w + (p.t ? ctx.measureText(p.v).width : sz + 2), 0);
}

async function drawText(ctx, text, x, y, sz = 28) {
  const parts = parseParts(text);
  const align = ctx.textAlign;
  const total = measureFull(ctx, parts, sz);
  let cx = align === "center" ? x - total / 2 : align === "right" ? x - total : x;
  ctx.textAlign = "left";
  for (const p of parts) {
    if (p.t) {
      ctx.fillText(p.v, cx, y);
      cx += ctx.measureText(p.v).width;
    } else {
      const u   = getUnified(p.v);
      const img = u ? await emojiImg(u) : null;
      if (img) { ctx.drawImage(img, cx, y - sz * 0.78, sz, sz); cx += sz + 2; }
      else     { ctx.fillText(p.v, cx, y); cx += ctx.measureText(p.v).width; }
    }
  }
  ctx.textAlign = align;
}

function fmt(n) { return Number(n).toLocaleString("id-ID"); }

async function fetchAvatar(gara, sender) {
  try {
    const url = await gara.profilePictureUrl(sender, "image");
    const res = await fetch(url);
    if (!res.ok) throw 0;
    return Buffer.from(await res.arrayBuffer());
  } catch {
    return Buffer.from(await (await fetch(FALLBACK_PP)).arrayBuffer());
  }
}

function noise(ctx, W, H) {
  const imageData = ctx.getImageData(0, 0, W, H);
  const data      = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    const v    = (Math.random() - 0.5) * 12;
    data[i]     = Math.min(255, Math.max(0, data[i]     + v));
    data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + v));
    data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + v));
  }
  ctx.putImageData(imageData, 0, 0);
}

function softBlob(ctx, W, H, x, y, r, c0, c1 = "rgba(0,0,0,0)") {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, c0);
  g.addColorStop(1, c1);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}

async function buildCard(user, progress, needed, avatarBuf) {
  const W = 1080, H = 1180;
  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext("2d");

  const C = {
    haze    : "rgba(210,200,235,1)",
    text    : "rgba(38,28,72,0.97)",
    sub     : "rgba(80,60,120,0.85)",
    lavender: "rgba(110,80,180,1)",
    rose    : "rgba(185,80,120,1)",
    mint    : "rgba(40,160,130,1)",
    cream   : "rgba(160,100,40,1)",
    gold    : "rgba(200,150,30,1)",
    stroke  : "rgba(180,160,210,0.35)",
    bar_bg  : "rgba(180,160,210,0.22)",
    dim     : "rgba(80,60,120,0.6)",
    deep    : "rgba(60,40,110,1)",
  };

  ctx.fillStyle = C.haze;
  ctx.fillRect(0, 0, W, H);

  softBlob(ctx, W, H, W * 0.2,  H * 0.15, 420, "rgba(200,185,235,0.7)");
  softBlob(ctx, W, H, W * 0.85, H * 0.1,  360, "rgba(220,185,210,0.55)");
  softBlob(ctx, W, H, W * 0.5,  H * 0.55, 500, "rgba(185,215,220,0.45)");
  softBlob(ctx, W, H, W * 0.1,  H * 0.8,  320, "rgba(215,195,230,0.5)");
  softBlob(ctx, W, H, W * 0.9,  H * 0.85, 350, "rgba(230,200,215,0.5)");
  softBlob(ctx, W, H, W * 0.5,  H * 0.5,  W * 0.7, "rgba(255,255,255,0.18)");

  ctx.strokeStyle = "rgba(200,185,230,0.28)";
  ctx.lineWidth   = 1;
  for (let x = 0; x < W; x += 80) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
  }
  for (let y = 0; y < H; y += 80) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
  }

  for (let i = 0; i < 28; i++) {
    const px = Math.random() * W, py = Math.random() * H;
    const pr = Math.random() * 2.5 + 0.5, pa = Math.random() * 0.35 + 0.1;
    ctx.beginPath();
    ctx.arc(px, py, pr, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(180,160,220,${pa})`;
    ctx.fill();
  }

  const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.25, W / 2, H / 2, H * 0.78);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(90,70,130,0.18)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  ctx.beginPath();
  ctx.roundRect(40, 40, W - 80, H - 80, 36);
  ctx.strokeStyle = C.stroke;
  ctx.lineWidth   = 1.5;
  ctx.stroke();
  ctx.fillStyle   = "rgba(255,255,255,0.10)";
  ctx.fill();

  ctx.beginPath();
  ctx.roundRect(56, 56, W - 112, H - 112, 28);
  ctx.strokeStyle = "rgba(255,255,255,0.22)";
  ctx.lineWidth   = 1;
  ctx.stroke();

  const AX = W / 2, AY = 296, AR = 172;

  ctx.save();
  const ringG = ctx.createLinearGradient(AX - AR, AY - AR, AX + AR, AY + AR);
  ringG.addColorStop(0, C.lavender);
  ringG.addColorStop(0.5, C.rose);
  ringG.addColorStop(1, C.mint);
  ctx.beginPath();
  ctx.arc(AX, AY, AR + 7, 0, Math.PI * 2);
  ctx.strokeStyle = ringG;
  ctx.lineWidth   = 4;
  ctx.shadowBlur  = 30;
  ctx.shadowColor = "rgba(182,162,220,0.7)";
  ctx.stroke();
  ctx.restore();

  ctx.beginPath();
  ctx.arc(AX, AY, AR + 14, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(255,255,255,0.28)";
  ctx.lineWidth   = 1;
  ctx.stroke();

  ctx.save();
  ctx.beginPath();
  ctx.arc(AX, AY, AR, 0, Math.PI * 2);
  ctx.clip();
  try {
    const img = await loadImage(
      await sharp(avatarBuf).resize(AR * 2, AR * 2).jpeg({ quality: 92 }).toBuffer()
    );
    ctx.drawImage(img, AX - AR, AY - AR, AR * 2, AR * 2);
    ctx.fillStyle = "rgba(200,185,230,0.12)";
    ctx.fillRect(AX - AR, AY - AR, AR * 2, AR * 2);
  } catch {
    ctx.fillStyle = "rgba(200,185,230,0.4)";
    ctx.fillRect(AX - AR, AY - AR, AR * 2, AR * 2);
  }
  ctx.restore();

  const shimG = ctx.createLinearGradient(AX - AR, AY - AR, AX + AR, AY + AR);
  shimG.addColorStop(0, "rgba(255,255,255,0.18)");
  shimG.addColorStop(0.5, "rgba(255,255,255,0.04)");
  shimG.addColorStop(1, "rgba(255,255,255,0.10)");
  ctx.save();
  ctx.beginPath();
  ctx.arc(AX, AY, AR, 0, Math.PI * 2);
  ctx.clip();
  ctx.fillStyle = shimG;
  ctx.fillRect(AX - AR, AY - AR, AR * 2, AR * 2);
  ctx.restore();

  ctx.fillStyle = C.text;
  ctx.font      = "bold 58px monospace, 'Unifont', 'UnifontUpper'";
  ctx.textAlign = "center";
  await drawText(ctx, user.name || "Unknown", W / 2, AY + AR + 68, 54);

  const role = user.role || "Newbie";
  ctx.font      = "bold 22px monospace, 'Unifont', 'UnifontUpper'";
  ctx.textAlign = "left";
  const bW = ctx.measureText(role).width + 48, bH = 42;
  const bX = W / 2 - bW / 2, bY = AY + AR + 86;

  const pillG = ctx.createLinearGradient(bX, bY, bX + bW, bY + bH);
  pillG.addColorStop(0, "rgba(182,162,220,0.75)");
  pillG.addColorStop(1, "rgba(220,170,190,0.75)");
  ctx.beginPath();
  ctx.roundRect(bX, bY, bW, bH, 21);
  ctx.fillStyle   = pillG;
  ctx.shadowBlur  = 18;
  ctx.shadowColor = "rgba(182,162,220,0.5)";
  ctx.fill();
  ctx.shadowBlur  = 0;
  ctx.strokeStyle = "rgba(255,255,255,0.45)";
  ctx.lineWidth   = 1;
  ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.font      = "bold 22px monospace, 'Unifont', 'UnifontUpper'";
  ctx.textAlign = "center";
  ctx.fillText(role, W / 2, bY + 29);

  ctx.textAlign = "left";
  const stats = [
    ["LEVEL",    String(user.level || 0), C.lavender, "rgba(182,162,220,0.42)"],
    ["TOTAL XP", fmt(user.exp || 0),      C.mint,     "rgba(160,210,200,0.38)"],
    ["XP PROG",  fmt(progress),           C.rose,     "rgba(220,170,190,0.38)"],
    ["NEXT LVL", `${fmt(needed)} XP`,     C.cream,    "rgba(220,185,150,0.35)"],
  ];
  const SW = 455, SH = 112, SG = 22;
  const gridX = (W - SW * 2 - SG) / 2;
  const gridY = bY + bH + 46;

  for (let i = 0; i < 4; i++) {
    const [label, value, color, bgColor] = stats[i];
    const col = i % 2, row = Math.floor(i / 2);
    const sx = gridX + col * (SW + SG), sy = gridY + row * (SH + SG);

    ctx.beginPath();
    ctx.roundRect(sx, sy, SW, SH, 18);
    ctx.fillStyle = bgColor;
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.30)";
    ctx.lineWidth   = 1;
    ctx.stroke();

    ctx.fillStyle = C.sub;
    ctx.font      = "18px monospace, 'Unifont', 'UnifontUpper'";
    ctx.fillText(label, sx + 22, sy + 36);

    ctx.fillStyle   = color;
    ctx.font        = "bold 38px monospace, 'Unifont', 'UnifontUpper'";
    ctx.fillText(value, sx + 22, sy + 86);
  }

  const BY  = gridY + 2 * (SH + SG) + 28;
  const BX  = gridX, BW = SW * 2 + SG, BH = 20;
  const pct = needed > 0 ? Math.min(progress / needed, 1) : 1;

  ctx.fillStyle = C.sub;
  ctx.font      = "18px monospace, 'Unifont', 'UnifontUpper'";
  ctx.textAlign = "left";
  ctx.fillText(`Progress ke Level ${(user.level || 0) + 1}`, BX, BY - 14);
  ctx.textAlign = "right";
  ctx.fillStyle = C.deep;
  ctx.font      = "bold 18px monospace, 'Unifont', 'UnifontUpper'";
  ctx.fillText(`${Math.round(pct * 100)}%`, BX + BW, BY - 14);

  ctx.beginPath();
  ctx.roundRect(BX, BY, BW, BH, BH / 2);
  ctx.fillStyle = C.bar_bg;
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.20)";
  ctx.lineWidth   = 1;
  ctx.stroke();

  const fw  = Math.max(BH, BW * pct);
  const barG = ctx.createLinearGradient(BX, 0, BX + fw, 0);
  barG.addColorStop(0, "rgba(182,162,220,0.9)");
  barG.addColorStop(0.5, "rgba(200,175,215,0.95)");
  barG.addColorStop(1, "rgba(160,210,200,0.9)");
  ctx.beginPath();
  ctx.roundRect(BX, BY, fw, BH, BH / 2);
  ctx.fillStyle   = barG;
  ctx.shadowBlur  = 20;
  ctx.shadowColor = "rgba(182,162,220,0.65)";
  ctx.fill();
  ctx.shadowBlur  = 0;
  ctx.strokeStyle = "rgba(255,255,255,0.28)";
  ctx.lineWidth   = 1;
  ctx.stroke();

  const walletY = BY + BH + 36;
  const walletH = 90;

  const wG = ctx.createLinearGradient(BX, walletY, BX + BW, walletY + walletH);
wG.addColorStop(0, "rgba(30,80,200,0.22)");
wG.addColorStop(1, "rgba(80,140,220,0.18)");
ctx.beginPath();
ctx.roundRect(BX, walletY, BW, walletH, 18);
ctx.fillStyle   = wG;
ctx.shadowBlur  = 14;
ctx.shadowColor = "rgba(30,80,200,0.25)";
ctx.fill();
ctx.shadowBlur  = 0;
ctx.strokeStyle = "rgba(80,140,220,0.45)";
ctx.lineWidth   = 1;
ctx.stroke();

  ctx.fillStyle = C.sub;
ctx.font      = "18px monospace, 'Unifont', 'UnifontUpper'";
ctx.textAlign = "left";
ctx.fillText("SALDO", BX + 22, walletY + 34);

ctx.fillStyle = C.text;
ctx.font      = "bold 42px monospace, 'Unifont', 'UnifontUpper'";
await drawText(ctx, `🪙 ${fmt(user.balance ?? 0)}`, BX + 22, walletY + 74, 38);

  noise(ctx, W, H);

  return canvas.toBuffer("image/png");
}

export const profileCommand = {
  cmd : ["profile", "rank", "level", "me"],
  tag : "rpg",
  desc: "Lihat profil XP, level & saldo kamu",
  async run(m) {
    const user         = rpg.getUser(m.sender, m.pushName);
    const { min, xp } = rpg.xpRange(user.level);
    const avatar       = await fetchAvatar(m.gara, m.sender);
    const img          = await buildCard(user, user.exp - min, xp, avatar);
    await m.reply({ image: img, caption: "" });
  },
};

export const leaderboardCommand = {
  cmd : ["toprank", "leaderboard", "lb"],
  tag : "rpg",
  desc: "Lihat 10 pengguna dengan XP tertinggi",
  async run(m) {
    const all = Object.values(rpg.getAll())
      .sort((a, b) => (b.exp || 0) - (a.exp || 0))
      .slice(0, 10);
    if (!all.length) return m.reply("Belum ada data user.");
    const medals = ["🥇", "🥈", "🥉"];
    const lines  = all.map((u, i) =>
      `${medals[i] || `${i + 1}.`} *${u.name || "?"}* — Lv.${u.level} | ${fmt(u.exp)} XP\n   🎖️ ${u.role}`
    );
    await m.reply(`🏆 *TOP 10 LEADERBOARD XP* 🏆\n\n${lines.join("\n\n")}`);
  },
};