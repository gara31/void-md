function normalizeNumber(raw) {
  let num = raw.replace(/[^0-9]/g, "");
  if (num.startsWith("0")) num = "62" + num.slice(1);
  return num;
}

async function resolveTarget(m) {
  if (m.quotedSender) return toNum(resolveJid(m.quotedSender) ?? m.quotedSender);
  if (m.mentionList?.length > 0) return toNum(resolveJid(m.mentionList[0]) ?? m.mentionList[0]);
  if (m.q) return normalizeNumber(m.q);
  return null;
}

export default {
  cmd   : ["infowa"],
  tag   : "info",
  desc  : "Info nomor WhatsApp (status, foto profil, terakhir online)",
  isArgs: "contoh: .infowa 08xxxxxxxxxx",

  async run(m) {
    const num = await resolveTarget(m);
    if (!num) return m.reply("Kirim nomor, tag, atau reply pesan pengguna.\nContoh: .infowa 08xxxxxxxxxx");

    const jid = num + "@s.whatsapp.net";
    await m.reply(msg.common.wait);

    const [registered, statusRaw, presence] = await Promise.allSettled([
      m.gara.onWhatsApp(num),
      m.gara.fetchStatus(jid),
      (async () => {
        await m.gara.presenceSubscribe(jid);
        await sleep(4000);
        return presenceStore.get(jid);
      })(),
    ]);

    const isRegistered = registered.status === "fulfilled" && registered.value?.[0]?.exists;
    const statusEntry  = statusRaw.status === "fulfilled"
      ? (Array.isArray(statusRaw.value) ? statusRaw.value[0] : statusRaw.value)
      : null;
    const presenceData = presence.status === "fulfilled" ? presence.value : null;

    const statusText    = statusEntry?.status?.status?.trim() || "(kosong)";
    const statusChanged = statusEntry?.status?.setAt ? dateFormatter(statusEntry.status.setAt * 1000) : "tidak diketahui";
    const lastOnline    = presenceData?.lastSeen ? dateFormatter(presenceData.lastSeen * 1000) : "tidak diketahui / privasi";

    let ppBuf = null;
    try {
      const ppUrl = await m.gara.profilePictureUrl(jid, "image");
      ppBuf = await fetch(ppUrl).then(r => r.arrayBuffer()).then(b => Buffer.from(b));
    } catch {}

    const caption = [
      `*Info WA*`,
      ``,
      `*IDENTITAS*`,
      `- nomor      : @${num}`,
      `- terdaftar  : ${isRegistered ? "ya" : "tidak"}`,
      ``,
      `*STATUS*`,
      `- isi        : ${statusText}`,
      `- diubah     : ${statusChanged}`,
      ``,
      `*AKTIVITAS*`,
      `- terakhir online : ${lastOnline}`,
      ...(!ppBuf ? [``, `*FOTO PROFIL*`, `- diprivasi`] : []),
    ].join("\n");

    const mentions = [jid];

    if (ppBuf) {
      await m.reply({ image: ppBuf, caption, mimetype: "image/jpeg", mentions });
    } else {
      await m.reply({ text: caption, mentions });
    }
  },
};