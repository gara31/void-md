import axios from "axios";
import * as cheerio from "cheerio";

export default {
  cmd: ["infokomik", "komik"],
  tag: "info",
  desc: "Cari informasi komik/manga di komiku.org",
  isArgs: "Masukkan judul komik yang ingin dicari",

  async run(m) {
    await m.reply(msg.common.wait);

    let results;
    try {
      const searchUrl = `https://komiku.org/?post_type=manga&s=${encodeURIComponent(m.q)}`;
      const { data: searchHtml } = await axios.get(searchUrl, {
        headers: { "User-Agent": "Mozilla/5.0", "Accept-Language": "en-US,en;q=0.9" },
      });

      const $s = cheerio.load(searchHtml);
      const apiUrl = $s("span[hx-get]").attr("hx-get");
      if (!apiUrl) return m.reply("Gagal mendapatkan data, mungkin website berubah");

      const { data: apiData } = await axios.get(apiUrl, {
        headers: { "User-Agent": "Mozilla/5.0", "Accept-Language": "en-US,en;q=0.9" },
      });

      const $ = cheerio.load(apiData);
      results = [];
      $("div.bge").each((_, el) => {
        const title = $(el).find("h3").text().trim();
        const link  = $(el).find("div.bgei > a").attr("href");
        const image = $(el).find("div.bgei > a > img").attr("src");
        if (title && link && image) results.push({ title, link, image });
      });
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    if (!results.length) return m.reply(`Tidak ditemukan hasil untuk: ${m.q}`);

    let teks = `Hasil pencarian: *${m.q}*\n\n`;
    for (let i = 0; i < Math.min(5, results.length); i++) {
      teks += `*${results[i].title}*\n${results[i].link}\n\n`;
    }

    await m.reply({ image: { url: results[0].image }, caption: teks.trim() });
  },
};
