import axios from "axios";
import * as cheerio from "cheerio";

const BASE_URL = "https://www.jadwaltv.net";
const HEADERS  = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
};

async function scrapeChannel(channel) {
  const { data } = await axios.get(`${BASE_URL}/channel/${channel.toLowerCase()}`, {
    timeout: 30000,
    headers: HEADERS,
  });
  const $      = cheerio.load(data);
  const jadwal = [];

  $("table.table-bordered tbody tr").each((_, el) => {
    const jam   = $(el).find("td").first().text().trim();
    const acara = $(el).find("td").last().text().trim();
    if (jam && acara && jam !== "Jam" && acara !== "Acara") {
      jadwal.push({ jam, acara });
    }
  });

  return jadwal;
}

async function scrapeAllChannels() {
  const { data } = await axios.get(`${BASE_URL}/channel/acara-tv-nasional-saat-ini`, {
    timeout: 30000,
    headers: HEADERS,
  });
  const $      = cheerio.load(data);
  const result = [];
  let   curr   = "";

  $("table.table-bordered tbody tr").each((_, el) => {
    if ($(el).find("td[colspan=2]").length > 0) {
      curr = $(el).find("a").text().trim();
    } else {
      const jam   = $(el).find("td").first().text().trim();
      const acara = $(el).find("td").last().text().trim();
      if (jam && acara && curr) {
        const ch = result.find(r => r.channel === curr);
        if (ch) ch.jadwal.push({ jam, acara });
        else result.push({ channel: curr, jadwal: [{ jam, acara }] });
      }
    }
  });

  return result;
}

export default {
  cmd   : ["infotv", "jadwaltv"],
  tag   : "info",
  desc  : "Info jadwal acara TV nasional Indonesia",
  isArgs: "❗masukkan nama channel, contoh: .infotv antv",

  async run(m) {
    await m.reply(msg.common.wait);

    const channel = m.q.trim().toLowerCase();

    try {
      const jadwal = await scrapeChannel(channel);
      if (!jadwal.length) return m.reply("channel tidak ditemukan atau jadwal kosong");

      const nama  = channel.toUpperCase().split("").join("  ");
      const lines = jadwal.map(j => `- ${j.jam} : ${j.acara}`).join("\n");
      return m.reply(`*I N F O  J A D W A L    ${nama}*\n\n${lines}`);

    } catch (e) {
      return m.reply(msg.common.error(e));
    }
  },
};
