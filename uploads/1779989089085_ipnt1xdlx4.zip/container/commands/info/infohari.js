import axios from "axios";
import * as cheerio from "cheerio";

const WIKIPEDIA_EVENTS = [
  { date: "01-03", event: "Hari Amal Bhakti Kementerian Agama" },
  { date: "01-04", event: "Hari Braille Sedunia" },
  { date: "01-05", event: "Hari Korps Wanita Angkatan Laut" },
  { date: "01-10", event: "Hari Gerakan Satu Juta Pohon" },
  { date: "01-10", event: "Hari Tritura" },
  { date: "01-15", event: "Hari Dharma Samudera" },
  { date: "01-25", event: "Hari Gizi Nasional" },
  { date: "01-31", event: "Hari Lahir Nahdlatul Ulama" },
  { date: "02-02", event: "Hari Lahan Basah Sedunia" },
  { date: "02-04", event: "Hari Kanker Sedunia" },
  { date: "02-09", event: "Hari Pers Nasional" },
  { date: "02-14", event: "Hari PETA" },
  { date: "02-21", event: "Hari Bahasa Ibu Internasional" },
  { date: "02-21", event: "Hari Peduli Sampah Nasional" },
  { date: "03-01", event: "Hari Kehakiman Nasional" },
  { date: "03-08", event: "Hari Wanita Internasional" },
  { date: "03-09", event: "Hari Musik Nasional" },
  { date: "03-22", event: "Hari Air Sedunia" },
  { date: "03-24", event: "Hari Tuberkulosis Sedunia" },
  { date: "03-30", event: "Hari Film Nasional" },
  { date: "04-02", event: "Hari Autisme Sedunia" },
  { date: "04-07", event: "Hari Kesehatan Internasional" },
  { date: "04-09", event: "Hari TNI AU" },
  { date: "04-21", event: "Hari Kartini" },
  { date: "04-22", event: "Hari Bumi" },
  { date: "04-23", event: "Hari Buku Sedunia" },
  { date: "05-01", event: "Hari Buruh Sedunia" },
  { date: "05-02", event: "Hari Pendidikan Nasional" },
  { date: "05-20", event: "Hari Kebangkitan Nasional" },
  { date: "05-31", event: "Hari Tanpa Tembakau" },
  { date: "06-01", event: "Hari Lahir Pancasila" },
  { date: "06-05", event: "Hari Lingkungan Hidup" },
  { date: "06-26", event: "Hari Anti Narkoba" },
  { date: "07-01", event: "Hari Bhayangkara" },
  { date: "07-12", event: "Hari Koperasi" },
  { date: "07-23", event: "Hari Anak Nasional" },
  { date: "08-05", event: "Hari Dharma Wanita" },
  { date: "08-08", event: "Hari ASEAN" },
  { date: "08-14", event: "Hari Pramuka" },
  { date: "08-17", event: "Hari Kemerdekaan RI" },
  { date: "09-01", event: "Hari Polwan" },
  { date: "09-09", event: "Hari Olahraga Nasional" },
  { date: "09-28", event: "Hari Kereta Api" },
  { date: "09-30", event: "Hari G30S PKI" },
  { date: "10-01", event: "Hari Kesaktian Pancasila" },
  { date: "10-02", event: "Hari Batik Nasional" },
  { date: "10-05", event: "Hari TNI" },
  { date: "10-22", event: "Hari Santri Nasional" },
  { date: "10-28", event: "Hari Sumpah Pemuda" },
  { date: "11-10", event: "Hari Pahlawan" },
  { date: "11-12", event: "Hari Ayah Nasional" },
  { date: "11-25", event: "Hari Guru" },
  { date: "12-01", event: "Hari AIDS Sedunia" },
  { date: "12-09", event: "Hari Anti Korupsi" },
  { date: "12-10", event: "Hari HAM" },
  { date: "12-22", event: "Hari Ibu" },
  { date: "12-25", event: "Hari Natal" },
];

function getTodayKey() {
  const now   = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day   = String(now.getDate()).padStart(2, "0");
  return `${month}-${day}`;
}

function getDaysUntil(today, target) {
  const [tm, td] = today.split("-").map(Number);
  const [em, ed] = target.split("-").map(Number);
  const yr  = new Date().getFullYear();
  const d1  = new Date(yr, tm - 1, td);
  let   d2  = new Date(yr, em - 1, ed);
  if (d2 < d1) d2 = new Date(yr + 1, em - 1, ed);
  return Math.ceil((d2 - d1) / 86400000);
}

function getMonthNum(name) {
  const map = { januari:"01", februari:"02", maret:"03", april:"04", mei:"05", juni:"06",
                juli:"07", agustus:"08", september:"09", oktober:"10", november:"11", desember:"12" };
  return map[name.toLowerCase().replace(/\d/g, "").trim()] || "00";
}

async function scrapeEvents() {
  const events = new Map();

  // data statis wikipedia
  for (const e of WIKIPEDIA_EVENTS) {
    events.set(`${e.date}-${e.event.toLowerCase()}`, { date: e.date, event: e.event });
  }

  // scrape tanggalan.com
  try {
    const { data } = await axios.get("https://www.tanggalan.com/", {
      timeout: 15000,
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    const $ = cheerio.load(data);
    $("article ul").each((_, el) => {
      const monthName = $(el).find("a").first().text().trim();
      const month     = getMonthNum(monthName);
      if (month === "00") return;
      $(el).find("table tbody tr").each((_, row) => {
        const rawDate = $(row).find("td").first().text().trim();
        const event   = $(row).find("td").last().text().trim();
        const dayNum  = parseInt(rawDate.split("-")[0], 10);
        if (isNaN(dayNum) || !event) return;
        const date = `${month}-${String(dayNum).padStart(2, "0")}`;
        const key  = `${date}-${event.toLowerCase()}`;
        if (!events.has(key)) events.set(key, { date, event });
      });
    });
  } catch {}

  return Array.from(events.values()).sort((a, b) => a.date.localeCompare(b.date));
}

export default {
  cmd : ["infohari", "harini"],
  tag : "info",
  desc: "Info hari peringatan/nasional hari ini & mendatang",

  async run(m) {
    await m.reply(msg.common.wait);

    let allEvents;
    try {
      allEvents = await scrapeEvents();
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    const today    = getTodayKey();
    const todayEvs = allEvents.filter(e => e.date === today);
    const upcoming = allEvents
      .map(e => ({ ...e, hari: getDaysUntil(today, e.date) }))
      .filter(e => e.hari > 0)
      .sort((a, b) => a.hari - b.hari)
      .slice(0, 5);

    let text = "";

    if (todayEvs.length > 0) {
      text += `*Hari Ini (${today})*\n`;
      text += todayEvs.map(e => `- ${e.event}`).join("\n");
      text += "\n\n";
    } else {
      text += `*Hari Ini (${today})*\ntidak ada peringatan khusus\n\n`;
    }

    if (upcoming.length > 0) {
      text += `*Mendatang*\n`;
      text += upcoming.map(e =>
        `- ${e.event}\n   ${e.date} (${e.hari} hari lagi)`
      ).join("\n");
    }

    await m.reply(text.trim());
  },
};
