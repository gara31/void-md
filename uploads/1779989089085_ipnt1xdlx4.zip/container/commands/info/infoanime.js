import axios from "axios";
import * as translate from "@vitalets/google-translate-api";

async function getAniListAnime(query) {
  const gqlQuery = `
  query ($search: String) {
    Media(search: $search, type: ANIME) {
      id
      title { romaji english native }
      description(asHtml: false)
      episodes
      duration
      status
      season
      seasonYear
      genres
      averageScore
      popularity
      studios { nodes { name } }
      coverImage { extraLarge large medium }
      bannerImage
    }
  }`;

  const { data } = await axios.post(
    "https://graphql.anilist.co",
    { query: gqlQuery, variables: { search: query } },
    { headers: { "Content-Type": "application/json" } }
  );

  return data.data.Media;
}

export default {
  cmd   : ["infoanime", "anime"],
  tag   : "info",
  desc  : "Info anime dari AniList",
  isArgs: "❗contoh: .anime Yosuga No Sora",

  async run(m) {
    await m.reply(msg.common.wait);

    const anime = await getAniListAnime(m.q.trim());
    if (!anime) return m.reply("Anime tidak ditemukan");

    let desc = (anime.description || "").replace(/<[^>]*>?/gm, "") || "Tidak ada deskripsi.";
    try {
      const res = await translate.translate(desc, { to: "id" });
      desc = res.text;
    } catch {}

    const caption = [
      `*${anime.title.romaji || anime.title.english || anime.title.native}*`,
      ``,
      `*INFORMASI UMUM*`,
      `- Skor: ${anime.averageScore ? `${anime.averageScore}%` : "-"}`,
      `- Popularitas: ${anime.popularity || "-"}`,
      `- Genre: ${anime.genres.join(", ") || "-"}`,
      `- Studio: ${anime.studios.nodes.map(s => s.name).join(", ") || "-"}`,
      `- Musim: ${anime.season ? `${anime.season} ${anime.seasonYear}` : "-"}`,
      `- Durasi: ${anime.duration ? `${anime.duration} menit/episode` : "-"}`,
      `- Status: ${anime.status || "-"}`,
      `- Episode: ${anime.episodes || "-"}`,
      ``,
      `*SINOPSIS*`,
      desc,
    ].join("\n");

    const imageUrls = [anime.coverImage.extraLarge, anime.bannerImage, anime.coverImage.large].filter(Boolean);

    for (const url of imageUrls) {
      try {
        const { data } = await axios.get(url, { responseType: "arraybuffer", timeout: 15000, headers: { "User-Agent": "Mozilla/5.0" } });
        await m.reply({ image: Buffer.from(data), caption });
        return;
      } catch {}
    }

    await m.reply(caption);
  },
};
