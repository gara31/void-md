import * as translate from "@vitalets/google-translate-api";

export default {
  cmd   : ["infochar", "char"],
  tag   : "info",
  desc  : "Info karakter anime dari Jikan",
  isArgs: "❗contoh: .char Mei Misaki",

  async run(m) {
    await m.reply(msg.common.wait);

    const res  = await fetch(`https://api.jikan.moe/v4/characters?q=${encodeURIComponent(m.q.trim())}&limit=1`);
    const json = await res.json();
    const data = json.data || [];

    if (!data.length) return m.reply("Karakter tidak ditemukan");

    const char = data[0];

    let animeList = "-";
    try {
      const animeRes  = await fetch(`https://api.jikan.moe/v4/characters/${char.mal_id}/anime`);
      const animeJson = await animeRes.json();
      animeList = (animeJson.data || [])
        .slice(0, 3)
        .map(e => `${e.anime.title} (${e.role})`)
        .join("\n") || "-";
    } catch {}

    let about = "Deskripsi tidak tersedia";
    if (char.about) {
      try {
        const t = await translate.translate(char.about.split("\n")[0], { to: "id" });
        about = t.text;
      } catch {
        about = char.about.split("\n")[0];
      }
    }

    const caption = [
      `*${char.name}*`,
      ``,
      `*INFORMASI UMUM*`,
      `- Nama: ${char.name}`,
      `- Kanji: ${char.name_kanji || "-"}`,
      `- Nicknames: ${(char.nicknames || []).join(", ") || "-"}`,
      `- Favorit: ${char.favorites || "-"}`,
      ``,
      `*MUNCUL DI*`,
      animeList,
      ``,
      `*TENTANG*`,
      about,
    ].join("\n");

    await m.reply({ image: { url: char.images?.jpg?.image_url }, caption });
  },
};
