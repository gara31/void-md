function extractCode(input) {
  if (!input) return null;
  const match = input.match(/(?:chat\.whatsapp\.com\/)?([A-Za-z0-9]{20,})/);
  return match ? match[1] : null;
}

export default {
  cmd : ["infogc", "infoinvite"],
  tag : "info",
  desc: "Lihat informasi grup dari link invite WhatsApp",

  async run(m) {
    const raw  = m.q?.trim();
    const code = extractCode(raw);

    if (!code) {
      return m.reply(
        "Kirim link atau kode invite grup.\n" +
        "Contoh: .infogc https://chat.whatsapp.com/xxxxx"
      );
    }

    await m.reply(msg.common.wait);

    let g;
    try {
      g = await m.gara.groupGetInviteInfo(code);
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    const tglDibuat = g.creation
      ? dateFormatter(g.creation * 1000)
      : "Tidak diketahui";

    const tglSubject = g.subjectTime
      ? dateFormatter(g.subjectTime * 1000)
      : "Tidak diketahui";

    const tglDesc = g.descTime
      ? dateFormatter(g.descTime * 1000)
      : "Tidak diketahui";

    const owner        = g.owner?.replace("@s.whatsapp.net", "") ?? "Tidak diketahui";
    const subjectOwner = g.subjectOwner?.replace("@s.whatsapp.net", "") ?? "Tidak diketahui";
    const descOwner    = g.descOwner?.replace("@s.whatsapp.net", "") ?? "Tidak diketahui";

    const totalAdmin  = g.participants?.filter(p => p.admin).length ?? 0;
    const totalMember = g.size ?? g.participants?.length ?? 0;

    const tipeGrup = g.isCommunity
      ? "Komunitas"
      : g.isCommunityAnnounce
        ? "Pengumuman Komunitas"
        : "Grup Biasa";

    const kirimPesan  = g.announce  ? "Admin saja" : "Semua member";
    const editInfo    = g.restrict  ? "Admin saja" : "Semua member";
    const approvalJoin = g.joinApprovalMode ? "Perlu persetujuan admin" : "Langsung masuk";
    const tambahMember = g.memberAddMode === "admin_add" ? "Admin saja" : "Semua member";

    const desc = g.desc?.trim() || "(tidak ada deskripsi)";

    const lines = [
      "*Info Grup*",
      "",
      `- *Nama:* ${g.subject}`,
      `- *ID Grup:* ${g.id}`,
      `- *Tipe:* ${tipeGrup}`,
      "",
      "*Pembuat*",
      `- *Dibuat oleh:* ${owner}`,
      `- *Tanggal dibuat:* ${tglDibuat}`,
      "",
      "*Subjek*",
      `- *Diubah oleh:* ${subjectOwner}`,
      `- *Tanggal diubah:* ${tglSubject}`,
      "",
      "*Deskripsi*",
      `- *Isi:* ${desc}`,
      `- *Diubah oleh:* ${descOwner}`,
      `- *Tanggal diubah:* ${tglDesc}`,
      "",
      "*Member*",
      `- *Total member:* ${totalMember}`,
      `- *Total admin:* ${totalAdmin}`,
      "",
      "*Pengaturan*",
      `- *Kirim pesan:* ${kirimPesan}`,
      `- *Edit info grup:* ${editInfo}`,
      `- *Gabung via link:* ${approvalJoin}`,
      `- *Tambah member:* ${tambahMember}`,
    ];

    if (g.linkedParent) {
      lines.push("", `- *Komunitas induk:* ${g.linkedParent}`);
    }

    await m.reply(lines.join("\n"));
  },
};