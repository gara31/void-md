import * as translate from "@vitalets/google-translate-api";

const propLabels = {
  P21:    "Jenis Kelamin",
  P569:   "Tanggal Lahir",
  P570:   "Tanggal Meninggal",
  P19:    "Tempat Lahir",
  P20:    "Tempat Meninggal",
  P509:   "Penyebab Kematian",
  P1196:  "Cara Meninggal",
  P27:    "Kebangsaan",
  P172:   "Etnisitas",
  P103:   "Bahasa Ibu",
  P1412:  "Bahasa yang Digunakan",
  P140:   "Agama",
  P106:   "Profesi / Pekerjaan",
  P101:   "Bidang Keahlian",
  P136:   "Genre",
  P1303:  "Instrumen Musik",
  P412:   "Suara / Vokal",
  P264:   "Label Rekaman",
  P22:    "Ayah",
  P25:    "Ibu",
  P26:    "Pasangan",
  P40:    "Anak",
  P3373:  "Saudara Kandung",
  P53:    "Keluarga / Dinasti",
  P1038:  "Kerabat",
  P69:    "Pendidikan",
  P166:   "Penghargaan",
  P1411:  "Nominasi",
  P1050:  "Kondisi Medis",
  P18:    "Foto",
  P109:   "Tanda Tangan",
  P1477:  "Nama Lahir",
  P1449:  "Nama Julukan",
  P735:   "Nama Depan",
  P734:   "Nama Keluarga",
  P856:   "Website Resmi",
  P2002:  "Twitter / X",
  P2013:  "Facebook",
  P2003:  "Instagram",
  P2847:  "Google+",
  P3417:  "Quora",
  P3782:  "Artstation",
  P4019:  "Mastodon",
  P2397:  "YouTube Channel",
  P1953:  "Discogs",
  P1902:  "Spotify",
  P1728:  "AllMusic",
  P2373:  "Genius",
  P434:   "MusicBrainz Artist",
  P1284:  "Munzinger",
  P1286:  "Munzinger Sport",
  P1263:  "NNDB",
  P998:   "DMOZ",
  P345:   "IMDb",
  P646:   "Freebase",
  P244:   "LoC Authority",
  P214:   "VIAF",
  P227:   "GND",
  P213:   "ISNI",
  P349:   "NDL Japan",
  P691:   "NKC Czech",
  P906:   "SELIBR Sweden",
  P1006:  "NTA Netherlands",
  P950:   "BNE Spain",
  P268:   "BnF France",
  P269:   "SUDOC France",
  P271:   "CiNii Japan",
  P1315:  "NLA Australia",
  P1207:  "NUKAT Poland",
  P1003:  "NLR Romania",
  P1580:  "UB Mannheim",
  P1553:  "Yandex Music",
  P409:   "NLA Trove",
  P1711:  "RKD Artist",
  P3430:  "SNAC",
  P3435:  "PeekYou",
  P535:   "Find A Grave",
  P119:   "Lokasi Makam",
  P1442:  "Foto Makam",
  P2031:  "Tahun Aktif (Mulai)",
  P2032:  "Tahun Aktif (Selesai)",
  P910:   "Kategori Utama",
  P1151:  "Portal Topik",
  P31:    "Merupakan",
  P373:   "Kategori Wikipedia",
  P935:   "Galeri Commons",
  P1417:  "Britannica",
  P2163:  "FAST ID",
  P2168:  "SRAIL ID",
  P2387:  "ECARTICO ID",
  P2435:  "PORT ID",
  P2519:  "SCOPE ID",
  P2572:  "BnF Catalogue Général",
  P2579:  "ISWC",
  P2581:  "BabelNet",
  P2600:  "Geni.com",
  P2604:  "Kinopoisk",
  P2605:  "CSFD",
  P2626:  "DKFILM",
  P2638:  "Theatricalia",
  P2722:  "Deezer Artist",
  P2849:  "iTunes Artist",
  P2850:  "iTunes App",
  P2889:  "Familypedia",
  P2909:  "SHARE Catalogue",
  P2924:  "GTAA",
  P2949:  "WikiTree",
  P2963:  "Goodreads Author",
  P2966:  "Shoeboxed",
  P3017:  "KINO.de",
  P3040:  "SoundCloud",
  P3065:  "RERO (Swiss)",
  P3106:  "Musopen Composer",
  P3114:  "NLP Poland",
  P3136:  "China Biographical DB",
  P3162:  "Douban",
  P3192:  "Last.fm",
  P3219:  "Encyclopaedia Universalis",
  P3221:  "NYC Dance",
  P3265:  "Myspace",
  P3280:  "BanjoWiki",
  P3305:  "KINENOTE",
  P3341:  "Filmportal.de",
  P3348:  "NLG Greece",
  P3365:  "Treccani",
  P3368:  "Prabook",
  P3388:  "CONOR Slovenia",
  P3478:  "Songkick Artist",
  P3479:  "Omni Music",
  P3553:  "Zhihu",
  P3569:  "Songfacts Artist",
  P3579:  "Sina Weibo",
  P3630:  "Babelio Author",
  P3733:  "TikTok",
  P3828:  "Wears",
  P3845:  "Theaterlexikon",
  P3846:  "DNB Catalogue",
  P3984:  "Subreddit",
  P3987:  "SHARE-VDE",
  P4012:  "Semantic Scholar Author",
  P4104:  "Canmore",
  P4198:  "Apple Music Artist",
  P4204:  "Genius Artist",
  P4208:  "Publons Author",
  P4223:  "NSZL (Hungary)",
  P4300:  "Museum of Modern Art",
  P4332:  "Genius Lyrics",
  P4342:  "Store norske leksikon",
  P4359:  "Letterboxd",
  P4431:  "Keybase",
  P4438:  "BTO",
  P4440:  "Kbpedia",
  P4473:  "Publika",
  P4514:  "CERL Thesaurus",
  P4515:  "Catalogus Professorum Lipsiensis",
  P4576:  "AlloCiné",
  P4619:  "NLB Singapore",
  P4657:  "NSDL India",
  P4666:  "CineTV",
  P4747:  "Online Books Page",
  P4757:  "NLA People Australia",
  P4768:  "CinemaRX",
  P4782:  "Open Library",
  P4823:  "National Portrait Gallery UK",
  P4839:  "Muck Rack",
  P4927:  "Archnet",
  P4985:  "TMDB Person",
  P5007:  "World Rugby",
  P5008:  "On Focus (Wikimedia)",
  P5019:  "Brockhaus",
  P5033:  "Persée",
  P5034:  "National Library Korea",
  P5063:  "Progarchives Artist",
  P5068:  "KoBoL Author",
  P5121:  "Progarchives",
  P5145:  "GS1 GPC",
  P5154:  "Filmweb Person",
  P5184:  "Odnoklassniki",
  P5233:  "Bibsonomy",
  P5254:  "PMC Author",
  P5287:  "Behind the Voice Actors",
  P5292:  "ILScat",
  P5298:  "Open Alex Author",
  P5337:  "Google News",
  P5340:  "CATNOC",
  P5356:  "Krugosvet",
  P5404:  "Open Media DB",
  P5421:  "Trading Card Database",
  P5431:  "Discogs Artist",
  P5534:  "World Biographical Information System",
  P5551:  "Basketball Reference",
  P5587:  "Libris (Sweden)",
  P5617:  "LSID",
  P5801:  "ZBW",
  P5882:  "Muziekweb Performer",
  P5905:  "Comic Vine",
  P5917:  "Prabook",
  P5927:  "Spotify Artist",
  P6058:  "AniList Character",
  P6081:  "Catalogus Professorum Rostochiensium",
  P6119:  "NLCz",
  P6181:  "WeChat",
  P6200:  "BBC Sport",
  P6255:  "Opac BNF (Swiss)",
  P6262:  "Fandom Wiki",
  P6275:  "National Gallery of Art (US)",
  P6276:  "National Gallery of Victoria",
  P6298:  "Open Plaques",
  P6327:  "Internet Archive Author",
  P6351:  "Wikimania Speaker",
  P6385:  "Krugosvet Encyclopedia",
  P6394:  "CALIS",
  P6412:  "WaymarkD",
  P6413:  "Sports Reference",
  P6446:  "NBA.com",
  P6461:  "WLM ID",
  P6517:  "Who's on First",
  P6559:  "WD-FIST",
  P6573:  "Libris",
  P6578:  "Angelicum",
  P6621:  "FAST (new)",
  P6683:  "ESTER",
  P6706:  "ARIADNE-plus",
  P6723:  "BNE (new)",
  P6839:  "TV Tropes",
  P6844:  "Filmweb",
  P6849:  "AGORHA",
  P6868:  "EAGLE-network",
  P6870:  "MusicBrainz Release Group",
  P6874:  "NSZL Author",
  P6886:  "Writing System",
  P6900:  "PMC Journal",
  P6903:  "Quora Profile",
  P6912:  "LIBRIS Person",
  P6914:  "Foursquare",
  P6918:  "GoodReads",
  P6923:  "VIAF (mirror)",
  P6926:  "BIBSYS (Norway)",
  P6927:  "BIBSYS (Norway) 2",
  P6960:  "Encyclopaedia Iranica",
  P6967:  "CANTIC",
  P6968:  "Biblioteca Nacional de Portugal",
  P6970:  "BNP (alt)",
  P7024:  "ISCC",
  P7026:  "NLP Author",
  P7029:  "SUDOC (alt)",
  P7039:  "Roglo",
  P7050:  "BnF Catalogue (alt)",
  P7052:  "SHARE-VDE (alt)",
  P7070:  "SCOPUS Author",
  P7084:  "CID Portugal",
  P7109:  "BNB Person",
  P7119:  "Moodle Author",
  P7157:  "Crossref Member",
  P7184:  "WRPW",
  P7185:  "RCAHMW",
  P7187:  "Archivio Toscano",
  P7189:  "PIC (Italy)",
  P7190:  "NISO",
  P7193:  "IECHOR",
  P7194:  "NISO (alt)",
  P7196:  "SBN (Italy)",
  P7198:  "ARIADNE",
  P7212:  "ACMID",
  P7214:  "AGORHA Person",
  P7215:  "Libris (Sweden) URI",
  P7275:  "CONOR (Slovenia)",
  P7284:  "BDH",
  P7293:  "PLWABN",
  P7300:  "RKD Person",
  P7303:  "NMvW",
  P7305:  "Europeana Person",
  P7353:  "LIBRIS Work",
  P7369:  "ISNI (alt)",
  P7502:  "SHARE Author",
  P7506:  "VIVO",
  P7520:  "National Museum Denmark",
  P7522:  "WoS ResearcherID",
  P7545:  "Askart",
  P7553:  "Biblioteca Nacional Argentina",
  P7666:  "Twitter (alt)",
  P7699:  "PLWABN (alt)",
  P7700:  "PLWABN (alt2)",
  P7703:  "PLWABN (alt3)",
  P7704:  "PLWABN (alt4)",
  P7745:  "PLWABN (alt5)",
  P7803:  "NUKAT (alt)",
  P7815:  "NDL (alt)",
  P7902:  "KINOLUZ",
  P7920:  "Linked Jazz",
  P7929:  "Retina Engage",
  P7982:  "Biblioteca Nacional Bolivia",
  P8013:  "Trove Person",
  P8034:  "VIVE",
  P8041:  "J. Paul Getty Trust",
  P8094:  "GovTrack",
  P8125:  "National Portrait Gallery (UK) 2",
  P8179:  "Canadiana",
  P8189:  "NLI Israel",
  P8301:  "Find A Grave Memorial",
  P8309:  "BNF Portugal ID",
  P8313:  "Dict. of Art Historians",
  P8349:  "Artnet",
  P8381:  "NLB Singapore (alt)",
  P8385:  "Internet Archive Video",
  P8591:  "Songkick (alt)",
  P8669:  "CanLII Judge",
  P8672:  "CERL Thesaurus (alt)",
  P8687:  "Social Blade",
  P8693:  "POTY",
  P8796:  "NLA Catalogue",
  P8814:  "NLI Israel (alt)",
  P8819:  "IdentitéS",
  P8849:  "AllRecipes",
  P8870:  "NLA Trove (new)",
  P8879:  "BVMC Person",
  P8885:  "RILM",
  P8895:  "Datenbank Theaterzetteln",
  P8969:  "Dictionary of Irish Biography",
  P8977:  "ISFDB",
  P8980:  "Stadia (alt)",
  P9102:  "NLP Person",
  P9171:  "EU Parliament",
  P9247:  "Brill Online",
  P9305:  "Open Library Author",
  P9328:  "BIBNAT Romania",
  P9346:  "NatBib Estonia",
  P9352:  "GeoNames Feature",
  P9404:  "Oxford DNB",
  P9463:  "Encyclopaedia Biographica",
  P9469:  "Diccionario Biográfico",
  P9662:  "CEOL",
  P9686:  "Musik Sammler",
  P9694:  "Agence Bibliographique",
  P9775:  "Nordicana",
  P9807:  "BVMC Work",
  P9864:  "BVMC Author",
  P9918:  "Les Archives du spectacle",
  P9937:  "Academic Tree",
  P9964:  "ABTEIBY",
  P9965:  "MoMA Artist",
  P9984:  "WTO",
  P9995:  "Artsy",
  P10018: "Open ISNI",
  P10052: "BNI Italy",
  P10069: "PACTOLS",
  P10097: "Linked Open Vocabularies",
  P10163: "BNI Person",
  P10166: "Répertoire du Patrimoine",
  P10180: "NLB Singapore Person",
  P10194: "SIVA",
  P10225: "BVMC (alt2)",
  P10242: "SEER",
  P10266: "CvB",
  P10268: "Dict. of New Zealand Biography",
  P10288: "ARCA",
  P10297: "Scopus Author (new)",
  P10302: "BNPC",
  P10305: "ECARTICO (alt)",
  P10328: "IANA Language",
  P10372: "Filmograafia Estonia",
  P10387: "NSDL India (alt)",
  P10400: "CineMagia Person",
  P10410: "Open Plaques (alt)",
  P10445: "Biblioteca Virtual Miguel de Cervantes",
  P10524: "ISCC (alt)",
  P10540: "NLIL",
  P10553: "ORCID",
  P10554: "Researcher Scholar ID",
  P10565: "BMLO",
  P10608: "NLP Name",
  P10621: "SEMA",
  P10660: "NLP Alt",
  P10699: "LCSN",
  P10757: "NLI Israel URI",
  P10780: "Lieder Net",
  P10820: "ARLIMA",
  P10832: "Open ISNI 2",
  P10885: "MNHN",
  P10895: "ATILF",
  P10900: "BUDA",
  P10916: "NLT Thailand",
  P11047: "NUKAT (alt2)",
  P11090: "BNI Person (alt)",
  P11120: "NatBib Lithuania",
  P11137: "Czech Nat. Auth.",
  P11156: "CRIS",
  P11168: "NatBib Latvia",
  P11194: "NatBib Bosnia",
  P11196: "NatBib Albania",
  P11237: "NatBib Montenegro",
  P11245: "NatBib North Macedonia",
  P11249: "NatBib Slovakia",
  P11345: "NLIL Author",
  P11386: "NatBib Croatia",
  P11408: "NatBib Serbia",
  P11434: "NatBib Slovenia",
  P11449: "NatBib Kosovo",
  P11454: "NatBib Moldova",
  P11496: "NatBib Belarus",
  P11646: "NatBib Georgia",
  P11683: "NatBib Armenia",
  P11686: "NatBib Azerbaijan",
  P11800: "NatBib Kyrgyzstan",
  P11823: "NatBib Tajikistan",
  P12086: "NatBib Kazakhstan",
  P12098: "NatBib Uzbekistan",
  P12152: "NatBib Turkmenistan",
  P12153: "NatBib Mongolia",
  P12309: "NatBib Bahrain",
  P12320: "NatBib Oman",
  P12385: "NatBib UAE",
  P12582: "NatBib Kuwait",
  P12595: "NatBib Jordan",
  P12597: "NatBib Lebanon",
  P12674: "NatBib Iraq",
  P12749: "NatBib Syria",
  P12800: "NatBib Libya",
  P12836: "NatBib Tunisia",
  P12854: "NatBib Algeria",
  P13049: "NatBib Morocco",
  P13204: "NatBib Egypt",
  P13295: "NatBib Sudan",
  P13300: "NatBib Ethiopia",
  P13390: "NatBib Kenya",
  P13526: "NatBib Tanzania",
  P13591: "NatBib South Africa",
  P13613: "NatBib Nigeria",
  P13634: "NatBib Ghana",
  P13661: "NatBib Cameroon",
  P13797: "NatBib Senegal",
  P13956: "NatBib Ivory Coast",
  P13967: "NatBib Madagascar",
  P13974: "NatBib Mauritius",
  P14003: "NatBib Mozambique",
  P14062: "NatBib Zimbabwe",
  P14073: "NatBib Zambia",
  P14178: "NatBib Uganda",
  P14225: "NatBib Rwanda",
  P14436: "NatBib Angola",
};

const prioProps = [
  "P21", "P569", "P570", "P19", "P20", "P509",
  "P27", "P172", "P103", "P1412", "P140",
  "P106", "P101", "P136", "P1303", "P412", "P264",
  "P22", "P25", "P26", "P40", "P3373",
  "P69", "P166", "P1411", "P1050",
  "P1477", "P1449", "P735", "P734",
  "P856", "P2002", "P2013", "P2003", "P2397",
  "P345", "P2031", "P2032",
];

// Batch resolve: fetch up to 50 entity IDs in one API call
async function batchResolveLabels(entityIds, lang = "id") {
  const labelMap = {};
  if (!entityIds.length) return labelMap;

  const unique = [...new Set(entityIds)];
  const chunkSize = 50;

  for (let i = 0; i < unique.length; i += chunkSize) {
    const chunk = unique.slice(i, i + chunkSize);
    const ids = chunk.join("|");
    try {
      const url = `https://www.wikidata.org/w/api.php?action=wbgetentities&ids=${ids}&format=json&languages=${lang}|en&props=labels`;
      const data = await fetch(url).then(r => r.json());
      for (const id of chunk) {
        const entity = data.entities?.[id];
        labelMap[id] =
          entity?.labels?.[lang]?.value ||
          entity?.labels?.en?.value ||
          id;
      }
    } catch {
      for (const id of chunk) labelMap[id] = id;
    }
  }

  return labelMap;
}

// Collect all wikibase entity IDs from claims (sync, no fetch)
function collectEntityIds(claims, ordered) {
  const ids = new Set();
  const skip = new Set(["P18","P109","P1442","P935","P373","P910","P1151"]);
  for (const pid of ordered) {
    if (skip.has(pid) || !propLabels[pid]) continue;
    const claimArr = claims[pid] || [];
    for (const c of claimArr.slice(0, 3)) {
      const dv = c.mainsnak?.datavalue;
      if (dv?.type === "wikibase-entityid" && dv.value?.id) {
        ids.add(dv.value.id);
      }
    }
  }
  return [...ids];
}

// Format claim value synchronously using pre-resolved label map
function formatClaimValueSync(snak, labelMap) {
  const dv = snak?.datavalue;
  if (!dv) return null;
  if (dv.type === "string") return dv.value;
  if (dv.type === "time") {
    const raw = dv.value?.time || "";
    const m = raw.match(/[+-](\d{4})-(\d{2})-(\d{2})/);
    if (m) {
      const [, y, mo, d] = m;
      if (mo === "00") return y;
      if (d === "00") return `${mo}/${y}`;
      return `${d.replace(/^0/, "")} ${["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"][+mo-1]} ${y}`;
    }
    return raw;
  }
  if (dv.type === "wikibase-entityid") {
    const id = dv.value?.id;
    if (!id) return null;
    return labelMap[id] || id;
  }
  if (dv.type === "monolingualtext") return dv.value?.text;
  if (dv.type === "globecoordinate") {
    const { latitude: lat, longitude: lon } = dv.value || {};
    if (lat && lon) return `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  }
  return null;
}

async function getWikidataPerson(query, lang = "id") {
  try {
    const searchUrl = `https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(query)}&language=${lang}&format=json&limit=1&type=item`;
    const searchData = await fetch(searchUrl).then(r => r.json());
    const match = searchData.search?.[0];
    if (!match) return null;

    const qid = match.id;
    const entityUrl = `https://www.wikidata.org/w/api.php?action=wbgetentities&ids=${qid}&format=json&languages=${lang}|en&props=labels|descriptions|claims|sitelinks`;
    const entityData = await fetch(entityUrl).then(r => r.json());
    const entity = entityData.entities?.[qid];
    if (!entity) return null;

    const name = entity.labels?.[lang]?.value || entity.labels?.en?.value || query;
    const description = entity.descriptions?.[lang]?.value || entity.descriptions?.en?.value || "";
    const claims = entity.claims || {};

    // Fetch photo
    let photo = null;
    const photoFile = claims.P18?.[0]?.mainsnak?.datavalue?.value;
    if (photoFile) {
      const enc = encodeURIComponent(photoFile.replace(/ /g, "_"));
      const infoUrl = `https://commons.wikimedia.org/w/api.php?action=query&titles=File:${enc}&prop=imageinfo&iiprop=url&format=json`;
      try {
        const imgData = await fetch(infoUrl).then(r => r.json());
        const pages = imgData.query?.pages || {};
        const page = Object.values(pages)[0];
        photo = page?.imageinfo?.[0]?.url || null;
      } catch {}
    }

    // Build wiki link
    let wikiLink = entity.sitelinks?.idwiki?.url
      || entity.sitelinks?.enwiki?.url
      || `https://www.wikidata.org/wiki/${qid}`;
    if (wikiLink.startsWith("//")) wikiLink = "https:" + wikiLink;

    // Determine property order
    const allPropIds = Object.keys(claims);
    const ordered = [...new Set([...prioProps.filter(p => claims[p]), ...allPropIds])];

    // Collect all wikibase entity IDs, then batch resolve in one go
    const entityIdList = collectEntityIds(claims, ordered);
    const labelMap = await batchResolveLabels(entityIdList, lang);

    // Build resolved map synchronously
    const skip = new Set(["P18","P109","P1442","P935","P373","P910","P1151"]);
    const resolved = {};
    for (const pid of ordered) {
      if (skip.has(pid) || !propLabels[pid]) continue;
      const label = propLabels[pid];
      const claimArr = claims[pid] || [];
      const vals = [];
      for (const c of claimArr.slice(0, 3)) {
        const v = formatClaimValueSync(c.mainsnak, labelMap);
        if (v) vals.push(v);
      }
      if (vals.length) resolved[pid] = { label, values: vals };
    }

    return { qid, name, description, photo, wikiLink, resolved, lang };
  } catch (e) {
    console.error("Wikidata error:", e.message);
    return null;
  }
}

function buildCaption(person) {
  const { name, description, resolved, wikiLink } = person;
  const groups = {
    "IDENTITAS": ["P21","P1477","P1449","P735","P734"],
    "KEHIDUPAN": ["P569","P19","P570","P20","P509","P1196"],
    "KEWARGANEGARAAN & BUDAYA": ["P27","P172","P103","P1412","P140"],
    "KARIER & KEAHLIAN": ["P106","P101","P136","P1303","P412","P264","P2031","P2032"],
    "KELUARGA": ["P22","P25","P26","P40","P3373","P53","P1038"],
    "PENDIDIKAN & PENGHARGAAN": ["P69","P166","P1411"],
    "MEDIS": ["P1050"],
    "MEDIA SOSIAL & WEB": ["P856","P2002","P2013","P2003","P2397","P1902","P3192","P3733"],
  };

  const lines = [
    `*${name}*\n`,
    description ? `_${description}_` : "",
    "",
  ];

  const usedPids = new Set();

  for (const [groupName, pids] of Object.entries(groups)) {
    const groupLines = [];
    for (const pid of pids) {
      if (!resolved[pid]) continue;
      const { label, values } = resolved[pid];
      groupLines.push(`- ${label}: ${values.join(", ")}`);
      usedPids.add(pid);
    }
    if (groupLines.length) {
      lines.push(`*${groupName}*`);
      lines.push(...groupLines);
      lines.push("");
    }
  }
  

  return lines.filter(l => l !== undefined).join("\n");
}

export default {
  cmd   : ["infotokoh", "tokoh"],
  tag   : "info",
  desc  : "Info tokoh dari Wikidata (Wikipedia)",
  isArgs: "❗contoh: .tokoh Soekarno",

  async run(m) {
    await m.reply(msg.common.wait);

    const query = m.q?.trim();
    if (!query) return m.reply(msg.common.needArgs);

    const person = await getWikidataPerson(query, "id");
    if (!person) return m.reply("Tokoh tidak ditemukan");

    if (person.description?.length > 10) {
      try {
        const res = await translate.translate(person.description, { to: "id" });
        person.description = res.text;
      } catch {}
    }

    const caption = buildCaption(person);

    if (person.photo?.startsWith("http")) {
      try {
        const res = await fetch(person.photo, { headers: { "User-Agent": "Mozilla/5.0" } });
        const buf = Buffer.from(await res.arrayBuffer());
        await m.reply({ image: buf, caption });
      } catch {
        await m.reply(caption);
      }
    } else {
      await m.reply(caption);
    }
  },
};