import axios from "axios";
import { getPhoneSpecs } from "../../settings/scrape/getPhoneSpecs.js";

export default {
  cmd   : ["infohp", "hp"],
  tag   : "info",
  desc  : "Info spesifikasi HP dari GSMArena",
  isArgs: "❗contoh: .hp Xiaomi Redmi Note 14",

  async run(m) {
    await m.reply(msg.common.wait);

    const specs = await getPhoneSpecs(m.q.trim());
    if (!specs?.name) return m.reply("HP tidak ditemukan atau gagal mengambil data");

    const caption = [
      `*${specs.name}*`,
      ``,
      `*JARINGAN*`,
      `- Teknologi: ${specs.technology || "-"}`,
      `- 2G: ${specs.bands2g || "-"}`,
      `- 3G: ${specs.bands3g || "-"}`,
      `- 4G: ${specs.bands4g || "-"}`,
      `- Kecepatan: ${specs.speed || "-"}`,
      ``,
      `*PELUNCURAN*`,
      `- Diumumkan: ${specs.announced || "-"}`,
      `- Status: ${specs.status || "-"}`,
      ``,
      `*DESAIN*`,
      `- Dimensi: ${specs.dimensions || "-"}`,
      `- Berat: ${specs.weight || "-"}`,
      `- Build: ${specs.build || "-"}`,
      `- SIM: ${specs.sim || "-"}`,
      ``,
      `*LAYAR*`,
      `- Tipe: ${specs.displayType || "-"}`,
      `- Ukuran: ${specs.displaySize || "-"}`,
      `- Resolusi: ${specs.resolution || "-"}`,
      `- Proteksi: ${specs.protection || "-"}`,
      ``,
      `*PLATFORM*`,
      `- OS: ${specs.os || "-"}`,
      `- Chipset: ${specs.chipset || "-"}`,
      `- CPU: ${specs.cpu || "-"}`,
      `- GPU: ${specs.gpu || "-"}`,
      ``,
      `*MEMORI*`,
      `- Slot Kartu: ${specs.cardSlot || "-"}`,
      `- Internal: ${specs.internal || "-"}`,
      ``,
      `*KAMERA*`,
      `- Kamera Utama: ${specs.mainCamera || "-"}`,
      `- Kamera Depan: ${specs.selfieCamera || "-"}`,
    ].join("\n");

    if (specs.image?.startsWith("http")) {
      try {
        const { data } = await axios.get(specs.image, { responseType: "arraybuffer", timeout: 15000, headers: { "User-Agent": "Mozilla/5.0" } });
        await m.reply({ image: Buffer.from(data), caption });
      } catch {
        await m.reply(caption);
      }
    } else {
      await m.reply(caption);
    }
  },
};
