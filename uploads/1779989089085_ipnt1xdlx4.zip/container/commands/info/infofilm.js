import axios from "axios";
import * as translate from "@vitalets/google-translate-api";
import { getIMDbMovie } from "../../settings/scrape/getIMDbMovie.js";

export default {
  cmd   : ["infofilm", "film"],
  tag   : "info",
  desc  : "Info film dari IMDb",
  isArgs: "❗contoh: .film Indiana jones",

  async run(m) {
    await m.reply(msg.common.wait);

    const movie = await getIMDbMovie(m.q.trim());
    if (!movie?.title) return m.reply("Film tidak ditemukan atau gagal mengambil data");

    let translatedPlot = movie.plot || "Sinopsis tidak tersedia";
    if (movie.plot?.length > 10) {
      try {
        const res = await translate.translate(movie.plot, { to: "id" });
        translatedPlot = res.text;
      } catch {}
    }

    const caption = [
      `*${movie.title}*`,
      ``,
      `*INFORMASI UMUM*`,
      `- Tahun: ${movie.year || "-"}`,
      `- Rating: ${movie.rating ? `⭐ ${movie.rating}/10` : "-"} ${movie.ratingCount ? `(${movie.ratingCount})` : ""}`,
      `- Durasi: ${movie.duration || "-"}`,
      `- Genre: ${movie.genre.length ? movie.genre.join(", ") : "-"}`,
      `- Negara: ${movie.country || "-"}`,
      `- Bahasa: ${movie.language || "-"}`,
      ``,
      `*PRODUKSI*`,
      `- Sutradara: ${movie.director.length ? movie.director.join(", ") : "-"}`,
      `- Pemeran: ${movie.cast.length ? movie.cast.join(", ") : "-"}`,
      `- Tanggal Rilis: ${movie.releaseDate || "-"}`,
      ``,
      `*BOX OFFICE*`,
      `- Budget: ${movie.budget || "-"}`,
      `- Pendapatan: ${movie.boxOffice || "-"}`,
      ``,
      `*SINOPSIS*`,
      translatedPlot,
    ].join("\n");

    if (movie.poster?.startsWith("http")) {
      try {
        const { data } = await axios.get(movie.poster, { responseType: "arraybuffer", timeout: 15000, headers: { "User-Agent": "Mozilla/5.0" } });
        await m.reply({ image: Buffer.from(data), caption });
      } catch {
        await m.reply(caption);
      }
    } else {
      await m.reply(caption);
    }
  },
};
