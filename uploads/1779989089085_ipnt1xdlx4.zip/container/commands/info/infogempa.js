import axios from "axios";

const URLS = {
  auto     : "https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json",
  terkini  : "https://data.bmkg.go.id/DataMKG/TEWS/gempaterkini.json",
  dirasakan: "https://data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json",
};

const SHAKEMAP_BASE = "https://data.bmkg.go.id/DataMKG/TEWS/";

const HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
};

async function fetchJSON(url) {
  const { data } = await axios.get(url, { timeout: 30000, headers: HEADERS });
  return data;
}

async function getGempaAuto() {
  const data  = await fetchJSON(URLS.auto);
  const gempa = data?.Infogempa?.gempa;
  if (!gempa) throw new Error("data gempa tidak ditemukan");
  return gempa;
}

async function getGempaTerkini() {
  const data = await fetchJSON(URLS.terkini);
  return data?.Infogempa?.gempa || [];
}

async function getGempaDirasakan() {
  const data = await fetchJSON(URLS.dirasakan);
  return data?.Infogempa?.gempa || [];
}

function formatGempa(g) {
  return (
    `tanggal  : ${g.Tanggal} ${g.Jam}\n` +
    `magnitudo: ${g.Magnitude}\n` +
    `kedalaman: ${g.Kedalaman}\n` +
    `wilayah  : ${g.Wilayah}\n` +
    `potensi  : ${g.Potensi || "-"}\n` +
    `koordinat: ${g.Lintang}, ${g.Bujur}`
  );
}

export default {
  cmd : ["infogempa", "gempa"],
  tag : "info",
  desc: "Info gempa terkini dari BMKG",

  async run(m) {
    await m.reply(msg.common.wait);

    const sub = m.args[0]?.toLowerCase() || "auto";

    try {
      if (sub === "terkini") {
        const list = await getGempaTerkini();
        const top5 = list.slice(0, 5);
        const text = top5.map((g, i) =>
          `[ ${i + 1} ]\n` + formatGempa(g)
        ).join("\n\n");
        return m.reply(`*Gempa Terkini (5 terakhir)*\n\n${text}`);
      }

      if (sub === "dirasakan") {
        const list = await getGempaDirasakan();
        const top5 = list.slice(0, 5);
        const text = top5.map((g, i) =>
          `[ ${i + 1} ]\n` + formatGempa(g)
        ).join("\n\n");
        return m.reply(`*Gempa Dirasakan (5 terakhir)*\n\n${text}`);
      }

      // default: auto (gempa terbaru + shakemap)
      const gempa = await getGempaAuto();
      const text  = formatGempa(gempa);

      if (gempa.Shakemap) {
        const imgUrl = SHAKEMAP_BASE + gempa.Shakemap;
        return m.reply({ image: { url: imgUrl }, caption: `*Gempa Terbaru*\n\n${text}` });
      }

      return m.reply(`*Gempa Terbaru*\n\n${text}`);

    } catch (e) {
      return m.reply(msg.common.error(e));
    }
  },
};
