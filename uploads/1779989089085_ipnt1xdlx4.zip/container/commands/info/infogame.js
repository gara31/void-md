import axios from "axios";
import { getRAWGGame } from "../../settings/scrape/getRAWGGame.js";

export default {
  cmd   : ["infogame", "game"],
  tag   : "info",
  desc  : "Info game dari RAWG",
  isArgs: "❗contoh: .game God of War",

  async run(m) {
    await m.reply(msg.common.wait);

    const game = await getRAWGGame(m.q.trim());
    if (!game?.title) return m.reply("Game tidak ditemukan atau gagal mengambil data");

    const fmt = (arr) => arr.length ? arr.join(", ") : "-";

    const caption = [
      `*${game.title}*`,
      ``,
      `*INFORMASI UMUM*`,
      `- Platform: ${fmt(game.platform)}`,
      `- Metascore: ${game.metascore}`,
      `- Genre: ${fmt(game.genre)}`,
      `- Tanggal Rilis: ${game.releaseDate}`,
      `- Rating Usia: ${game.ageRating}`,
      ``,
      `*PRODUKSI*`,
      `- Developer: ${fmt(game.developer)}`,
      `- Publisher: ${fmt(game.publisher)}`,
      ``,
      `*TAG GAME*`,
      `- ${fmt(game.tags)}`,
      ``,
      `*TENTANG GAME*`,
      game.translatedAbout,
    ].join("\n");

    if (game.image?.startsWith("http")) {
      try {
        const { data } = await axios.get(game.image, { responseType: "arraybuffer", timeout: 15000, headers: { "User-Agent": "Mozilla/5.0" } });
        await m.reply({ image: Buffer.from(data), caption });
      } catch {
        await m.reply(caption);
      }
    } else {
      await m.reply(caption);
    }
  },
};
