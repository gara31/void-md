import axios from "axios";

const BASE_CSV  = "https://raw.githubusercontent.com/kodewilayah/permendagri-72-2019/main/dist/base.csv";
const BMKG_URL  = "https://api.bmkg.go.id/publik/prakiraan-cuaca";

function determineBMKGUrl(code) {
  const dots    = (code.match(/\./g) || []).length;
  const admLevel = dots + 1;
  return `${BMKG_URL}?adm${admLevel}=${code}`;
}

function calcSimilarity(query, target) {
  const q = query.toLowerCase();
  const t = target.toLowerCase();
  const qWords = q.split(" ").filter(w => w.length > 0);
  const tWords = t.split(" ").filter(w => w.length > 0);

  let score = 0, bonus = 0;
  for (const qw of qWords) {
    let best = 0;
    for (const tw of tWords) {
      if (qw === tw) { best = 1; bonus += 0.2; break; }
      if (tw.includes(qw) || qw.includes(tw)) {
        const s = Math.min(qw.length, tw.length) / Math.max(qw.length, tw.length);
        best = Math.max(best, s);
      }
    }
    score += best;
  }
  return score / qWords.length + bonus;
}

async function searchWilayah(query) {
  const { data } = await axios.get(BASE_CSV, { timeout: 30000 });
  const rows     = data.split("\n");
  const results  = [];
  const threshold = query.length <= 4 ? 0.4 : 0.3;

  for (const row of rows) {
    if (!row.trim()) continue;
    const [kode, nama] = row.split(",");
    if (!nama) continue;
    const score = calcSimilarity(query, nama);
    if (score > threshold) results.push({ kode, nama: nama.trim(), score });
  }

  results.sort((a, b) => b.score - a.score);
  return results.slice(0, 5);
}

async function getWeather(kode) {
  const url     = determineBMKGUrl(kode);
  const { data } = await axios.get(url, { timeout: 30000 });
  return data.data;
}

function formatWeather(weatherData, namaWilayah) {
  if (!weatherData || !weatherData[0]) return "data cuaca tidak tersedia";

  const lokasi  = weatherData[0];
  const prakiraan = lokasi?.cuaca?.[0]?.[0];

  if (!prakiraan) return "data prakiraan tidak tersedia";

  return (
    `wilayah  : ${namaWilayah}\n` +
    `cuaca    : ${prakiraan.weather_desc || "-"}\n` +
    `suhu     : ${prakiraan.t || "-"}°C\n` +
    `kelembapan: ${prakiraan.hu || "-"}%\n` +
    `angin    : ${prakiraan.ws || "-"} km/h ${prakiraan.wd || ""}\n` +
    `visibilitas: ${prakiraan.vs_text || "-"}\n` +
    `waktu    : ${prakiraan.local_datetime || "-"}`
  );
}

export default {
  cmd   : ["infocuaca", "cuaca"],
  tag   : "info",
  desc  : "Info cuaca wilayah Indonesia dari BMKG",
  isArgs: "❗masukkan nama wilayah, contoh: .cuaca jakarta",

  async run(m) {
    await m.reply(msg.common.wait);

    const query = m.q.trim();

    let wilayahList;
    try {
      wilayahList = await searchWilayah(query);
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    if (!wilayahList.length) return m.reply("wilayah tidak ditemukan, coba nama yang lebih spesifik");

    const top = wilayahList[0];

    let weatherData;
    try {
      weatherData = await getWeather(top.kode);
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    const text = formatWeather(weatherData, top.nama);
    await m.reply(text);
  },
};
