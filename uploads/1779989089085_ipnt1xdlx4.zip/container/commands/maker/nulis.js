import { createCanvas, loadImage, registerFont } from "canvas";

function wrapText(ctx, text, maxChars) {
  const words = text.split(" ");
  const lines = [];
  let line = "";
  for (const word of words) {
    if ((line + word).length > maxChars) {
      lines.push(line.trim());
      line = word + " ";
    } else {
      line += word + " ";
    }
  }
  if (line) lines.push(line.trim());
  return lines;
}

function drawMultiline(ctx, lines, x, y, lineHeight) {
  for (let i = 0; i < lines.length; i++) {
    ctx.fillText(lines[i], x, y + i * lineHeight);
  }
}

export default {
  cmd: ["nulis"],
  tag: "maker",
  desc: "Buat teks di atas kertas tulis",
  isArgs: "❗ketik teks yang mau ditulis",

  async run(m) {
    try {
      registerFont("settings/font/Zahraaa.ttf", { family: "Zahraaa" });

      const background = await loadImage("https://raw.githubusercontent.com/gara31/void-md/main/uploads/1778979699932_u85dnbzbw98.jpg");
      const canvas = createCanvas(background.width, background.height);
      const ctx = canvas.getContext("2d");

      ctx.drawImage(background, 0, 0);

      const d = new Date();
      const tgl = d.toLocaleDateString("id-Id");
      const hari = d.toLocaleDateString("id-Id", { weekday: "long" });

      ctx.fillStyle = "black";
      ctx.font = "20px Zahraaa";
      ctx.fillText(hari, 806, 78);
      ctx.font = "18px Zahraaa";
      ctx.fillText(tgl, 806, 102);

      ctx.font = "20px Zahraaa";
      const wrapped = wrapText(ctx, m.q, 43);
      drawMultiline(ctx, wrapped, 344, 142, 24);

      const buffer = canvas.toBuffer("image/jpeg");
      await m.reply({ image: buffer });
    } catch (e) {
      return m.reply(msg.common.error(e));
    }
  },
};