import { createCanvas, loadImage, registerFont } from "canvas";
import assets from "@putuofc/assetsku";

registerFont(assets.font.get("HELVETICANEUEMED"), { family: "HelveticaNeueMed" });

export default {
  cmd    : ["stolol"],
  tag    : "maker",
  desc   : "Buat sertifikat tolol",
  isArgs : "❗masukkan nama penerima sertifikat!",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const text   = m.q.trim();
      if (text.length > 100) return m.reply("❗ teks maksimal 100 karakter");

      const image  = await loadImage(assets.image.get("SERTIFIKATTOLOL"));
      const canvas = createCanvas(image.width, image.height);
      const ctx    = canvas.getContext("2d");

      ctx.drawImage(image, 0, 0, image.width, image.height);

      const fontSize = 50;
      ctx.font      = `${fontSize}px "HelveticaNeueMed"`;
      ctx.fillStyle = "white";
      ctx.textAlign = "center";

      const metrics    = ctx.measureText(text);
      const textHeight = metrics.actualBoundingBoxAscent + metrics.actualBoundingBoxDescent;
      const x          = image.width / 2;
      const y          = image.height / 2 + textHeight / 2 - 10;

      ctx.fillText(text, x, y);

      const result = canvas.toBuffer("image/jpeg");
      const url    = await uguu(result);

      await m.reply({ image: { url }, caption: "" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};