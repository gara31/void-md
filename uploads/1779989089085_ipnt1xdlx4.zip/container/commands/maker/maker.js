import axios         from "axios";
import { readFileSync } from "fs";

async function getBuffer(url) {
  const { data } = await axios.get(url, { responseType: "arraybuffer" });
  return Buffer.from(data);
}

async function fetchBrat(text) {
  const url      = `https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=false&delay=500`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Brat API gagal: ${response.status}`);
  return Buffer.from(await response.arrayBuffer());
}

async function enhanceHD(imageBuffer) {
  const form = new FormData();
  form.append("method", "1");
  form.append("is_pro_version", "false");
  form.append("is_enhancing_more", "false");
  form.append("max_image_size", "high");
  form.append("file", new Blob([imageBuffer]), `img_${Date.now()}.jpg`);

  const { data } = await axios.post("https://ihancer.com/api/enhance", form, {
    headers: {
      "accept-encoding": "gzip",
      host             : "ihancer.com",
      "user-agent"     : "Dart/3.5 (dart:io)",
    },
    responseType: "arraybuffer",
  });

  return Buffer.from(data);
}

function termaiToken() {
  const b64      = Buffer.from(String(Date.now())).toString("base64");
  const charCode = [...b64].map(c => c.charCodeAt(0)).join(",");
  const b64again = Buffer.from(charCode).toString("base64");
  return Buffer.from(b64again, "base64").toString("utf16le");
}

export const bratCommand = {
  cmd   : ["brat", "bart", "bratgenerator"],
  tag   : "maker",
  desc  : "Generate brat sticker dari teks",
  isArgs: "❗masukkan teksnya dulu",

  async run(m) {
    await m.reply(msg.common.wait);

    const imageBuffer = await fetchBrat(m.q.trim());
    const enhanced    = await enhanceHD(imageBuffer);

    const stickerPath = await writeExifImg(enhanced, {
      packname: cfg.sticker.packname,
      author  : cfg.sticker.author,
    });

    await m.reply({ sticker: readFileSync(stickerPath) });
  },
};

export const bratvidCommand = {
  cmd   : ["bratvid", "bratvideo"],
  tag   : "maker",
  desc  : "Generate brat video sticker dari teks",
  isArgs: "❗masukkan teksnya dulu",

  async run(m) {
    const text = m.q.split("--")[0].trim();
    await m.reply(msg.common.wait);

    const buff = await getBuffer(
      `https://brat.siputzx.my.id/gif?text=${encodeURIComponent(text)}`
    );

    const stickerPath = await writeExifVid(buff, {
      packname: cfg.sticker.packname,
      author  : cfg.sticker.author,
    });

    await m.reply({ sticker: readFileSync(stickerPath) });
  },
};

export const stickerCommand = {
  cmd  : ["s", "sticker", "stiker"],
  tag  : "maker",
  desc : "Buat sticker dari gambar atau video",
  model: ["image", "video"],

  async run(m) {
    await m.reply(msg.common.wait);

    if (m.isVideo) {
      const videoMeta = m.raw.message?.[m.type] ?? m.quoted?.[m.quotedType] ?? null;
      if ((videoMeta?.seconds ?? 0) > 10) return m.reply("❗video terlalu panjang, maksimal 10 detik");
    }

    const media       = await m.download();
    const fn          = m.isVideo ? writeExifVid : writeExifImg;
    const stickerPath = await fn(media, {
      packname: cfg.sticker.packname,
      author  : cfg.sticker.author,
    });

    await m.reply({ sticker: readFileSync(stickerPath) });
  },
};

export const stickerWmCommand = {
  cmd   : ["wm", "swm"],
  tag   : "maker",
  desc  : "Buat sticker dengan watermark custom",
  model : ["image", "video", "sticker"],
  isArgs: "❗sertakan teks sebagai watermark\ncontoh: .wm NamaPack",

  async run(m) {
    await m.reply(msg.common.wait);

    if (m.isVideo) {
      const videoMeta = m.raw.message?.[m.type] ?? m.quoted?.[m.quotedType] ?? null;
      if ((videoMeta?.seconds ?? 0) > 10) return m.reply("❗video terlalu panjang, maksimal 10 detik");
    }

    const isInputSticker = m.quotedType === "stickerMessage" || m.type === "stickerMessage";
    const isAnimated     = isInputSticker
      ? (m.quoted?.stickerMessage?.isAnimated ?? m.raw.message?.stickerMessage?.isAnimated ?? false)
      : false;

    const media = await m.download();


    const fn          = (m.isVideo || isAnimated) ? writeExifVid : writeExifImg;
    const stickerPath = await fn(
      media,
      {
        packname: m.q.trim(),
        author  : m.pushName ?? "",
      },
      isInputSticker
    );

    await m.reply({ sticker: readFileSync(stickerPath) });
  },
};

export const smemeCommand = {
  cmd   : ["smeme", "stickermeme", "stikermeme"],
  tag   : "maker",
  desc  : "Buat sticker meme dari gambar",
  model : ["image", "sticker"],
  isArgs: "❗masukkan teksnya, format: teks1|teks2",

  async run(m) {
    await m.reply(msg.common.wait);

    const [txt1, txt2] = m.q.split("|");
    const top = (txt2 ? txt1 : "_").replace(/ /g, "_").replace(/\?/g, "~q").replace(/&/g, "~a");
    const bot = (txt2 ? txt2 : txt1).replace(/ /g, "_").replace(/\?/g, "~q").replace(/&/g, "~a");

    const media  = await m.download();
    const cdnUrl = await uguu(media);
    const buff   = await getBuffer(`https://api.memegen.link/images/custom/${top}/${bot}.png?background=${cdnUrl}`);

    const stickerPath = await writeExifImg(buff, {
      packname: cfg.sticker.packname,
      author  : cfg.sticker.author,
    });

    await m.reply({ sticker: readFileSync(stickerPath) });
  },
};

export const qcCommand = {
  cmd   : ["qc", "quoted"],
  tag   : "maker",
  desc  : "Buat quote card sticker",
  isArgs: "❗masukkan warna dan teks\\ncontoh: pink halo dunia\\n\\nwarna: pink, blue, red, green, yellow, purple, black, white, dll",

  async run(m) {
    await m.reply(msg.common.wait);

    const colors = {
      pink: "#f68ac9", blue: "#6cace4", red: "#f44336", green: "#4caf50",
      yellow: "#ffeb3b", purple: "#9c27b0", darkblue: "#0d47a1", lightblue: "#03a9f4",
      grey: "#9e9e9e", orange: "#ff9800", black: "#000000", white: "#ffffff",
      teal: "#008080", lightred: "#FFC0CB", brown: "#A52A2A", salmon: "#FFA07A",
      magenta: "#FF00FF", deeppink: "#FF1493", fire: "#B22222", skyblue: "#00BFFF",
      hotpink: "#FF69B4", cyan: "#48D1CC", darkpurple: "#BA55D3", gold: "#FFD700",
      silver: "#C0C0C0",
    };

    const [color, ...rest] = m.q.split(" ");
    const text             = colors[color] ? rest.join(" ") : m.q;
    const bgColor          = colors[color] || "#ffffff";

    let avatar;
    try {
      avatar = await m.gara.profilePictureUrl(m.quoted?.key?.participant || m.sender, "image");
    } catch {
      avatar = "https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg";
    }

    const payload = {
      type           : "quote",
      format         : "png",
      backgroundColor: bgColor,
      width          : 700,
      height         : 580,
      scale          : 2,
      messages       : [{
        entities: [],
        avatar  : true,
        from    : { id: 1, name: m.pushName, photo: { url: avatar } },
        text,
        "m.replyMessage": {},
      }],
    };

    const { data } = await axios.post("https://bot.lyo.su/quote/generate", payload, {
      headers: { "Content-Type": "application/json" },
    });

    const buff        = Buffer.from(data.result.image, "base64");
    const stickerPath = await writeExifImg(buff, {
      packname: cfg.sticker.packname,
      author  : cfg.sticker.author,
    });

    await m.reply({ sticker: readFileSync(stickerPath) });
  },
};

export const iqcCommand = {
  cmd   : ["iqc", "iqc-wa"],
  tag   : "maker",
  desc  : "Buat fake iMessage/WA bubble\\ncontoh: iqc halo --timestamp=19:00",
  isArgs: "❗masukkan teksnya dulu",

  async run(m) {
    await m.reply(msg.common.wait);

    const text      = m.q.split("--")[0].trim();
    const emoji     = m.cmd.includes("wa") ? "whatsapp" : "ios";
    const tsMatch   = m.q.match(/--timestamp=([^\s-]+)/);
    const now       = new Date();
    const h         = String(now.getHours()).padStart(2, "0");
    const min       = String(now.getMinutes()).padStart(2, "0");
    const timestamp = tsMatch ? tsMatch[1] : `${h}:${min}`;

    await m.reply({
      image: { url: `${api.xterm.url}/api/maker/iqc?text=${encodeURIComponent(text)}&emojiType=${emoji}&timestamp=${timestamp}&key=${api.xterm.key}` },
    });
  },
};

export const nglCommand = {
  cmd   : ["ngl", "fake-ngl"],
  tag   : "maker",
  desc  : "Buat fake NGL message\\ncontoh: ngl halo --emoji=ios --backgroundColor=dark",
  isArgs: "❗masukkan teksnya dulu",

  async run(m) {
    await m.reply(msg.common.wait);

    const args            = m.q.replace(/#/g, "%23");
    const text            = args.split("--")[0].trim();
    const emoji           = args.includes("--emoji=") ? args.split("--emoji=")[1].split("--")[0].trim() : "ios";
    const backgroundColor = args.includes("--backgroundColor=") ? args.split("--backgroundColor=")[1].split("--")[0].trim() : "light";

    await m.reply({
      image: { url: `${api.xterm.url}/api/maker/ngl?text=${encodeURIComponent(text)}&emojiType=${emoji}&backgroundColor=${backgroundColor}&key=${api.xterm.key}` },
    });
  },
};

export const emojimixCommand = {
  cmd   : ["emojimix"],
  tag   : "maker",
  desc  : "Campur dua emoji jadi sticker\\ncontoh: emojimix 😭+😂",
  isArgs: "❗masukkan dua emoji dipisah +\\ncontoh: 😭+😂",

  async run(m) {
    await m.reply(msg.common.wait);

    const [a, b] = m.q.split("+");
    if (!a || !b) return m.reply("❗format salah, contoh: 😭+😂");

    const res = await fetch(
      `https://tenor.googleapis.com/v2/featured?key=AIzaSyC-P6_qz3FzCoXGLk6tgitZo4jEJ5mLzD8&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(a)}_${encodeURIComponent(b)}`
    ).then(r => r.json());

    if (!res.results?.length) return m.reply("❗emoji tidak support digabung");

    for (const item of res.results) {
      const buff        = await getBuffer(item.url);
      const stickerPath = await writeExifImg(buff, {
        packname: cfg.sticker.packname,
        author  : cfg.sticker.author,
      });
      await m.reply({ sticker: readFileSync(stickerPath) });
      await sleep(500);
    }
  },
};

export const triggeredCommand = {
  cmd   : ["triggered", "triggered-image", "triggered-video"],
  tag   : "maker",
  desc  : "Buat sticker triggered dari gambar",
  model : ["image", "sticker"],

  async run(m) {
    await m.reply(msg.common.wait);

    const type   = m.cmd === "triggered-video" ? "video" : "image";
    const media  = await m.download();
    const cdnUrl = await uguu(media);
    const buff   = await getBuffer(`${api.xterm.url}/api/maker/triggered-${type}?url=${cdnUrl}&key=${api.xterm.key}`);

    const fn          = type === "video" ? writeExifVid : writeExifImg;
    const stickerPath = await fn(buff, {
      packname: cfg.sticker.packname,
      author  : cfg.sticker.author,
    });

    await m.reply({ sticker: readFileSync(stickerPath) });
  },
};