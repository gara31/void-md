import { processMedia } from "../../handlers/ffmpeg.js";

export default {
  cmd : ["toimg", "s2img"],
  tag : "converter",
  desc: "Convert stiker jadi gambar PNG",

  async run(m) {
    if (m.isVideo) {
      return m.reply("❗ *toimg* cuma support stiker/gambar, bukan video atau GIF.");
    }

    if (!m.isSticker && !m.isImage) {
      return m.reply("❗ Kirim atau reply *stiker* buat diconvert ke gambar.");
    }

    if (m.isSticker) {
      const rawMsg   = m.raw?.message;
      const stickerMsg =
        rawMsg?.stickerMessage ??
        rawMsg?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage ??
        m.quoted?.stickerMessage ??
        null;

      if (stickerMsg?.isAnimated) {
        return m.reply("❗ Stiker animasi/gerak nggak didukung.");
      }
    }

    await m.reply(msg.common.wait);

    try {
      const buffer = await m.download();
      const pngBuf = await processMedia(buffer, [], "png");
      await m.reply({ image: pngBuf, caption: "" });
    } catch (e) {
      await m.reply(`❗ Gagal convert: ${e.message}`);
    }
  },
};