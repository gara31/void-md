import { toMp3 } from "../../handlers/ffmpeg.js";

export default {
  cmd : ["tomp3"],
  tag : "converter",
  desc: "Convert video/audio jadi file MP3",

  async run(m) {
    if (!m.isVideo && !m.isAudio) {
      return m.reply("❗ Kirim atau reply *video/audio* buat diconvert ke MP3.");
    }

    await m.reply(msg.common.wait);

    try {
      const buffer = await m.download();
      const mp3Buf = await toMp3(buffer);
      await m.reply({
        document: mp3Buf,
        mimetype : "audio/mpeg",
        fileName : "audio.mp3",
      });
    } catch (e) {
      await m.reply(`❗ Gagal convert: ${e.message}`);
    }
  },
};