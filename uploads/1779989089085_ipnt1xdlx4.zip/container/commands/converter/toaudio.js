import { toMp3 } from "../../handlers/ffmpeg.js";

export default {
  cmd : ["toaudio"],
  tag : "converter",
  desc: "Convert video/audio jadi audio langsung",

  async run(m) {
    if (!m.isVideo && !m.isAudio) {
      return m.reply("❗ Kirim atau reply *video/audio* buat diconvert ke audio.");
    }

    await m.reply(msg.common.wait);

    try {
      const buffer = await m.download();
      const mp3Buf = await toMp3(buffer);
      await m.reply({
        audio   : mp3Buf,
        mimetype: "audio/mpeg",
        ptt     : false,
      });
    } catch (e) {
      await m.reply(`❗ Gagal convert: ${e.message}`);
    }
  },
};