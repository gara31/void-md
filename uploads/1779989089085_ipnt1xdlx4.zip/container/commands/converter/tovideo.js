import { webpToMp4 } from "../../handlers/sticker.js";

export default {
  cmd : ["tovideo", "tomp4"],
  tag : "converter",
  desc: "Convert stiker animasi jadi video MP4",

  async run(m) {
    if (!m.isSticker && !m.isVideo) {
      return m.reply("❗ Kirim atau reply *stiker animasi* buat diconvert ke MP4.");
    }

    if (m.isSticker) {
      const rawMsg     = m.raw?.message;
      const stickerMsg =
        rawMsg?.stickerMessage ??
        rawMsg?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage ??
        m.quoted?.stickerMessage ??
        null;

      if (!stickerMsg?.isAnimated) {
        return m.reply("❗ Stiker diam nggak bisa diconvert ke video, kirim stiker animasi/gerak.");
      }
    }

    await m.reply(msg.common.wait);

    try {
      const buffer = await m.download();
      const url    = await webpToMp4(buffer);
      await m.reply({ video: { url }, caption: "", mimetype: "video/mp4" });
    } catch (e) {
      await m.reply(`❗ Gagal convert: ${e.message}`);
    }
  },
};