import axios from "axios";

async function searchLyrics(title) {
  const { data } = await axios.get(`https://lrclib.net/api/search?q=${encodeURIComponent(title)}`, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
    },
  });

  if (!data || !data[0]) throw new Error("lirikna teu kapanggih");

  const song       = data[0];
  const lyricsRaw  = song.plainLyrics || song.syncedLyrics;

  if (!lyricsRaw) throw new Error("aya laguna tapi euweuh lirikna");

  const cleanLyrics = lyricsRaw.replace(/\[.*?\]/g, "").trim();

  return {
    trackName : song.trackName,
    artistName: song.artistName,
    albumName : song.albumName,
    duration  : song.duration,
    lyrics    : cleanLyrics,
  };
}

function formatDuration(seconds) {
  if (!seconds) return "-";
  const m = Math.floor(seconds / 60);
  const s = String(seconds % 60).padStart(2, "0");
  return `${m}:${s}`;
}

export default {
  cmd : ["lirik", "lyrics"],
  tag : "search",
  desc: "Cari lirik lagu",
  isArgs: "❗judul lagunya apa?",

  async run(m) {
    await m.reply(msg.common.wait);

    let result;
    try {
      result = await searchLyrics(m.q.trim());
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    const header =
      `judul   : ${result.trackName}\n` +
      `artis   : ${result.artistName}\n` +
      `album   : ${result.albumName || "-"}\n` +
      `durasi  : ${formatDuration(result.duration)}\n\n`;

    const disclaimer = "\n\n---\n_Educational Purpose Only_";
    const full       = header + result.lyrics + disclaimer;

    const MAX = 3000;
    if (full.length <= MAX) {
      return m.reply(full);
    }

    const chunks = [];
    let remaining = full;
    while (remaining.length > 0) {
      chunks.push(remaining.slice(0, MAX));
      remaining = remaining.slice(MAX);
    }

    for (let i = 0; i < chunks.length; i++) {
      await m.reply(`[${i + 1}/${chunks.length}]\n\n` + chunks[i]);
      if (i < chunks.length - 1) await sleep(1000);
    }
  },
};
