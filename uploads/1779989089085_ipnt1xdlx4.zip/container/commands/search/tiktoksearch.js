function formatDuration(sec = 0) {
  const m = Math.floor(sec / 60).toString().padStart(2, "0");
  const s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default {
  cmd: ["ttsearch", "tiktoksearch"],
  tag: "search",
  desc: "Cari video TikTok secara acak",
  isArgs: "❗cari video apa",

  async run(m) {
    await m.reply(msg.common.wait);

    const query = m.q.trim();

    let videos;
    try {
      const res = await fetch(`https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(query)}&count=10&cursor=0&web=1`).then(r => r.json());
      videos = res?.data?.videos;
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    if (!videos?.length) return m.reply(msg.common.notFound);

    const pick = videos[Math.floor(Math.random() * videos.length)];

    let data;
    try {
      const res = await fetch(`https://www.tikwm.com/api/?url=https://www.tiktok.com/@${pick.author.unique_id}/video/${pick.video_id}&hd=1`).then(r => r.json());
      data = res.data;
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    if (!data?.play) return m.reply(msg.common.notFound);

    await m.reply({ video: { url: data.play } });
  },
};
