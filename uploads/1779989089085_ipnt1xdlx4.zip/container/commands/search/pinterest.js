import axios from "axios";
import https  from "https";

const agent = new https.Agent({
  rejectUnauthorized: true,
  maxVersion        : "TLSv1.3",
  minVersion        : "TLSv1.2",
});

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

async function pinterestTermai(query, limit) {
  const res = await fetch(`${api.xterm.url}/api/search/pinterest-image?query=${encodeURIComponent(query)}&key=${api.xterm.key}`)
    .then(r => r.json());
  if (!res?.data?.length) throw new Error("tidak ditemukan");
  return shuffle(res.data).slice(0, limit);
}

async function pinterestScrape(query, limit) {
  const page = Math.floor(Math.random() * 5);

  const { data } = await axios.get("https://www.pinterest.com/resource/BaseSearchResource/get/", {
    httpsAgent: agent,
    headers: {
      accept                      : "application/json, text/javascript, */*, q=0.01",
      "accept-encoding"           : "gzip, deflate",
      "accept-language"           : "en-US,en;q=0.9",
      dnt                         : "1",
      referer                     : "https://www.pinterest.com/",
      "sec-ch-ua"                 : '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133"',
      "sec-ch-ua-mobile"          : "?0",
      "sec-ch-ua-platform"        : '"Windows"',
      "sec-fetch-dest"            : "empty",
      "sec-fetch-mode"            : "cors",
      "sec-fetch-site"            : "same-origin",
      "user-agent"                : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0",
      "x-app-version"             : "c056fb7",
      "x-pinterest-appstate"      : "active",
      "x-pinterest-pws-handler"   : "www/[username]/[slug].js",
      "x-pinterest-source-url"    : "/hargr003/cat-pictures/",
      "x-requested-with"          : "XMLHttpRequest",
    },
    params: {
      source_url: "/search/pins/?q=" + encodeURIComponent(query),
      data: JSON.stringify({
        options: {
          isPrefetch                  : false,
          query,
          scope                       : "pins",
          no_fetch_context_on_resource: false,
          page_size                   : 25,
          offset                      : page * 25,
        },
        context: {},
      }),
      _: Date.now() + Math.floor(Math.random() * 9999),
    },
  });

  const results = data.resource_response?.data?.results ?? [];
  if (!results.length) throw new Error(`gambar "${query}" nggak ketemu`);

  return shuffle(
    results
      .filter(v => v.images?.["736x"] || v.images?.orig)
      .map(v => v.images?.["736x"]?.url ?? v.images?.orig?.url)
  ).slice(0, limit);
}

async function downloadBuffer(url) {
  const { data } = await axios.get(url, {
    responseType: "arraybuffer",
    headers: {
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
      referer     : "https://www.pinterest.com/",
    },
  });
  return Buffer.from(data);
}

export default {
  cmd   : ["pin", "pinterest"],
  tag   : "search",
  desc  : "Cari gambar dari Pinterest",
  isArgs: "❗ cari gambar apa?",

  async run(m) {
    const parts = m.q.split(",");
    const query = parts[0].trim();
    const limit = parts[1] ? Math.min(parseInt(parts[1].trim()), 10) : 1;

    await m.reply(msg.common.wait);

    let urls;
    try {
      urls = await pinterestTermai(query, limit);
    } catch {
      try {
        urls = await pinterestScrape(query, limit);
      } catch (e) {
        return m.reply(msg.common.error(e));
      }
    }

    if (!urls.length) return m.reply(msg.common.notFound);

    for (const url of urls) {
      try {
        const buffer = await downloadBuffer(url);
        await m.reply({ image: buffer });
      } catch {
        await m.reply({ image: { url } });
      }
      await sleep(500);
    }
  },
};