import crypto from "crypto";
import axios  from "axios";
import sharp  from "sharp";
import { generateWAMessageFromContent } from "gara";

class SaveTube {
  constructor() {
    this.ky  = "C5D58EF67A7584E4A29F6C35BBC4EB12";
    this.fmt = ["144","240","360","480","720","1080","mp3"];
    this.re  = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/;
    this.is  = axios.create({
      headers: {
        "content-type": "application/json",
        "origin"      : "https://yt.savetube.me",
        "user-agent"  : "Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0",
      },
    });
  }

  async decrypt(enc) {
    const [sr, ky] = [Buffer.from(enc, "base64"), Buffer.from(this.ky, "hex")];
    const [iv, dt] = [sr.slice(0, 16), sr.slice(16)];
    const dc = crypto.createDecipheriv("aes-128-cbc", ky, iv);
    return JSON.parse(Buffer.concat([dc.update(dt), dc.final()]).toString());
  }

  async getCdn() {
    const res = await this.is.get("https://media.savetube.vip/api/random-cdn");
    return res.data.cdn;
  }

  async download(url, format = "mp3") {
    const id = url.match(this.re)?.[3];
    if (!id) throw new Error("ID tidak bisa diambil dari URL");
    if (!this.fmt.includes(format)) throw new Error(`Format tidak valid. Pilihan: ${this.fmt.join(", ")}`);

    const cdn = await this.getCdn();
    const res = await this.is.post(`https://${cdn}/v2/info`, {
      url: `https://www.youtube.com/watch?v=${id}`,
    });
    const dec = await this.decrypt(res.data.data);
    const dl  = await this.is.post(`https://${cdn}/download`, {
      id          : id,
      downloadType: format === "mp3" ? "audio" : "video",
      quality     : format === "mp3" ? "128" : format,
      key         : dec.key,
    });

    return {
      title   : dec.title,
      thumb   : dec.thumbnail || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
      duration: dec.duration,
      format,
      url     : dl.data.data.downloadUrl,
    };
  }
}

const st = new SaveTube();

async function searchYoutube(q) {
  if (/^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\//.test(q)) return q;
  const res   = await fetch(`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`, {
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
  });
  const match = (await res.text()).match(/"videoId":"([^"]+)"/);
  if (!match) throw new Error("video tidak ditemukan");
  return `https://www.youtube.com/watch?v=${match[1]}`;
}

async function toBuffer(url) {
  const res = await axios.get(url, { responseType: "arraybuffer", timeout: 60000 });
  return Buffer.from(res.data);
}

async function getThumb(thumbUrl) {
  const res = await fetch(thumbUrl);
  return await sharp(Buffer.from(await res.arrayBuffer()))
    .resize(300, 150)
    .jpeg({ quality: 80 })
    .toBuffer();
}

async function sendInteractive(m, info, mediaContent) {
  const thumb  = await getThumb(info.thumb).catch(() => null);
  const waMsg  = generateWAMessageFromContent(m.jid, {
    interactiveMessage: {
      header: {
        subtitle          : "",
        hasMediaAttachment: false,
        locationMessage: {
          degreesLatitude : 0,
          degreesLongitude: 0,
          name            : "",
          address         : info.title || "",
          url             : `https://chat.whatsapp.com/EerBzpUuByd3GBSqXBl1bP`,
          jpegThumbnail   : thumb ? thumb.toString("base64") : "",
        },
      },
      body             : { text: "" },
      footer           : { text: "" },
      nativeFlowMessage: { buttons: [] },
    },
  }, { quoted: m.raw });

  await m.gara.relayMessage(m.jid, waMsg.message, { messageId: waMsg.key.id });
  await m.reply(mediaContent);
}

export const playCommand = {
  cmd   : ["play"],
  tag   : "search",
  desc  : "Download audio YouTube",
  isArgs: "❗mana url atau judul lagu nya",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const url    = await searchYoutube(m.q.trim());
      const info   = await st.download(url, "mp3");
      const buffer = await toBuffer(info.url);

      await sendInteractive(m, info, {
        audio  : buffer,
        mimetype: "audio/mpeg",
        ptt    : false,
      });
    } catch (e) {
      m.reply(msg.common.error(e));
    }
  },
};

export const ytmp3Command = {
  cmd   : ["ytmp3"],
  tag   : "downloader",
  desc  : "Download audio YouTube sebagai file MP3",
  isArgs: "❗mana url atau judul lagu nya",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const url    = await searchYoutube(m.q.trim());
      const info   = await st.download(url, "mp3");
      const buffer = await toBuffer(info.url);

      await sendInteractive(m, info, {
        document: buffer,
        mimetype: "audio/mpeg",
        fileName: `${info.title || "audio"}.mp3`,
      });
    } catch (e) {
      m.reply(msg.common.error(e));
    }
  },
};

export const ytmp4Command = {
  cmd   : ["ytmp4", "yt"],
  tag   : "downloader",
  desc  : "Download video YouTube",
  isArgs: "❗mana url youtube nya",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const info   = await st.download(m.q.trim(), "720");
      const buffer = await toBuffer(info.url);

      await sendInteractive(m, info, {
        video  : buffer,
        mimetype: "video/mp4",
      });
    } catch (e) {
      m.reply(msg.common.error(e));
    }
  },
};