import { generateWAMessageContent } from "gara";

async function buildMessageContent(gara, content) {
  const uploadFn = gara.waUploadToServer ?? gara.uploadMedia ?? undefined;
  const opts     = uploadFn ? { upload: uploadFn } : {};

  if (typeof generateWAMessageContent === "function") return generateWAMessageContent(content, opts);

  throw new Error("gagal build message content - generateWAMessageContent tidak tersedia");
}

export default {
  cmd    : ["swgc", "statusgc", "uploadstatus"],
  tag    : "group",
  desc   : "Upload teks/media ke status grup",
  isGroup: true,
  isAdmin: true,

  async run(m) {
    const isQuotedAudio = m.quoted && /audioMessage/.test(m.quotedType);
    const isQuotedMedia = m.quoted && /imageMessage|videoMessage/.test(m.quotedType);

    if (!m.q && !isQuotedAudio) return m.reply(
      "*Cara Penggunaan:*\n" +
      ".swgc <teks>\n" +
      "Reply foto/video dengan caption: .swgc <teks>\n" +
      "Reply audio: .swgc (tanpa teks)\n\n" +
      "*Contoh:*\n" +
      ".swgc Hello everyone!\n\n" +
      "Upload teks, foto, video, atau audio ke status grup"
    );

    await m.reply(msg.common.wait);

    try {
      let content;

      if (isQuotedAudio) {
        const media = await m.download();
        if (!media) return m.reply("gagal download audio");
        content = { audio: media, mimetype: "audio/mp4", ptt: false };
      } else if (isQuotedMedia) {
        const media = await m.download();
        if (!media) return m.reply("gagal download media");
        content = /videoMessage/.test(m.quotedType)
          ? { video: media, caption: m.q }
          : { image: media, caption: m.q };
      } else {
        content = { text: m.q };
      }

      const waMsgContent = await buildMessageContent(m.gara, content);
      const innerMessage = waMsgContent?.message ?? waMsgContent;

      await m.gara.relayMessage(m.jid, {
        groupStatusMessageV2: { message: innerMessage },
      }, {});

      const tipe = content.image ? "Image"
                 : content.video ? "Video"
                 : content.audio ? "Audio"
                 : "Text";

      await m.reply(
        `*Upload Berhasil*\n\n` +
        `Status grup telah diupdate.\n` +
        `Tipe: ${tipe}`
      );
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};