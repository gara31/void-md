import { groupStore } from "../../db/groupStore.js";

export const antilinkCommand = {
  cmd: ["antilink"],
  tag: "group",
  desc: "Kelola daftar link terlarang",
  isGroup: true,
  isAdmin: true,

  async run(m) {
    const data   = groupStore.get(m.jid);
    const args   = m.q?.trim().split(/[\s,]+/).filter(Boolean) ?? [];
    const action = args[0]?.toLowerCase();
    const values = args.slice(1);

    const info = () =>
      `*Antilink* — ${data.antilink ? "✅ Aktif" : "✖️ Mati"}\n` +
      `Link dilarang:\n${data.links.length ? data.links.map(l => `  • ${l}`).join("\n") : "  (kosong)"}\n\n` +
      `Perintah:\n` +
      `▸ .antilink add <domain>\n` +
      `▸ .antilink del <domain>\n` +
      `▸ .antilink list\n\n` +
      `Aktifkan: .on antilink\n` +
      `Matikan : .off antilink`;

    if (!action) return m.reply(info());

    if (action === "add") {
      if (!values.length) return m.reply("Masukkan domain yang ingin dilarang.\nContoh: .antilink add t.me");
      const merged = [...new Set([...data.links, ...values])];
      groupStore.set(m.jid, { links: merged });
      return m.reply(`✅ Ditambahkan ke daftar terlarang: ${values.join(", ")}`);
    }

    if (action === "del" || action === "delete") {
      if (!values.length) return m.reply("Masukkan domain yang ingin dihapus.\nContoh: .antilink del t.me");
      const filtered = data.links.filter(l => !values.includes(l));
      groupStore.set(m.jid, { links: filtered });
      return m.reply(`✅ Dihapus dari daftar terlarang: ${values.join(", ")}`);
    }

    if (action === "list") {
      return m.reply(
        `*Antilink* — ${data.antilink ? "✅ Aktif" : "✖️ Mati"}\n\n` +
        `*Link dilarang:*\n${data.links.length ? data.links.map(l => `  • ${l}`).join("\n") : "  (kosong)"}`
      );
    }

    return m.reply(info());
  },
};
