import { afkStore } from "../../db/afkStore.js";

export const afkCommand = {
  cmd: ["afk"],
  tag: "group",
  desc: "Set status AFK",
  isGroup: true,

  async run(m) {
    if (afkStore.has(m.sender)) {
      return m.reply("Kamu sudah AFK. Kirim pesan dulu untuk balik.");
    }

    const reason = m.q?.trim() || "ngkk tau";
    if (reason.length > 100) return m.reply("Alasan maksimal 100 karakter.");

    afkStore.set(m.sender, reason);

    const now = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    await m.reply(
      `@${m.sender.split("@")[0]} sekarang *AFK!*\n\n` +
      `- Alasan: ${reason}\n` +
      `- Waktu: ${now}`,
      { mentions: [m.sender] }
    );
  },
};
