import { groupStore } from "../../db/groupStore.js";

const features = ["welcome", "leave", "antilink"];

const already = (feat, on) => on
  ? `*${feat}* sudah aktif di group ini`
  : `*${feat}* sudah tidak aktif di group ini`;
const ok = (feat, on) => on
  ? `Berhasil Mengaktifkan *${feat}* di group ini`
  : `Berhasil Menonaktifkan *${feat}* di group ini`;

export const onCommand = {
  cmd       : ["on"],
  tag       : "group",
  desc      : "Aktifkan fitur grup",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    const input = m.q?.trim().toLowerCase();

    if (!input || !features.includes(input)) return m.reply(
      `Fitur tersedia:\n${features.map(f => `▸ ${f}`).join("\n")}\n\nContoh: ${prefix}on welcome`
    );

    const data = groupStore.get(m.jid);
    if (data[input]) return m.reply(already(input, true));

    groupStore.set(m.jid, { [input]: true });
    m.reply(ok(input, true));
  },
};

export const offCommand = {
  cmd    : ["off"],
  tag    : "group",
  desc   : "Matikan fitur grup",
  isGroup: true,
  isAdmin: true,

  async run(m) {
    const input = m.q?.trim().toLowerCase();

    if (!input || !features.includes(input)) return m.reply(
      `Fitur tersedia:\n${features.map(f => `▸ ${f}`).join("\n")}\n\nContoh: ${prefix}off welcome`
    );

    const data = groupStore.get(m.jid);
    if (!data[input]) return m.reply(already(input, false));

    groupStore.set(m.jid, { [input]: false });
    m.reply(ok(input, false));
  },
};

export const setWelcomeCommand = {
  cmd    : ["setwelcome"],
  tag    : "group",
  desc   : "Set teks welcome",
  isGroup: true,
  isAdmin: true,

  async run(m) {
    const text = m.q?.trim();
    if (!text) return m.reply(
      `Cara pakai:\n${prefix}setwelcome <teks>\n\nPlaceholder: <members> <subject>\n\nContoh:\n${prefix}setwelcome Haii <members>, welcome di <subject>!`
    );

    groupStore.set(m.jid, { wtxt: text });
    m.reply(`Berhasil menyimpan teks *welcome*`);
  },
};

export const setLeaveCommand = {
  cmd    : ["setleave"],
  tag    : "group",
  desc   : "Set teks leave",
  isGroup: true,
  isAdmin: true,

  async run(m) {
    const text = m.q?.trim();
    if (!text) return m.reply(
      `Cara pakai:\n${prefix}setleave <teks>\n\nPlaceholder: <members> <subject>\n\nContoh:\n${prefix}setleave Bye <members>...`
    );

    groupStore.set(m.jid, { ltxt: text });
    m.reply(`Berhasil menyimpan teks *leave*`);
  },
};