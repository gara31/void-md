export const listAdminCommand = {
  cmd    : ["listadmin", "adminlist", "admins"],
  tag    : "group",
  desc   : "Lihat daftar admin grup",
  isGroup: true,

  async run(m) {
    try {
      const info = await getFullGroupInfo(m.gara, m.jid);
      if (!info) return m.reply(msg.group.metaFail);

      const botId = normJid(m.gara.user?.id ?? "");

      if (!info.admins.length) return m.reply(msg.group.noAdmin);

      const list = info.admins.map(p => {
        const resolved = resolveJid(p.id || p.lid);
        const num      = resolved.split("@")[0];
        const isSuper  = p.admin === "superadmin";
        const isBot    = normJid(resolved) === botId;
        return `${isSuper ? "⭐ [superadmin]" : "🛡️ [admin]"} @${num}${isBot ? " (bot)" : ""}`;
      }).join("\n");

      await m.reply(
        `╭─「 👥 DAFTAR ADMIN 」\n│  ${info.meta.subject}\n│\n${list.split("\n").map(l => "├ " + l).join("\n")}\n│\n├ 📊 Total: ${info.admins.length} admin\n│`,
        { mentions: info.admins.map(p => resolveJid(p.id || p.lid)) }
      );
    } catch (e) {
      m.reply(msg.group.adminFail(e));
    }
  },
};

export const listGroupCommand = {
  cmd    : ["grupinfo"],
  tag    : "group",
  desc   : "Info lengkap grup",
  isGroup: true,

  async run(m) {
    try {
      const info = await getFullGroupInfo(m.gara, m.jid);
      if (!info) return m.reply(msg.group.metaFail);

      const { meta, totalCount, adminCount, botIsAdmin } = info;
      const memberOnly = totalCount - adminCount;

      await m.reply(
        msg.info.infoGrup({ groupName: meta.subject, memberCount: totalCount, adminCount, memberOnly, isBotAdmin: botIsAdmin, isAdmin: m.isAdmin })
      );
    } catch {
      m.reply(msg.group.metaFail);
    }
  },
};

export const promoteCommand = {
  cmd       : ["promote", "pro"],
  tag       : "group",
  desc      : "Jadikan member sebagai admin grup",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    const raw = getMentions(m);
    if (!raw.length) return m.reply(msg.common.needMention);

    const botId   = normJid(m.gara.user?.id ?? "");
    const targets = (await resolveMentions(raw, m.gara, m.jid, m.groupMeta))
      .filter(t => normJid(t) !== botId);
    if (!targets.length) return;

    for (const target of targets) {
      const num = target.split("@")[0];
      try {
        const api = await toApiJid(target, m.groupMeta, m.gara, m.jid);
        await m.gara.groupParticipantsUpdate(m.jid, [api], "promote");
        await m.reply(msg.group.promoteSuccess(num), { mentions: [target] });
      } catch (e) {
        await m.reply(msg.group.promoteFail(e));
      }
    }
  },
};

export const demoteCommand = {
  cmd       : ["demote", "dem"],
  tag       : "group",
  desc      : "Turunkan admin menjadi member biasa",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    const raw = getMentions(m);
    if (!raw.length) return m.reply(msg.common.needMention);

    const botId   = normJid(m.gara.user?.id ?? "");
    const targets = (await resolveMentions(raw, m.gara, m.jid, m.groupMeta))
      .filter(t => normJid(t) !== botId);
    if (!targets.length) return;

    for (const target of targets) {
      const num = target.split("@")[0];
      try {
        const api = await toApiJid(target, m.groupMeta, m.gara, m.jid);
        await m.gara.groupParticipantsUpdate(m.jid, [api], "demote");
        await m.reply(msg.group.demoteSuccess(num), { mentions: [target] });
      } catch (e) {
        await m.reply(msg.group.demoteFail(e));
      }
    }
  },
};

export const kickCommand = {
  cmd       : ["kick", "keluarkan"],
  tag       : "group",
  desc      : "Keluarkan member dari grup",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    const raw = getMentions(m);
    if (!raw.length) return m.reply(msg.common.needMention);

    const botId   = normJid(m.gara.user?.id ?? "");
    const selfId  = normJid(m.sender);

    const targets = (await resolveMentions(raw, m.gara, m.jid, m.groupMeta))
      .filter(t => {
        if (normJid(t) === selfId) { m.reply(msg.group.cantKickSelf); return false; }
        if (normJid(t) === botId)  return false;
        return true;
      });
    if (!targets.length) return;

    for (const target of targets) {
      const num = target.split("@")[0];
      try {
        const toKick = await toApiJid(target, m.groupMeta, m.gara, m.jid);
        await m.gara.groupParticipantsUpdate(m.jid, [toKick], "remove");
        await m.reply(msg.group.kickSuccess(num), { mentions: [target] });
      } catch (e) {
        await m.reply(msg.group.kickFail(num, e?.message ?? e));
      }
    }
  },
};

export const addCommand = {
  cmd       : ["add", "tambah"],
  tag       : "group",
  desc      : "Tambahkan member baru ke grup",
  isGroup   : true,
  isOwner   : true,
  isBotAdmin: true,
  isArgs    : true,

  async run(m) {
    const numbers = m.args
      .map(n => n.replace(/[^0-9]/g, "") + "@s.whatsapp.net")
      .filter(n => n.length > 10);

    if (!numbers.length) return m.reply(msg.group.addInvalid);

    try {
      const results = await m.gara.groupParticipantsUpdate(m.jid, numbers, "add");

      const toJid = (jid) => resolveJid(jid);

      const successJids = results.filter(r => r.status === "200").map(r => toJid(r.jid));
      const failJids    = results.filter(r => r.status !== "200").map(r => toJid(r.jid));

      if (successJids.length) {
        const tags = successJids.map(j => `@${j.split("@")[0]}`).join(", ");
        await m.reply(msg.group.addSuccess(tags), { mentions: successJids });
      }
      if (failJids.length) {
        const tags = failJids.map(j => `@${j.split("@")[0]}`).join(", ");
        await m.reply(msg.group.addFail(tags), { mentions: failJids });
      }
    } catch (e) {
      await m.reply(msg.group.addFail(e?.message ?? e));
    }
  },
};

export const tagAllCommand = {
  cmd    : ["tagall", "alltag", "everyone"],
  tag    : "group",
  desc   : "Mention semua anggota grup",
  isGroup: true,

  async run(m) {
    if (!m.isAdmin && !m.isOwner) return m.reply(msg.common.onlyAdmin);

    const info = await getFullGroupInfo(m.gara, m.jid);
    if (!info) return m.reply(msg.group.metaFail);

    const mentions = info.participants.map(p => resolveJid(p.id || p.lid));
    const pesan    = m.q.trim() || msg.group.tagallText();
    const tagsText = mentions.map(j => `@${j.split("@")[0]}`).join(" ");

    await m.reply(`${pesan}\n\n${tagsText}`, { mentions });
  },
};

export const hideTagCommand = {
  cmd    : ["h", "hidetag", "ht"],
  tag    : "group",
  desc   : "Tag semua member tanpa terlihat",
  isGroup: true,

  async run(m) {
    if (!m.isAdmin && !m.isOwner) return m.reply(msg.common.onlyAdmin);

    const info = await getFullGroupInfo(m.gara, m.jid);
    if (!info) return m.reply(msg.group.metaFail);

    const mentions = info.participants.map(p => resolveJid(p.id || p.lid));
    const pesan    = m.q.trim() || msg.group.tagallText();

    await m.reply(pesan, { mentions });
  },
};

export const openCommand = {
  cmd       : ["open"],
  tag       : "group",
  desc      : "Buka grup (semua bisa kirim pesan)",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    try {
      await m.gara.groupSettingUpdate(m.jid, "not_announcement");
      await m.reply(msg.group.openSuccess);
    } catch (e) {
      await m.reply(msg.group.settingFail(e));
    }
  },
};

export const closeCommand = {
  cmd       : ["close"],
  tag       : "group",
  desc      : "Tutup grup (hanya admin yang bisa kirim)",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    try {
      await m.gara.groupSettingUpdate(m.jid, "announcement");
      await m.reply(msg.group.closeSuccess);
    } catch (e) {
      await m.reply(msg.group.settingFail(e));
    }
  },
};

export const lockCommand = {
  cmd       : ["lock"],
  tag       : "group",
  desc      : "Kunci info grup (hanya admin bisa edit)",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    try {
      await m.gara.groupSettingUpdate(m.jid, "locked");
      await m.reply(msg.group.lockSuccess);
    } catch (e) {
      await m.reply(msg.group.settingFail(e));
    }
  },
};

export const unlockCommand = {
  cmd       : ["unlock"],
  tag       : "group",
  desc      : "Buka kunci info grup (semua bisa edit)",
  isGroup   : true,
  isAdmin   : true,
  isBotAdmin: true,

  async run(m) {
    try {
      await m.gara.groupSettingUpdate(m.jid, "unlocked");
      await m.reply(msg.group.unlockSuccess);
    } catch (e) {
      await m.reply(msg.group.settingFail(e));
    }
  },
};

export const deleteCommand = {
  cmd    : ["d", "delete", "del", "hapus"],
  tag    : "group",
  desc   : "Hapus pesan",
  isAdmin: true,

  async run(m) {
    const targetKey = m._reactionTargetKey ?? m.quotedKey ?? null;
    if (!targetKey) return m.reply(msg.common.needQuoted);

    try {
      await m.gara.sendMessage(m.jid, { delete: targetKey });
    } catch (e) {
      await m.reply(e);
    }
  },
};
