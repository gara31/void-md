import fs   from "fs";
import path from "path";
import { reloadCommands, getCommands } from "../../handlers/commandHandler.js";

const COMMANDS_DIR = path.join(process.cwd(), "commands");

function extractTag(code) {
  const match = code.match(/tag\s*:\s*["']([^"']+)["']/);
  return match ? match[1].toLowerCase().trim() : null;
}

function extractCmdNames(code) {
  const match = code.match(/cmd\s*:\s*\[([^\]]+)\]/);
  if (!match) return [];
  return match[1]
    .split(",")
    .map(s => s.replace(/["'\s]/g, ""))
    .filter(Boolean);
}

export const addPluginCommand = {
  cmd    : ["addpg", "addplugin"],
  tag    : "owner",
  desc   : "Tambah plugin baru dari file .js atau code",
  isOwner: true,

  async run(m) {
    let fileName = null;
    let code     = null;

    if (m.quotedType === "documentMessage") {
      const docMsg  = m.quoted?.documentMessage ?? m.quoted;
      fileName      = docMsg?.fileName ?? docMsg?.title ?? null;
      if (!fileName?.endsWith(".js")) return m.reply("❗ file harus berekstensi .js");
      const buf     = await m.downloadQuoted();
      code          = buf.toString("utf-8");
    } else {
      const rawBody = m.body ?? "";
      const prefixCmd = rawBody.match(/^.+?\s+/)?.[0] ?? "";
      const afterCmd  = rawBody.slice(prefixCmd.length);
      const lines     = afterCmd.split("\n");
      fileName        = lines[0].trim();
      if (!fileName?.endsWith(".js")) return m.reply("format: .addpg blur.js\n<code di baris berikutnya>");
      code            = lines.slice(1).join("\n").trim();
      if (!code) return m.reply("❗ code tidak boleh kosong");
    }

    const tag = extractTag(code);
    if (!tag) return m.reply("❗ tag tidak ditemukan di dalam code");

    const tagDir = path.join(COMMANDS_DIR, tag);
    if (!fs.existsSync(tagDir)) {
      const available = fs.readdirSync(COMMANDS_DIR)
        .filter(f => fs.statSync(path.join(COMMANDS_DIR, f)).isDirectory())
        .join(", ");
      return m.reply(`❗ folder [${tag}] tidak ada\nfolder tersedia: ${available}`);
    }

    const filePath = path.join(tagDir, fileName);
    const isUpdate = fs.existsSync(filePath);

    try {
      fs.writeFileSync(filePath, code, "utf-8");
      await reloadCommands();
      const cmds = extractCmdNames(code);
      m.reply(`✅ plugin berhasil ${isUpdate ? "diupdate" : "ditambahkan"}\nfile: ${tag}/${fileName}${cmds.length ? `\ncmd: ${cmds.join(", ")}` : ""}`);
    } catch (e) {
      m.reply(`❗ gagal menyimpan file: ${e.message}`);
    }
  },
};

export const getPluginCommand = {
  cmd    : ["getpg"],
  tag    : "owner",
  desc   : "Kirim file plugin sebagai dokumen",
  isOwner: true,
  isArgs : true,

  async run(m) {
    const input = m.args[0]?.trim();
    if (!input) return m.reply("format: .gp <namafile.js> atau .gp <cmdname>");

    let filePath = null;

    if (input.endsWith(".js")) {
      filePath = findFileRecursive(COMMANDS_DIR, input);
    } else {
      const cmd = getCommands().get(input.toLowerCase());
      if (cmd?._file) filePath = cmd._file;
    }

    if (!filePath || !fs.existsSync(filePath)) return m.reply(`❗ plugin ${input} tidak ditemukan`);

    const code = fs.readFileSync(filePath, "utf-8");
    const name = path.basename(filePath);

    await m.gara.sendMessage(m.jid, {
      document : Buffer.from(code, "utf-8"),
      fileName : name,
      mimetype : "application/javascript",
      caption  : "",
    }, { quoted: m.raw });
  },
};

export const delPluginCommand = {
  cmd    : ["delpg", "delplugin"],
  tag    : "owner",
  desc   : "Hapus plugin",
  isOwner: true,
  isArgs : true,

  async run(m) {
    const input = m.args[0]?.trim();
    if (!input) return m.reply("format: .delpg <namafile.js> atau .delpg <cmdname>");

    let filePath = null;
    let fileName = null;

    if (input.endsWith(".js")) {
      filePath = findFileRecursive(COMMANDS_DIR, input);
      fileName = input;
    } else {
      const cmd = getCommands().get(input.toLowerCase());
      if (cmd?._file) { filePath = cmd._file; fileName = path.basename(cmd._file); }
    }

    if (!filePath || !fs.existsSync(filePath)) return m.reply(`❗ plugin ${input} tidak ditemukan`);

    try {
      fs.unlinkSync(filePath);
      await reloadCommands();
      m.reply(`✅ plugin ${fileName} berhasil dihapus`);
    } catch (e) {
      m.reply(`❗ gagal hapus: ${e.message}`);
    }
  },
};

function findFileRecursive(dir, name) {
  for (const item of fs.readdirSync(dir)) {
    const full = path.join(dir, item);
    if (fs.statSync(full).isDirectory()) {
      const found = findFileRecursive(full, name);
      if (found) return found;
    } else if (item === name) {
      return full;
    }
  }
  return null;
}
