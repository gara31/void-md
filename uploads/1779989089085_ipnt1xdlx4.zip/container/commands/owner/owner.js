import fs   from "fs";
import path from "path";
import { reloadCommands, getCommands } from "../../handlers/commandHandler.js";

export const clearSesiCommand = {
  cmd    : ["clearsesi", "clearsession", "csesi"],
  tag    : "owner",
  desc   : "Bersihkan file session bot",
  isOwner: true,

  async run(m) {
    const sessionPath = path.resolve(session);
    if (!fs.existsSync(sessionPath)) return;

    const files = fs.readdirSync(sessionPath).filter(f => f !== "creds.json");
    if (!files.length) return m.reply("session sudah bersih");

    for (const file of files) {
      try {
        fs.unlinkSync(path.join(sessionPath, file));
        await new Promise(r => setTimeout(r, 250));
      } catch {}
    }

    m.reply("session berhasil dibersihkan ✅");
  },
};

export const reloadCommand = {
  cmd    : ["reload", "reloadcmd"],
  tag    : "owner",
  desc   : "Reload semua command tanpa restart bot",
  isOwner: true,

  async run(m) {
    const before = getCommands().size;
    await reloadCommands();
    const after = getCommands().size;
    m.reply(`✅ reload selesai\n${before} → ${after} alias`);
  },
};
