export const addOwnerCommand = {
  cmd    : ["addowner"],
  tag    : "owner",
  desc   : "Tambah owner bot",
  isOwner: true,

  async run(m) {
    const raw = getMentions(m);
    if (!raw.length) return m.reply("tag atau reply orangnya dulu");

    const targets = await resolveMentions(raw, m.gara, m.jid, m.groupMeta);

    const toAdd = targets.filter(j => !global.owner.includes(j.split("@")[0]));
    if (!toAdd.length) return m.reply("semua yang ditag udah jadi owner");

    global.owner.push(...toAdd.map(j => j.split("@")[0]));
    saveConfig();

    const tags = toAdd.map(j => `@${j.split("@")[0]}`).join(", ");
    await m.reply(`${tags} udah ditambah jadi owner`, { mentions: toAdd });
  },
};

export const delOwnerCommand = {
  cmd    : ["delowner"],
  tag    : "owner",
  desc   : "Hapus owner bot",
  isOwner: true,

  async run(m) {
    const raw = getMentions(m);
    if (!raw.length) return m.reply("tag atau reply orangnya dulu");

    const targets = await resolveMentions(raw, m.gara, m.jid, m.groupMeta);

    const toRemove = targets.filter(j => global.owner.includes(j.split("@")[0]));
    if (!toRemove.length) return m.reply("yang ditag bukan owner");

    global.owner = global.owner.filter(n => !toRemove.map(j => j.split("@")[0]).includes(n));
    saveConfig();

    const tags = toRemove.map(j => `@${j.split("@")[0]}`).join(", ");
    await m.reply(`${tags} udah dihapus dari owner`, { mentions: toRemove });
  },
};
