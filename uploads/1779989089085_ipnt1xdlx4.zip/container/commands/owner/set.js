import { groupStore } from "../../db/groupStore.js";

export default {
  cmd    : ["set"],
  tag    : "owner",
  desc   : "Atur konfigurasi bot",
  isOwner: true,

  async run(m) {
    const [t1 = "", t2 = ""] = m.args;
    const sub  = t1.toLowerCase();
    const val  = t2.toLowerCase();
    const isOn = ["on", "true"].includes(val);
    const isOff = ["off", "false"].includes(val);

    const options = {
      public     : "mode public",
      desc       : "tampilkan deskripsi command di menu",
      autoread   : "auto read pesan",
      anticall   : "tolak panggilan masuk",
      mute       : "mute grup (blokir semua command kecuali owner)",
      verifikasi : "wajibkan verifikasi kontak sebelum pakai bot",
    };

    if (!sub || !options[sub]) {
      return m.reply(
        `┌─ [ SET ] ─\n│\n` +
        Object.entries(options)
          .map(([k, v]) => `│⇨ *${prefix}set ${k}* — ${v}`)
          .join("\n") +
        `\n│\n│⇨ Contoh: *${prefix}set desc off*\n│\n└─ _${botfullname}_`
      );
    }

    const status  = (v) => v ? "✅ ON" : "✖️ OFF";
    const header  = (title) => `┌─ [ SET ${title} ] ─\n│\n`;
    const footer  = `\n│\n└─ _${botfullname}_`;
    const current = (label) => `│⇨ Sekarang: *${label}*`;
    const already = (feat, on) => on
      ? `*${feat}* sudah aktif di group ini`
      : `*${feat}* sudah tidak aktif di group ini`;
    const ok = (feat, on) => on
      ? `Berhasil Mengaktifkan *${feat}* di group ini`
      : `Berhasil Menonaktifkan *${feat}* di group ini`;

    switch (sub) {

      case "public": {
        const label = () => {
          const p = global.cfg.public;
          if (p === "onlygc") return "🔒 ONLY GC";
          if (!p)             return "✖️ OFF (Self)";
          return "🌐 PUBLIC";
        };
        const modeLabel = { onlygc: "OnlyGC", on: "Public", off: "Self" };

        if (!val) return m.reply(
          header("PUBLIC") +
          `│⇨ *${prefix}set public onlygc* — hanya aktif di grup\n` +
          `│⇨ *${prefix}set public on*     — aktif di mana saja\n` +
          `│⇨ *${prefix}set public off*    — hanya owner (self)\n│\n` +
          current(label()) + footer
        );

        const map = { onlygc: "onlygc", on: true, off: false };
        if (!(val in map)) return m.reply(`Nilai tidak dikenal: *${val}*\nOpsi: onlygc | on | off`);

        if (global.cfg.public === map[val])
          return m.reply(`Mode *${modeLabel[val]}* sudah aktif`);

        global.cfg.public = map[val];
        saveConfig();
        return m.reply(`Berhasil mengubah mode ke *${modeLabel[val]}*`);
      }

      case "desc": {
        if (!val || (!isOn && !isOff)) return m.reply(
          header("DESC") +
          `│⇨ *${prefix}set desc on*  — tampilkan deskripsi di menu\n` +
          `│⇨ *${prefix}set desc off* — sembunyikan deskripsi di menu\n│\n` +
          current(status(global.cfg.showDesc !== false)) + footer
        );

        if (isOn  && global.cfg.showDesc !== false) return m.reply(already("desc", true));
        if (isOff && global.cfg.showDesc === false)  return m.reply(already("desc", false));

        global.cfg.showDesc = isOn;
        saveConfig();
        return m.reply(ok("desc", isOn));
      }

      case "autoread": {
        if (!val || (!isOn && !isOff)) return m.reply(
          header("AUTOREAD") +
          `│⇨ *${prefix}set autoread on*  — tandai pesan langsung terbaca\n` +
          `│⇨ *${prefix}set autoread off* — nonaktifkan\n│\n` +
          current(status(global.cfg.autoRead)) + footer
        );

        if (isOn  && global.cfg.autoRead)  return m.reply(already("autoread", true));
        if (isOff && !global.cfg.autoRead) return m.reply(already("autoread", false));

        global.cfg.autoRead = isOn;
        saveConfig();
        return m.reply(ok("autoread", isOn));
      }

      case "anticall": {
        if (!val || (!isOn && !isOff)) return m.reply(
          header("ANTICALL") +
          `│⇨ *${prefix}set anticall on*  — tolak semua panggilan masuk\n` +
          `│⇨ *${prefix}set anticall off* — nonaktifkan\n│\n` +
          current(status(global.cfg.antiCall)) + footer
        );

        if (isOn  && global.cfg.antiCall)  return m.reply(already("anticall", true));
        if (isOff && !global.cfg.antiCall) return m.reply(already("anticall", false));

        global.cfg.antiCall = isOn;
        saveConfig();
        return m.reply(ok("anticall", isOn));
      }

      case "mute": {
        if (!m.isGroup) return m.reply("Fitur mute hanya bisa digunakan di grup.");

        if (!val || (!isOn && !isOff)) return m.reply(
          header("MUTE") +
          `│⇨ *${prefix}set mute on*  — blokir semua command di grup ini\n` +
          `│⇨ *${prefix}set mute off* — aktifkan kembali\n│\n` +
          current(status(groupStore.get(m.jid).mute)) + footer
        );

        const grp = groupStore.get(m.jid);
        if (isOn  && grp.mute)  return m.reply(already("mute", true));
        if (isOff && !grp.mute) return m.reply(already("mute", false));

        groupStore.set(m.jid, { mute: isOn });
        return m.reply(ok("mute", isOn));
      }

      case "verifikasi": {
        if (!val || (!isOn && !isOff)) return m.reply(
          header("VERIFIKASI") +
          `│⇨ *${prefix}set verifikasi on*  — wajibkan verifikasi kontak\n` +
          `│⇨ *${prefix}set verifikasi off* — nonaktifkan verifikasi\n│\n` +
          current(status(global.cfg?.verify?.enabled)) + footer
        );

        if (isOn  && global.cfg?.verify?.enabled)  return m.reply(already("verifikasi", true));
        if (isOff && !global.cfg?.verify?.enabled) return m.reply(already("verifikasi", false));

        if (!global.cfg.verify) global.cfg.verify = {};
        global.cfg.verify.enabled = isOn;
        saveConfig();
        return m.reply(ok("verifikasi", isOn));
      }
    }
  },
};