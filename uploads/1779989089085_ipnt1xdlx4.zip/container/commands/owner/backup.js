import fs   from "fs";
import path from "path";
import zlib from "zlib";
import { exec } from "child_process";

function createTarGz(source, output) {
  return new Promise((resolve, reject) => {
    const srcDir   = path.resolve(source);
    const outPath  = path.resolve(output);
    const tarPath  = outPath.replace(/\.gz$/, "");
    const excludes = [
      "--exclude='node_modules'", "--exclude='.git'", "--exclude='.npm'",
      "--exclude='session/*'",
    ].join(" ");
    const credsPath = path.join(srcDir, "session", "creds.json");
    const appendCreds = fs.existsSync(credsPath)
      ? `&& tar --append -f ${tarPath} -C ${path.dirname(srcDir)} ${path.basename(srcDir)}/session/creds.json`
      : "";
    const cmd = `tar ${excludes} -cf ${tarPath} -C ${path.dirname(srcDir)} ${path.basename(srcDir)} ${appendCreds}`;
    exec(cmd, (err, _, stderr) => {
      if (err) return reject({ status: false, msg: `Gagal tar: ${stderr}` });
      const input = fs.createReadStream(tarPath);
      const out   = fs.createWriteStream(outPath);
      const gzip  = zlib.createGzip();
      input.pipe(gzip).pipe(out);
      out.on("finish", () => { fs.unlinkSync(tarPath); resolve({ status: true }); });
      out.on("error", e => reject({ status: false, msg: e.message }));
    });
  });
}

export default {
  cmd    : ["backup", "bk"],
  tag    : "owner",
  desc   : "Backup data bot",
  isOwner: true,

  async run(m) {
    const outFile = "./backup.tar.gz";
    try {
      await m.reply(msg.owner.backupStart);
      const result = await createTarGz("./", outFile);
      if (!result.status) return m.reply(result.msg);

      const sizeKB   = (fs.statSync(outFile).size / 1024).toFixed(1);
      const fileName = `${path.basename(path.resolve("."))} - ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}.tar.gz`;

      await m.reply(msg.owner.backupSending(m.isGroup));
      await m.gara.sendMessage(m.sender, { document: { url: outFile }, mimetype: "application/gzip", fileName }, { quoted: m.raw });
      await m.reply(msg.owner.backupSuccess(sizeKB, m.isGroup));
    } catch (e) {
      console.error("[BACKUP ERROR]", e);
      await m.reply(msg.owner.backupFail(e));
    } finally {
      if (fs.existsSync(outFile)) fs.unlinkSync(outFile);
    }
  },
};
