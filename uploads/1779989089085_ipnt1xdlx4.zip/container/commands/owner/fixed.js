import fs   from "fs";
import path from "path";
import { reloadCommands } from "../../handlers/commandHandler.js";

export default {
  cmd     : ["fixed"],
  tag     : "owner",
  desc    : "Upload & reload file command",
  isOwner : true,
  isQuoted: true,

  async run(m) {
    const fileName =
      m.quoted?.documentMessage?.fileName ??
      m.quoted?.fileName ??
      null;

    if (!fileName || !fileName.endsWith(".js"))
      return m.reply("Reply file .js dulu!");

    const name       = path.basename(fileName);
    const fullPath   = path.join(process.cwd(), "commands", name);
    const fileExists = fs.existsSync(fullPath);

    const buffer  = await download(m.quoted.documentMessage, "document");
    const content = buffer.toString("utf8");

    fs.writeFileSync(fullPath, content, "utf8");

    try {
      await reloadCommands(name);
      await m.reply(fileExists
        ? `*${name}* berhasil di-update & direload!`
        : `*${name}* berhasil ditambahkan & direload!`
      );
    } catch (e) {
      await m.reply(`File tersimpan tapi gagal reload:\n${e.message}`);
    }
  },
};
