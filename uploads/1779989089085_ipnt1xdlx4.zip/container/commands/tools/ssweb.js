import axios from "axios";

export default {
  cmd   : ["ssweb"],
  tag   : "tools",
  desc  : "Screenshot website dari URL",
  isArgs: "❗mana url nya",

  async run(m) {
    const url = (m.quotedUrl?.[0] || m.url?.[0]);
    if (!url) return m.reply("❗url tidak ditemukan di pesan");

    await m.reply(msg.common.wait);

    try {
      const res = await axios.get(
        "https://image.thum.io/get/width/1900/crop/1000/fullpage/" + url,
        {
          responseType  : "arraybuffer",
          timeout       : 2500000,
          headers       : {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
          },
          validateStatus: (s) => s === 200,
        }
      );

      await m.reply({ image: Buffer.from(res.data), caption: "Result" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};