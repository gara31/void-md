import axios    from "axios";
import FormData from "form-data";

async function enhanceIhancer(buffer) {
  const form = new FormData();
  form.append("method",            "1");
  form.append("is_pro_version",    "false");
  form.append("is_enhancing_more", "false");
  form.append("max_image_size",    "high");
  form.append("file", buffer, `img_${Date.now()}.jpg`);

  const { data } = await axios.post("https://ihancer.com/api/enhance", form, {
    headers: {
      ...form.getHeaders(),
      "accept-encoding": "gzip",
      "host"           : "ihancer.com",
      "user-agent"     : "Dart/3.5 (dart:io)",
    },
    responseType: "arraybuffer",
    timeout     : 30_000,
  });

  return Buffer.from(data);
}

async function enhanceRemini(buffer) {
  const url = await uguu(buffer);
  const res = await fetch(`${api.xterm.url}/api/tools/remini?url=${encodeURIComponent(url)}&key=${api.xterm.key}`)
    .then(r => r.json());
  if (!res?.data?.url) throw new Error("remini gagal");
  return res.data.url;
}

export default {
  cmd    : ["hd", "remini"],
  tag    : "tools",
  desc   : "Perjelas kualitas foto",

  async run(m) {
    if (!m.isImage && !m.isSticker) {
      return m.reply("❗ Kirim atau reply *gambar/stiker* dulu!");
    }

    if (m.isSticker) {
      const rawMsg     = m.raw?.message;
      const stickerMsg =
        rawMsg?.stickerMessage ??
        rawMsg?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage ??
        m.quoted?.stickerMessage ??
        null;

      if (stickerMsg?.isAnimated) {
        return m.reply("❗ Stiker animasi nggak bisa di-enhance, kirim stiker diam atau gambar.");
      }
    }

    await m.reply(msg.common.wait);

    const buffer = await m.download();

    try {
      const result = await enhanceIhancer(buffer);
      return m.reply({ image: result });
    } catch {}

    try {
      const url = await enhanceRemini(buffer);
      return m.reply({ image: { url } });
    } catch (e) {
      return m.reply(`❗ Gagal enhance: ${e.message}`);
    }
  },
};