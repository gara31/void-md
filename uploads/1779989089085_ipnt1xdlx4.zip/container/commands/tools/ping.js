import { createCanvas, loadImage } from "canvas";
import os                          from "os";
import axios                       from "axios";
import { performance }             from "perf_hooks";
import { execSync }                from "child_process";

function ensureRoundRect(ctx) {
  if (typeof ctx.roundRect === "function") return;
  ctx.roundRect = function (x, y, w, h, r) {
    const radius = typeof r === "number" ? { tl: r, tr: r, br: r, bl: r } : r;
    this.beginPath();
    this.moveTo(x + radius.tl, y);
    this.lineTo(x + w - radius.tr, y);
    this.quadraticCurveTo(x + w, y, x + w, y + radius.tr);
    this.lineTo(x + w, y + h - radius.br);
    this.quadraticCurveTo(x + w, y + h, x + w - radius.br, y + h);
    this.lineTo(x + radius.bl, y + h);
    this.quadraticCurveTo(x, y + h, x, y + h - radius.bl);
    this.lineTo(x, y + radius.tl);
    this.quadraticCurveTo(x, y, x + radius.tl, y);
    this.closePath();
    return this;
  };
}

async function runSpeedTest() {
  let downloadSpeed = 0, uploadSpeed = 0;
  try {
    const dlStart = performance.now();
    const dlRes   = await axios.get("https://speed.cloudflare.com/__down?bytes=10000000", {
      responseType: "arraybuffer", timeout: 20000,
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    const dlTime  = (performance.now() - dlStart) / 1000;
    downloadSpeed = dlRes.data.byteLength / (dlTime || 1);
  } catch { downloadSpeed = 0; }

  try {
    const upData  = "0".repeat(1024 * 1024);
    const upStart = performance.now();
    await axios.post("https://speed.cloudflare.com/__up", upData, {
      headers: { "Content-Length": upData.length }, timeout: 20000,
    });
    const upTime = (performance.now() - upStart) / 1000;
    uploadSpeed  = upData.length / (upTime || 1);
  } catch { uploadSpeed = 0; }

  const fmt = (b) => {
    const mbps = (b * 8) / (1024 * 1024);
    return mbps >= 1 ? `${mbps.toFixed(2)} Mbps` : `${(mbps * 1000).toFixed(2)} Kbps`;
  };
  return { dl: fmt(downloadSpeed), ul: fmt(uploadSpeed) };
}

async function getLatency(samples = 3) {
  let total = 0;
  for (let i = 0; i < samples; i++) {
    const start = performance.now();
    await axios.get("https://speed.cloudflare.com/cdn-cgi/trace", {
      timeout: 5000, headers: { "Cache-Control": "no-cache" },
    });
    total += performance.now() - start;
  }
  return total / samples;
}

function size(b) {
  const s = ["B","KB","MB","GB","TB"];
  const i = Math.floor(Math.log(b || 1) / Math.log(1024));
  return `${(b / Math.pow(1024, i)).toFixed(2)} ${s[i]}`;
}

function fmtTime(sec) {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}

function getDisk() {
  try {
    const df    = execSync("df -B1 / | tail -1").toString().trim().split(/\s+/);
    const total = parseInt(df[1] || "0");
    const used  = parseInt(df[2] || "0");
    const pct   = parseInt(String(df[4] || "0").replace("%", ""));
    return { total, used, pct: isNaN(pct) ? 0 : pct };
  } catch {
    return { total: 0, used: 0, pct: 50 };
  }
}

// ── Stars field ────────────────────────────────────────────────────────────────
function drawStars(ctx, W, H) {
  // Tiny distant stars
  for (let i = 0; i < 220; i++) {
    const x  = Math.random() * W;
    const y  = Math.random() * H * 0.72;
    const r  = Math.random() * 1.2 + 0.2;
    const a  = Math.random() * 0.7 + 0.25;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,245,235,${a})`;
    ctx.fill();
  }
  // Slightly larger glowing stars
  for (let i = 0; i < 28; i++) {
    const x = Math.random() * W;
    const y = Math.random() * H * 0.6;
    const r = Math.random() * 1.8 + 0.8;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255,240,220,0.9)`;
    ctx.shadowBlur  = 6;
    ctx.shadowColor = "rgba(255,220,180,0.8)";
    ctx.fill();
    ctx.shadowBlur  = 0;
  }
}

// ── Crescent Moon ──────────────────────────────────────────────────────────────
function drawMoon(ctx, x, y, r) {
  ctx.save();
  // Glow halo
  const halo = ctx.createRadialGradient(x, y, r * 0.5, x, y, r * 2.8);
  halo.addColorStop(0, "rgba(220,210,255,0.18)");
  halo.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = halo;
  ctx.beginPath(); ctx.arc(x, y, r * 2.8, 0, Math.PI * 2); ctx.fill();

  // Moon body
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(230,225,255,0.92)";
  ctx.shadowBlur  = 18; ctx.shadowColor = "rgba(200,190,255,0.6)";
  ctx.fill(); ctx.shadowBlur = 0;

  // Crescent cutout
  ctx.beginPath(); ctx.arc(x + r * 0.38, y - r * 0.08, r * 0.82, 0, Math.PI * 2);
  ctx.fillStyle = "#1a1535";
  ctx.fill();
  ctx.restore();
}

// ── Rising moon/sun glow on the horizon ───────────────────────────────────────
function drawRisingGlow(ctx, W, H) {
  // Large warm glow (the big moon/sun behind the mountain on the right)
  const cx = W * 0.78, cy = H * 0.82;
  const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, 340);
  glow.addColorStop(0,    "rgba(255,230,180,0.92)");
  glow.addColorStop(0.08, "rgba(255,200,140,0.8)");
  glow.addColorStop(0.22, "rgba(240,160,120,0.55)");
  glow.addColorStop(0.45, "rgba(200,110,130,0.30)");
  glow.addColorStop(0.7,  "rgba(140,80,140,0.12)");
  glow.addColorStop(1,    "rgba(0,0,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, W, H);

  // Bright core disk
  ctx.beginPath();
  ctx.arc(cx, cy, 58, 0, Math.PI * 2);
  const disk = ctx.createRadialGradient(cx, cy, 0, cx, cy, 58);
  disk.addColorStop(0,   "rgba(255,248,210,1)");
  disk.addColorStop(0.5, "rgba(255,220,160,0.95)");
  disk.addColorStop(1,   "rgba(255,190,120,0.6)");
  ctx.fillStyle   = disk;
  ctx.shadowBlur  = 60; ctx.shadowColor = "rgba(255,210,140,0.7)";
  ctx.fill(); ctx.shadowBlur = 0;
}

// ── Mountain silhouette ────────────────────────────────────────────────────────
function drawMountains(ctx, W, H) {
  // Back mountain (lighter, foggy)
  ctx.beginPath();
  ctx.moveTo(0, H);
  ctx.lineTo(W * 0.32, H * 0.44);
  ctx.bezierCurveTo(W * 0.42, H * 0.36, W * 0.55, H * 0.40, W * 0.68, H * 0.52);
  ctx.lineTo(W, H * 0.62);
  ctx.lineTo(W, H); ctx.closePath();
  const mtnBack = ctx.createLinearGradient(0, H * 0.36, 0, H);
  mtnBack.addColorStop(0, "rgba(58,52,90,0.72)");
  mtnBack.addColorStop(1, "rgba(28,22,55,0.85)");
  ctx.fillStyle = mtnBack; ctx.fill();

  // Front right mountain
  ctx.beginPath();
  ctx.moveTo(W * 0.58, H);
  ctx.lineTo(W * 0.72, H * 0.52);
  ctx.bezierCurveTo(W * 0.76, H * 0.46, W * 0.84, H * 0.50, W * 0.90, H * 0.60);
  ctx.lineTo(W, H * 0.68);
  ctx.lineTo(W, H); ctx.closePath();
  const mtnFront = ctx.createLinearGradient(0, H * 0.46, 0, H);
  mtnFront.addColorStop(0, "rgba(40,34,72,0.88)");
  mtnFront.addColorStop(1, "rgba(20,16,42,1)");
  ctx.fillStyle = mtnFront; ctx.fill();
}

// ── Pine tree silhouette helper ────────────────────────────────────────────────
function drawPine(ctx, x, baseY, height, color) {
  const w   = height * 0.38;
  const tiers = 4;
  for (let t = 0; t < tiers; t++) {
    const ty   = baseY - height * (0.22 + t * 0.22);
    const tw   = w * (1 - t * 0.18);
    const th   = height * 0.28;
    ctx.beginPath();
    ctx.moveTo(x, ty - th * 0.55);
    ctx.lineTo(x - tw / 2, ty + th * 0.45);
    ctx.lineTo(x + tw / 2, ty + th * 0.45);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
  }
  // trunk
  ctx.fillStyle = color;
  ctx.fillRect(x - width * 0.012, baseY - height * 0.12, width * 0.024, height * 0.12);
}

// ── Forest silhouette band ─────────────────────────────────────────────────────
function drawForest(ctx, W, H) {
  const baseY   = H * 0.86;
  const darkCol = "rgba(18,14,40,0.97)";
  const midCol  = "rgba(22,18,50,0.93)";

  // Varied pine trees across bottom
  const trees = [
    // left cluster
    { x: 0.01, h: 155, c: darkCol }, { x: 0.04, h: 185, c: darkCol },
    { x: 0.07, h: 210, c: darkCol }, { x: 0.10, h: 168, c: darkCol },
    { x: 0.13, h: 200, c: darkCol }, { x: 0.16, h: 145, c: midCol  },
    { x: 0.19, h: 220, c: darkCol }, { x: 0.22, h: 175, c: darkCol },
    { x: 0.25, h: 195, c: darkCol }, { x: 0.28, h: 160, c: midCol  },
    { x: 0.31, h: 215, c: darkCol }, { x: 0.34, h: 180, c: darkCol },
    { x: 0.37, h: 170, c: darkCol }, { x: 0.40, h: 205, c: midCol  },
    { x: 0.43, h: 190, c: darkCol }, { x: 0.46, h: 155, c: darkCol },
    { x: 0.49, h: 230, c: darkCol }, { x: 0.52, h: 175, c: midCol  },
    { x: 0.55, h: 195, c: darkCol }, { x: 0.58, h: 165, c: darkCol },
    // right cluster (taller, different style)
    { x: 0.74, h: 130, c: darkCol }, { x: 0.77, h: 115, c: darkCol },
    { x: 0.80, h: 145, c: darkCol }, { x: 0.83, h: 120, c: midCol  },
    { x: 0.86, h: 140, c: darkCol }, { x: 0.89, h: 110, c: darkCol },
    { x: 0.92, h: 130, c: darkCol }, { x: 0.95, h: 118, c: midCol  },
    { x: 0.98, h: 125, c: darkCol },
  ];

  for (const t of trees) {
    const bY = baseY + Math.random() * 20;
    drawPineSilhouette(ctx, t.x * W, bY, t.h, t.c);
  }

  // Ground fill
  ctx.fillStyle = "rgba(16,12,36,1)";
  ctx.fillRect(0, H * 0.88, W, H * 0.12);
}

function drawPineSilhouette(ctx, x, baseY, height, color) {
  const w     = height * 0.40;
  const tiers = 5;
  ctx.fillStyle = color;
  for (let t = 0; t < tiers; t++) {
    const frac = t / tiers;
    const ty   = baseY - height * frac;
    const tw   = w * (1 - frac * 0.7);
    const th   = height * 0.26;
    ctx.beginPath();
    ctx.moveTo(x, ty - th * 0.6);
    ctx.lineTo(x - tw / 2, ty + th * 0.4);
    ctx.lineTo(x + tw / 2, ty + th * 0.4);
    ctx.closePath();
    ctx.fill();
  }
  // Trunk
  const trunkW = Math.max(2, w * 0.07);
  ctx.fillRect(x - trunkW / 2, baseY - height * 0.08, trunkW, height * 0.08);
}

// ── Sky gradient background ────────────────────────────────────────────────────
function drawSky(ctx, W, H) {
  const sky = ctx.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0,    "#0e0b1f");   // deep navy top
  sky.addColorStop(0.18, "#16112e");
  sky.addColorStop(0.40, "#251640");   // dark purple mid
  sky.addColorStop(0.62, "#3d1e45");   // purple-rose
  sky.addColorStop(0.80, "#5a2540");   // rose-mauve near horizon
  sky.addColorStop(1,    "#3d1530");   // deep rose bottom
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, W, H);

  // Subtle horizontal atmospheric haze near horizon
  const haze = ctx.createLinearGradient(0, H * 0.55, 0, H * 0.80);
  haze.addColorStop(0, "rgba(180,120,160,0)");
  haze.addColorStop(0.5, "rgba(200,130,150,0.10)");
  haze.addColorStop(1,   "rgba(220,150,140,0.18)");
  ctx.fillStyle = haze;
  ctx.fillRect(0, H * 0.55, W, H * 0.25);
}

// ── Glass card ────────────────────────────────────────────────────────────────
function glassBox(ctx, x, y, w, h, r = 14) {
  ctx.beginPath(); ctx.roundRect(x, y, w, h, r);
  const bg = ctx.createLinearGradient(x, y, x, y + h);
  bg.addColorStop(0, "rgba(255,255,255,0.08)");
  bg.addColorStop(1, "rgba(255,255,255,0.03)");
  ctx.fillStyle   = bg; ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.14)";
  ctx.lineWidth   = 1; ctx.stroke();
}

// ── Arc circle metric ─────────────────────────────────────────────────────────
function drawCircle(ctx, x, y, r, pct, color, label, sub) {
  // Track
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(255,255,255,0.08)"; ctx.lineWidth = 11; ctx.stroke();
  // Fill
  ctx.beginPath();
  ctx.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (pct / 100));
  ctx.strokeStyle = color; ctx.lineWidth = 11; ctx.lineCap = "round";
  ctx.shadowBlur  = 16; ctx.shadowColor = color; ctx.stroke(); ctx.shadowBlur = 0;
  // Percent text
  ctx.textAlign = "center";
  ctx.fillStyle = "#f0eaff"; ctx.font = "bold 25px monospace";
  ctx.fillText(`${pct}%`, x, y + 9);
  // Label
  ctx.fillStyle = "rgba(200,185,230,0.75)"; ctx.font = "bold 11px monospace";
  ctx.fillText(label, x, y + r + 26);
  ctx.fillStyle = color; ctx.font = "11px monospace";
  ctx.fillText(sub, x, y + r + 44);
  ctx.textAlign = "left";
}

// ── Horizontal bar ────────────────────────────────────────────────────────────
function drawBar(ctx, x, y, w, h, pct, color, label) {
  ctx.fillStyle = "rgba(200,185,230,0.6)"; ctx.font = "11px monospace";
  ctx.fillText(label, x, y - 7);
  ctx.textAlign = "right";
  ctx.fillStyle = "#f0eaff"; ctx.font = "bold 11px monospace";
  ctx.fillText(`${pct}%`, x + w, y - 7);
  ctx.textAlign = "left";
  // Track
  ctx.beginPath(); ctx.roundRect(x, y, w, h, h / 2);
  ctx.fillStyle = "rgba(255,255,255,0.07)"; ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.12)"; ctx.lineWidth = 1; ctx.stroke();
  // Fill
  const fw  = Math.max(h, w * (pct / 100));
  const grd = ctx.createLinearGradient(x, 0, x + fw, 0);
  grd.addColorStop(0, color);
  grd.addColorStop(1, "rgba(255,255,255,0.55)");
  ctx.beginPath(); ctx.roundRect(x, y, fw, h, h / 2);
  ctx.fillStyle   = grd;
  ctx.shadowBlur  = 10; ctx.shadowColor = color;
  ctx.fill(); ctx.shadowBlur = 0;
}

async function buildImage(stats) {
  const { cpuPercent, cpuCores, cpuName, cpuSpeed, memPercent, usedMem, totalMem,
          freeMem, diskPercent, diskUsed, latency, netStats, botUptime, serverUptime } = stats;

  const W = 1280, H = 720;
  const canvas = createCanvas(W, H);
  const ctx    = canvas.getContext("2d");
  ensureRoundRect(ctx);

  // Night Forest Colour Palette
  const C = {
    text    : "#f0eaff",
    sub     : "rgba(200,185,230,0.75)",
    lavender: "#b8a8e8",
    rose    : "#e8909a",
    mint    : "#78d4b8",
    amber   : "#e8c87a",
    blue    : "#7ab8e8",
    stroke  : "rgba(255,255,255,0.14)",
    dim     : "rgba(120,100,160,0.6)",
  };

  // ── Sky ──────────────────────────────────────────────────────────────────────
  drawSky(ctx, W, H);

  // ── Stars ────────────────────────────────────────────────────────────────────
  drawStars(ctx, W, H);

  // ── Rising glow (right side) ─────────────────────────────────────────────────
  drawRisingGlow(ctx, W, H);

  // ── Mountains ────────────────────────────────────────────────────────────────
  drawMountains(ctx, W, H);

  // ── Forest pines ─────────────────────────────────────────────────────────────
  drawForest(ctx, W, H);

  // ── Crescent Moon ────────────────────────────────────────────────────────────
  drawMoon(ctx, W * 0.168, H * 0.13, 26);

  // ── Vignette overlay ─────────────────────────────────────────────────────────
  const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.15, W / 2, H / 2, H * 0.78);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(10,6,28,0.30)");
  ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);

  // ── Dark panel overlay (semi-transparent overlay for readability) ─────────────
  const panelOverlay = ctx.createLinearGradient(0, 0, 0, H);
  panelOverlay.addColorStop(0,   "rgba(10,6,28,0.55)");
  panelOverlay.addColorStop(0.5, "rgba(16,10,38,0.48)");
  panelOverlay.addColorStop(1,   "rgba(10,6,28,0.60)");
  ctx.fillStyle = panelOverlay; ctx.fillRect(0, 0, W, H);

  // ── Outer frame ──────────────────────────────────────────────────────────────
  ctx.beginPath(); ctx.roundRect(24, 24, W - 48, H - 48, 28);
  ctx.strokeStyle = "rgba(200,185,255,0.18)"; ctx.lineWidth = 1.5; ctx.stroke();
  ctx.beginPath(); ctx.roundRect(36, 36, W - 72, H - 72, 20);
  ctx.strokeStyle = "rgba(255,255,255,0.08)"; ctx.lineWidth = 1; ctx.stroke();

  // ════════════════════════════════════════════════════════════════════
  //  HEADER
  // ════════════════════════════════════════════════════════════════════
  ctx.fillStyle = C.lavender; ctx.font = "bold 22px monospace";
  ctx.fillText("SYSTEM MONITOR", 50, 62);
  ctx.fillStyle = C.sub; ctx.font = "14px monospace";
  ctx.fillText("Real-Time Performance Dashboard", 50, 82);

  // Latency badge (top-right)
  ctx.textAlign = "right";
  glassBox(ctx, W - 204, 36, 164, 54, 16);
  ctx.beginPath(); ctx.roundRect(W - 204, 36, 164, 54, 16);
  ctx.strokeStyle = C.mint; ctx.lineWidth = 1; ctx.stroke();

  ctx.fillStyle = C.mint; ctx.font = "bold 20px monospace";
  ctx.shadowBlur = 12; ctx.shadowColor = C.mint;
  ctx.fillText(`${latency.toFixed(2)} ms`, W - 52, 60);
  ctx.shadowBlur = 0;
  ctx.fillStyle = C.sub; ctx.font = "11px monospace";
  ctx.fillText("LATENCY", W - 52, 78);
  ctx.textAlign = "left";

  // ════════════════════════════════════════════════════════════════════
  //  TOP ROW — 4 metric cards
  // ════════════════════════════════════════════════════════════════════
  const bY = 108, bW = 272, bH = 210, gap = 20;

  // CPU card
  glassBox(ctx, 40, bY, bW, bH, 14);
  ctx.beginPath(); ctx.roundRect(40, bY, bW, bH, 14);
  ctx.strokeStyle = C.lavender; ctx.lineWidth = 1;
  ctx.shadowBlur = 12; ctx.shadowColor = "rgba(184,168,232,0.4)"; ctx.stroke(); ctx.shadowBlur = 0;
  drawCircle(ctx, 40 + bW / 2, bY + 82, 52, cpuPercent, C.lavender, "CPU USAGE", `${cpuCores} Cores`);

  // Memory card
  glassBox(ctx, 40 + bW + gap, bY, bW, bH, 14);
  ctx.beginPath(); ctx.roundRect(40 + bW + gap, bY, bW, bH, 14);
  ctx.strokeStyle = C.mint; ctx.lineWidth = 1;
  ctx.shadowBlur = 12; ctx.shadowColor = "rgba(120,212,184,0.4)"; ctx.stroke(); ctx.shadowBlur = 0;
  drawCircle(ctx, 40 + bW + gap + bW / 2, bY + 82, 52, memPercent, C.mint, "MEMORY", size(usedMem));

  // Disk card
  glassBox(ctx, 40 + (bW + gap) * 2, bY, bW, bH, 14);
  ctx.beginPath(); ctx.roundRect(40 + (bW + gap) * 2, bY, bW, bH, 14);
  ctx.strokeStyle = C.rose; ctx.lineWidth = 1;
  ctx.shadowBlur = 12; ctx.shadowColor = "rgba(232,144,154,0.4)"; ctx.stroke(); ctx.shadowBlur = 0;
  drawCircle(ctx, 40 + (bW + gap) * 2 + bW / 2, bY + 82, 52, diskPercent, C.rose, "STORAGE", size(diskUsed));

  // Network speed card
  const nX = 40 + (bW + gap) * 3;
  glassBox(ctx, nX, bY, bW, bH, 14);
  // Rainbow gradient border
  const ringG = ctx.createLinearGradient(nX, bY, nX + bW, bY + bH);
  ringG.addColorStop(0,    C.lavender);
  ringG.addColorStop(0.33, C.rose);
  ringG.addColorStop(0.66, C.amber);
  ringG.addColorStop(1,    C.mint);
  ctx.beginPath(); ctx.roundRect(nX, bY, bW, bH, 14);
  ctx.strokeStyle = ringG; ctx.lineWidth = 2;
  ctx.shadowBlur  = 16; ctx.shadowColor = "rgba(184,168,232,0.45)";
  ctx.stroke(); ctx.shadowBlur = 0;

  ctx.fillStyle = C.lavender; ctx.font = "bold 14px monospace";
  ctx.fillText("NETWORK SPEED", nX + 18, bY + 36);

  ctx.fillStyle = C.sub; ctx.font = "12px monospace"; ctx.fillText("⬇ Download", nX + 18, bY + 78);
  ctx.fillStyle = C.text; ctx.font = "bold 20px monospace";
  ctx.shadowBlur = 8; ctx.shadowColor = C.mint;
  ctx.fillText(netStats.dl, nX + 18, bY + 100); ctx.shadowBlur = 0;

  ctx.beginPath(); ctx.moveTo(nX + 18, bY + 115); ctx.lineTo(nX + bW - 18, bY + 115);
  ctx.strokeStyle = "rgba(255,255,255,0.10)"; ctx.lineWidth = 1; ctx.stroke();

  ctx.fillStyle = C.sub; ctx.font = "12px monospace"; ctx.fillText("⬆ Upload", nX + 18, bY + 146);
  ctx.fillStyle = C.text; ctx.font = "bold 20px monospace";
  ctx.shadowBlur = 8; ctx.shadowColor = C.rose;
  ctx.fillText(netStats.ul, nX + 18, bY + 168); ctx.shadowBlur = 0;

  // ════════════════════════════════════════════════════════════════════
  //  PILLS ROW
  // ════════════════════════════════════════════════════════════════════
  const pills = [
    { l: "HOSTNAME",   v: "XavierMarket",                     c: C.lavender },
    { l: "PLATFORM",   v: `${os.platform()} (${os.arch()})`,  c: C.mint     },
    { l: "BOT UPTIME", v: botUptime,                          c: C.rose     },
    { l: "SERVER UP",  v: serverUptime,                       c: C.amber    },
    { l: "NODE.JS",    v: process.version,                    c: C.blue     },
  ];
  const pW = (W - 80 - gap * (pills.length - 1)) / pills.length;
  const pY = bY + bH + 18;

  pills.forEach((p, i) => {
    const px = 40 + (pW + gap) * i;
    glassBox(ctx, px, pY, pW, 58, 14);
    ctx.beginPath(); ctx.roundRect(px, pY, pW, 58, 14);
    ctx.strokeStyle = p.c + "55"; ctx.lineWidth = 1; ctx.stroke();

    ctx.beginPath(); ctx.arc(px + 18, pY + 29, 5, 0, Math.PI * 2);
    ctx.fillStyle = p.c;
    ctx.shadowBlur = 10; ctx.shadowColor = p.c;
    ctx.fill(); ctx.shadowBlur = 0;

    ctx.fillStyle = C.sub; ctx.font = "10px monospace"; ctx.fillText(p.l, px + 32, pY + 22);
    ctx.fillStyle = C.text; ctx.font = "bold 13px monospace"; ctx.fillText(p.v, px + 32, pY + 44);
  });

  // ════════════════════════════════════════════════════════════════════
  //  BOTTOM PANEL
  // ════════════════════════════════════════════════════════════════════
  const pfY = pY + 76;
  const pfH = H - pfY - 36;
  glassBox(ctx, 40, pfY, W - 80, pfH, 18);
  // Panel border gradient
  const panelBorder = ctx.createLinearGradient(40, pfY, W - 40, pfY + pfH);
  panelBorder.addColorStop(0,   "rgba(184,168,232,0.45)");
  panelBorder.addColorStop(0.5, "rgba(232,144,154,0.35)");
  panelBorder.addColorStop(1,   "rgba(120,212,184,0.45)");
  ctx.beginPath(); ctx.roundRect(40, pfY, W - 80, pfH, 18);
  ctx.strokeStyle = panelBorder; ctx.lineWidth = 1.5;
  ctx.shadowBlur  = 14; ctx.shadowColor = "rgba(184,168,232,0.3)";
  ctx.stroke(); ctx.shadowBlur = 0;

  ctx.fillStyle = C.text; ctx.font = "bold 16px monospace"; ctx.fillText("SYSTEM PERFORMANCE", 68, pfY + 36);
  ctx.fillStyle = C.sub;  ctx.font = "12px monospace"; ctx.fillText("Real-time resource monitoring", 68, pfY + 54);

  // Bars
  const bX2 = 68, bSY = pfY + 80, bW2 = 480;
  drawBar(ctx, bX2, bSY,       bW2, 10, cpuPercent,  C.lavender, "CPU Load");
  drawBar(ctx, bX2, bSY + 38,  bW2, 10, memPercent,  C.mint,     "Memory Usage");
  drawBar(ctx, bX2, bSY + 76,  bW2, 10, diskPercent, C.rose,     "Disk Usage");
  drawBar(ctx, bX2, bSY + 114, bW2, 10, Math.min(Math.round((latency / 1000) * 100), 100), C.amber, "System Latency");

  // Detail table (right side)
  const details = [
    { k: "OS Release",   v: os.release() },
    { k: "CPU Model",    v: cpuName      },
    { k: "CPU Speed",    v: cpuSpeed     },
    { k: "Total Memory", v: size(totalMem) },
    { k: "Free Memory",  v: size(freeMem)  },
  ];
  const colors = [C.lavender, C.mint, C.rose, C.amber, C.blue];
  const iX = 650;
  details.forEach((d, i) => {
    const dy = bSY + i * 28;
    ctx.beginPath(); ctx.moveTo(iX - 12, dy - 14); ctx.lineTo(W - 56, dy - 14);
    ctx.strokeStyle = "rgba(255,255,255,0.07)"; ctx.lineWidth = 0.5; ctx.stroke();
    ctx.fillStyle = C.sub;      ctx.font = "13px monospace"; ctx.fillText(d.k, iX, dy);
    ctx.fillStyle = colors[i % colors.length]; ctx.font = "bold 13px monospace";
    ctx.shadowBlur = 6; ctx.shadowColor = colors[i % colors.length];
    ctx.fillText(d.v, iX + 190, dy); ctx.shadowBlur = 0;
  });

  return canvas.toBuffer("image/png");
}

export default {
  cmd : ["ping", "p", "cek"],
  tag : "tools",
  desc: "Cek performa & kecepatan server",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const [netStats, latency] = await Promise.all([runSpeedTest(), getLatency()]);

      const cpus       = os.cpus();
      const cpuName    = (cpus?.[0]?.model || "Unknown CPU").split(" @")[0].trim();
      const cpuSpeed   = (cpus?.[0]?.speed || 0) + " MHz";
      const cpuCores   = cpus.length || 1;
      const cpuLoad    = os.loadavg?.()[0] ?? 0;
      const cpuPercent = Math.min(Math.floor((cpuLoad / cpuCores) * 100), 100);

      const totalMem   = os.totalmem();
      const freeMem    = os.freemem();
      const usedMem    = totalMem - freeMem;
      const memPercent = Math.round((usedMem / totalMem) * 100);

      const disk = getDisk();

      const img = await buildImage({
        cpuPercent, cpuCores, cpuName, cpuSpeed,
        memPercent, usedMem, totalMem, freeMem,
        diskPercent: disk.pct, diskUsed: disk.used,
        latency, netStats,
        botUptime   : fmtTime(process.uptime()),
        serverUptime: fmtTime(os.uptime()),
      });

      await m.reply({ image: img, caption: "" });
    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};