export const getppCommand = {
  cmd: ["getpp"],
  tag: "tools",
  desc: "Ambil foto profil pengguna WhatsApp",

  async run(m) {
    let targetJid = null;

    if (m.quotedSender) {
      targetJid = m.quotedSender;
    } else if (m.mentionList?.length > 0) {
      targetJid = m.mentionList[0];
    } else if (m.q) {
      let num = m.q.replace(/[^0-9]/g, "");
      if (!num) return m.reply("Masukkan nomor, tag, atau reply pesan orang.");
      if (num.startsWith("0")) num = "62" + num.slice(1);
      targetJid = num + "@s.whatsapp.net";
    } else {
      return m.reply("Masukkan nomor, tag, atau reply pesan orang.");
    }

    targetJid = resolveJid(targetJid) ?? targetJid;

    let ppUrl;
    try {
      ppUrl = await m.gara.profilePictureUrl(targetJid, "image");
    } catch {
      return m.reply("Foto profil pada nomor tersebut di privasi");
    }

    const buf = await fetch(ppUrl).then(r => r.arrayBuffer()).then(b => Buffer.from(b));
    const uploadedUrl = await uguu(buf);

    if (!uploadedUrl || uploadedUrl === "failed") {
      return m.reply("Gagal upload foto profil.");
    }

    await sendMedia(m.gara, m.jid, m.raw, uploadedUrl, "image/jpeg", "");
  },
};