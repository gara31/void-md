import { generateWAMessageFromContent, generateWAMessageContent } from "gara";

export const cekidchCommand = {
  cmd: ["cekidch"],
  tag: "tools",
  desc: "Cek ID dan info saluran WhatsApp",

  async run(m) {
    const msg = m.raw.message;
    const type = Object.keys(msg)[0];
    const content = msg[type];

    const ext =
      content?.contextInfo?.quotedMessage?.extendedTextMessage ??
      (type === "extendedTextMessage" ? content : null);

    const link = ext?.matchedText ?? ext?.text ?? m.q ?? "";
    const isChannelLink = /whatsapp\.com\/channel\//i.test(link);

    if (!isChannelLink) {
      return m.reply("Kirim atau reply link saluran WhatsApp.\nContoh: .cekidch https://whatsapp.com/channel/xxx");
    }

    const inviteCode = link.split("/channel/")[1]?.split(/[?#\s]/)[0];
    if (!inviteCode) return m.reply("Link saluran tidak valid.");

    let data;
    try {
      data = await m.gara.newsletterMetadata("invite", inviteCode);
    } catch {
      return m.reply("Gagal mengambil info saluran. Coba lagi.");
    }

    const meta     = data.thread_metadata;
    const name     = meta.name?.text        ?? "Tidak diketahui";
    const desc     = meta.description?.text ?? "Tidak ada deskripsi";
    const subs     = meta.subscribers_count ?? "0";
    const state    = data.state?.type       ?? "Tidak diketahui";
    const verified = meta.verification === "VERIFIED" ? "Ya" : "Tidak";
    const handle   = meta.handle            ?? "Tidak ada";

    const createdRaw = parseInt(meta.creation_time ?? "0");
    const created    = createdRaw ? dateFormatter(createdRaw * 1000) : "Tidak diketahui";

    const infoText =
      `- \`Info Saluran WhatsApp\`\n\n` +
      `- *ID:* ${data.id}\n` +
      `- *Nama:* ${name}\n` +
      `- *Subscriber:* ${Number(subs).toLocaleString("id-ID")}\n` +
      `- *Status:* ${state}\n` +
      `- *Terverifikasi:* ${verified}\n` +
      `- *Dibuat:* ${created}` +
      `- *Deskripsi:* ${desc}\n\n`;

    let header = { title: "" };
    const preview = meta.preview?.direct_path;
    if (preview) {
      try {
        const imgUrl = "https://mmg.whatsapp.net" + preview;
        const buf = await fetch(imgUrl).then(r => r.arrayBuffer()).then(b => Buffer.from(b));
        const generated = await generateWAMessageContent(
          { image: buf, mimetype: "image/jpeg" },
          { upload: m.gara.waUploadToServer }
        );
        if (generated?.imageMessage) {
          header = {
            imageMessage: generated.imageMessage,
            hasMediaAttachment: true,
          };
        }
      } catch {}
    }

    const built = generateWAMessageFromContent(
      m.jid,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header,
              body: { text: "" },
              footer: { text: infoText },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "Salin ID Saluran",
                      id: "copy_id",
                      copy_code: data.id,
                    }),
                  },
                ],
              },
            },
          },
        },
      },
      { quoted: m.raw, userJid: m.sender }
    );

    await m.gara.relayMessage(m.jid, built.message, { messageId: built.key.id });
  },
};