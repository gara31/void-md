export default {
  cmd     : ["rvo"],
  tag     : "tools",
  desc    : "Buka foto/video/audio view once",
  isQuoted: true,

  async run(m) {
    const isVoImage = m.quotedType === "imageMessage" && m.quoted?.imageMessage?.viewOnce === true;
    const isVoAudio = m.quotedType === "audioMessage" && m.quoted?.audioMessage?.viewOnce === true;
    const isVoVideo = m.quotedType === "videoMessage" && m.quoted?.videoMessage?.viewOnce === true;

    if (!isVoImage && !isVoVideo && !isVoAudio) {
      return m.reply("Reply pesan 1x lihat nya dulu!");
    }

    await m.reply(msg.common.wait);

    if (isVoImage) {
      const buf = await download(m.quoted.imageMessage, "image");
      await m.reply({ image: buf });
    } else if (isVoVideo) {
      const buf = await download(m.quoted.videoMessage, "video");
      await m.reply({ video: buf });
    } else if (isVoAudio) {
      const buf = await download(m.quoted.audioMessage, "audio");
      await m.reply({ audio: buf, mimetype: "audio/mpeg", ptt: true });
    }
  },
};