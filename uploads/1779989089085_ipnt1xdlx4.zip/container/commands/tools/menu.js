import sharp from "sharp";
import { generateWAMessageFromContent } from "gara";
import { getMenuList, getCommands } from "../../handlers/commandHandler.js";
import { userStore } from "../../db/userStore.js";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pkg = require("../../package.json");

export default {
  cmd  : ["menu"],
  tag  : "tools",
  desc : "Tampilkan semua daftar perintah",

  async run(m) {
    const { tags, frames, image: menuImage, audio: menuAudio } = cfg.menu;
    const { brackets, head: HEAD, body: BODY, foot: FOOT } = frames;
    const showDesc = cfg.showDesc !== false;

    const wrap = (text) => `${brackets[0]}${text}${brackets[1]}`;

    if (m.args?.length > 0) {
      const entry = getCommands().get(m.args[0].toLowerCase());
      if (!entry) return m.reply(`Command *${m.args[0]}* tidak ditemukan.`);
      return m.reply(
        `${HEAD}─ ${wrap(" INFO COMMAND ")} ─\n` +
        `${BODY} Cmd   : *${prefix}${entry.cmd[0]}*\n` +
        `${BODY} Tag   : ${tags[entry.tag] ?? entry.tag}\n` +
        (showDesc ? `${BODY} Desc  : ${entry.desc || "-"}\n` : "") +
        `${BODY} Alias : ${entry.cmd.slice(1).map(a => prefix + a).join(", ") || "-"}\n` +
        `${FOOT}`
      );
    }

    const now     = new Date();
    const jam     = now.getHours();
    const ucapan  = jam < 12 ? "Pagi" : jam < 15 ? "Siang" : jam < 18 ? "Sore" : "Malam";
    const mode    = typeof cfg.public === "string" ? cfg.public : cfg.public ? "Public" : "Self";
    const botType = pkg.type === "module" ? "ESM" : "CJS";

    const user     = userStore.getUser(m.sender, m.pushName);
    const { max }  = userStore.xpRange(user.level);
    const menuList = getMenuList();

    let text = "";

    text += `*Hii, Selamat ${ucapan}!* 👋\n`;
    text += `Aku *${botnickname}*, siap membantu kamu.\n\n\n`;

    text += `\`System Information\`\n`;
    text += `  ╭ ⌯ Name    : ${botnickname}\n`;
    text += `  │ ⌯ Version : ${pkg.version}\n`;
    text += `  │ ⌯ Type    : ${botType}\n`;
    text += `  │ ⌯ Mode    : ${mode}\n`;
    text += `  ╰ ⌯ Prefix  : ${prefix}\n\n`;

    text += `\`Others Information\`\n`;
    text += `  ╭ ⌯ Name  : *${m.pushName || "User"}*\n`;
    text += `  │ ⌯ Role  : *${user.role}*\n`;
    text += `  │ ⌯ Level : *${user.level}*\n`;
    text += `  ╰ ⌯ XP    : *${user.exp}* / ${max}\n\n`;

    for (const [tag, list] of menuList) {
      const label = tags[tag] ?? `≡ ${tag.toUpperCase()}`;
      text += `\n${BODY} ${label}\n`;
      for (const item of list) {
        text += `   ├ *${prefix}${item.cmd}*\n`;
        if (showDesc && item.desc) text += `   └ ${item.desc}\n`;
      }
    }

    text += `\n© Vøid MD 2025–2026`;

    const res  = await fetch(menuImage);
    const gara = await sharp(Buffer.from(await res.arrayBuffer()))
      .resize(300, 150)
      .jpeg({ quality: 80 })
      .toBuffer();

    const waMsg = generateWAMessageFromContent(m.jid, {
      interactiveMessage: {
        header: {
          subtitle          : "",
          hasMediaAttachment: false,
          locationMessage   : {
            degreesLatitude : 0,
            degreesLongitude: 0,
            name            : "",
            address         : "",
            url             : "https://chat.whatsapp.com/EerBzpUuByd3GBSqXBl1bP",
            jpegThumbnail   : gara.toString("base64"),
          },
        },
        body  : { text: "" },
        footer: { text: text.trim() },
        nativeFlowMessage: {},
      },
    }, { quoted: m.raw });

    await m.gara.relayMessage(m.jid, waMsg.message, { messageId: waMsg.key.id });

    if (menuAudio) {
      await m.reply({ audio: { url: menuAudio }, mimetype: "audio/ogg; codecs=opus", ptt: true });
    }
  },
};