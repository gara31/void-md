import axios    from "axios";
import FormData from "form-data";

async function removeBgWeb(buffer) {
  const form = new FormData();
  form.append("file", buffer, {
    filename   : "image.jpg",
    contentType: "image/jpeg",
  });

  const { data } = await axios.post("https://removebg.one/api/predict/v2", form, {
    headers: {
      ...form.getHeaders(),
      "user-agent"        : "Mozilla/5.0 (Linux; Android 10)",
      accept              : "application/json, text/plain, */*",
      "sec-ch-ua"         : '"Chromium";v="139", "Not;A=Brand";v="99"',
      platform            : "PC",
      "sec-ch-ua-platform": '"Android"',
      origin              : "https://removebg.one",
      referer             : "https://removebg.one/upload",
    },
    maxBodyLength   : Infinity,
    maxContentLength: Infinity,
  });

  const url = data?.data?.cutoutUrl;
  if (!url) throw new Error("gagal hapus background");
  return url;
}

async function removeBgTermai(buffer) {
  const url = await uguu(buffer);
  const res = await fetch(`${api.xterm.url}/api/tools/image-removebg?url=${encodeURIComponent(url)}&key=${api.xterm.key}`)
    .then(r => r.json());
  if (!res?.data?.url) throw new Error("removebg termai gagal");
  return res.data.url;
}

export default {
  cmd  : ["removebg", "rmbg"],
  tag  : "tools",
  desc : "Hapus background foto atau stiker",

  async run(m) {
    if (!m.isImage && !m.isSticker) {
      return m.reply("❗ Kirim atau reply *gambar/stiker* dulu!");
    }

    if (m.isSticker) {
      const rawMsg     = m.raw?.message;
      const stickerMsg =
        rawMsg?.stickerMessage ??
        rawMsg?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage ??
        m.quoted?.stickerMessage ??
        null;

      if (stickerMsg?.isAnimated) {
        return m.reply("❗ Stiker animasi nggak bisa dihapus backgroundnya, kirim stiker diam atau gambar.");
      }
    }

    await m.reply(msg.common.wait);

    const buffer = await m.download();

    try {
      const url = await removeBgWeb(buffer);
      return m.reply({ image: { url } });
    } catch {}

    try {
      const url = await removeBgTermai(buffer);
      return m.reply({ image: { url } });
    } catch (e) {
      return m.reply(`❗ Gagal hapus background: ${e.message}`);
    }
  },
};