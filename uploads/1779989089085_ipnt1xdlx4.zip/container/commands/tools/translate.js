import axios from "axios";

async function translateChunk(text, source, target) {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${source}&tl=${target}&dt=t&q=${encodeURIComponent(text)}`;
  const { data } = await axios.get(url, {
    timeout: 30000,
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    },
  });
  return (data?.[0] || []).map(s => s?.[0] || "").join("");
}

async function translateText(text, source, target) {
  const MAX = 1000;
  if (text.length <= MAX) return await translateChunk(text, source, target);

  const lines  = text.split("\n");
  const chunks = [];
  let   curr   = "";

  for (const line of lines) {
    if ((curr + "\n" + line).length > MAX && curr.length > 0) {
      chunks.push(curr.trim());
      curr = line;
    } else {
      curr = curr ? curr + "\n" + line : line;
    }
  }
  if (curr.trim()) chunks.push(curr.trim());

  const results = [];
  for (const chunk of chunks) {
    results.push(await translateChunk(chunk, source, target));
    await new Promise(r => setTimeout(r, 300));
  }

  return results.join("\n");
}

export default {
  cmd     : ["translate", "tr", "tl"],
  tag     : "tools",
  desc    : "Translate teks ke bahasa lain",
  isQuoted: "❗reply chat yang mau di translate",

  async run(m) {
    await m.reply(msg.common.wait);

    const target = m.args[0] || "id";
    const text   = m.quotedText?.trim();

    if (!text) return m.reply("❗reply chat yang mau di translate");

    let result;
    try {
      result = await translateText(text, "auto", target);
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    await m.reply(result);
  },
};
