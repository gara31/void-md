export default {
  cmd: ["whatmusic", "whatmusik", "wmusic"],
  tag: "tools",
  desc: "Deteksi judul musik dari audio yang di-reply",
  isAudio: true,

  async run(m) {
    await m.reply(msg.common.wait);

    let buffer;
    try {
      buffer = await m.download();
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    const form = new FormData();
    form.append("file", new Blob([buffer]), "audio.mp3");
    form.append("sample_size", "118784");

    let json;
    try {
      const res = await fetch("https://api.doreso.com/humming", {
        method: "POST",
        headers: {
          "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36",
          "accept": "application/json, text/plain, */*",
          "origin": "https://www.aha-music.com",
          "referer": "https://www.aha-music.com/",
        },
        body: form,
      });
      json = await res.json();
    } catch (e) {
      return m.reply(msg.common.error(e));
    }

    if (!json?.data?.title) {
      return m.reply("Gagal mendeteksi musik");
    }

    await m.reply(json.data.title);
  },
};
