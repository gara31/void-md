import { getCommands } from "../../handlers/commandHandler.js";

export default {
  cmd  : ["totalfitur", "total", "fitur"],
  tag  : "tools",
  desc : "Lihat total fitur & command yang tersedia",

  async run(m) {
    const allCmds = getCommands();
    const unique  = new Set(allCmds.values());

    const byTag = new Map();
    for (const cmd of unique) {
      const tag = cmd.tag || "general";
      if (!byTag.has(tag)) byTag.set(tag, 0);
      byTag.set(tag, byTag.get(tag) + 1);
    }

    const totalCmd = unique.size;
    const tags     = cfg.menu?.tags ?? {};

    // Build tabel rows
    const rows = [
      { is_header: true, cells: ["Kategori", "Total"] },
    ];

    for (const [tag, count] of [...byTag.entries()].sort()) {
      const label = tags[tag]
        ? String(tags[tag]).replace(/[*_`]/g, "").trim()
        : tag.toUpperCase();
      rows.push({ is_header: false, cells: [label, `${count} cmd`] });
    }

    rows.push({ is_header: false, cells: ["📦 Total Semua", `${totalCmd} cmd`] });

    const data = Buffer.from(JSON.stringify({
      response_id: `totalfitur-${Date.now()}`,
      sections: [
        {
          view_model: {
            primitive: {
              text: `📋 *Total Fitur Bot*\n_${botfullname}_`,
              __typename: "GenAIMarkdownTextUXPrimitive"
            },
            __typename: "GenAISingleLayoutViewModel"
          }
        },
        {
          view_model: {
            primitive: {
              rows,
              __typename: "GenATableUXPrimitive"
            },
            __typename: "GenAISingleLayoutViewModel"
          }
        }
      ]
    })).toString("base64");

    await m.sock.relayMessage(m.from, {
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: "AI_RICH_RESPONSE_TYPE_STANDARD",
            unifiedResponse: { data },
            contextInfo: {
              forwardingScore: 2,
              isForwarded: true,
              forwardOrigin: "META_AI",
              forwardedAiBotMessageInfo: {
                botJid: "259786046210223@bot"
              }
            }
          }
        }
      }
    }, {});
  },
};