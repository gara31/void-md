import { generateWAMessageFromContent } from "gara";
import { fileTypeFromBuffer }           from "file-type";
import FormData                         from "form-data";
import axios                            from "axios";

const github_token  = "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";
const github_owner  = "gara31";
const github_repo   = "void-md";
const github_branch = "main";

async function upload_github(buffer) {
  const ft       = await fileTypeFromBuffer(buffer);
  const ext      = ft?.ext || "bin";
  const filename = `uploads/${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;

  await axios.put(
    `https://api.github.com/repos/${github_owner}/${github_repo}/contents/${filename}`,
    {
      message : `upload ${filename}`,
      content : buffer.toString("base64"),
      branch  : github_branch,
    },
    {
      headers: {
        authorization : `token ${github_token}`,
        "content-type": "application/json",
      },
    }
  );

  return `https://raw.githubusercontent.com/${github_owner}/${github_repo}/${github_branch}/${filename}`;
}

async function upload_termai(buffer, ext) {
  const fd = new FormData();
  fd.append("file", buffer, { filename: "file." + ext });

  const { data } = await axios.post(
    "https://c.termai.cc/api/upload?key=AIzaBj7z2z3xBjsk",
    fd,
    { headers: { "content-type": "multipart/form-data" }, timeout: 20000 }
  );

  if (!data?.path) throw new Error("upload gagal");
  return data.path;
}

export default {
  cmd    : ["tourl"],
  tag    : "tools",
  desc   : "upload media dan dapatkan url-nya",
  isMedia: "❗kirim atau reply media dulu (foto/video/audio/dokumen)",

  async run(m) {
    await m.reply(msg.common.wait);

    try {
      const buffer = await m.download();
      const ft     = await fileTypeFromBuffer(buffer);
      const ext    = ft?.ext || "bin";

      let url;
      let label;

      if (m.isOwner) {
        url   = await upload_github(buffer);
        label = "github";
      } else {
        url   = await upload_termai(buffer, ext);
        label = "cdn";
      }

      const text =
        `- \`hasil upload\`\n\n` +
        `- *via:* ${label}\n` +
        `- *ext:* ${ext}\n` +
        `- *url:* ${url}`;

      const built = generateWAMessageFromContent(
        m.jid,
        {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: { title: "" },
                body  : { text: "" },
                footer: { text },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_copy",
                      buttonParamsJson: JSON.stringify({
                        display_text: "salin url",
                        id          : "copy_url",
                        copy_code   : url,
                      }),
                    },
                    {
                      name: "cta_url",
                      buttonParamsJson: JSON.stringify({
                        display_text: "buka url",
                        url         : url,
                        merchant_url: url,
                      }),
                    },
                  ],
                },
              },
            },
          },
        },
        { quoted: m.raw, userJid: m.sender }
      );

      await m.gara.relayMessage(m.jid, built.message, { messageId: built.key.id });

    } catch (e) {
      await m.reply(`❗ ${e.message}`);
    }
  },
};