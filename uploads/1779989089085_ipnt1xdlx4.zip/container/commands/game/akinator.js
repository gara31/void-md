import { createRequire } from "module";
const require = createRequire(import.meta.url);

export const akinatorCommand = {
  cmd : ["akinator", "aki"],
  tag : "game",
  desc: "Tebak karakter / tokoh dengan Akinator 🧞",

  async run(m) {
    const existing = getGame(m.jid);

    if (existing?.type === "akinator") {
      return m.reply(
        `Masih ada game Akinator yang aktif di sini!\n` +
        `Ketik *${prefix}akistop* untuk berhenti dulu.`
      );
    }

    if (existing) {
      return m.reply(
        `Masih ada game *${existing.type}* yang aktif di sini!\n\n` +
        `Selesaikan atau hentikan game itu dulu sebelum mulai Akinator.`
      );
    }

    await m.reply("```Memulai Akinator...```");

    try {
      const { Akinator } = require("@aqul/akinator-api");

      const aki = new Akinator({ region: "id", childMode: true });
      await aki.start();

      setGame(m.jid, "akinator", {
        aki,
        creator: {
          name: m.pushName,
          id  : m.sender,
        },
        step    : aki.step,
        progress: aki.progress,
        question: aki.question,
        endTime : Date.now() + 10 * 60 * 1000,
      });

      const txt =
        `*!-======[ AKINATOR ]======-!*\n\n` +
    `❓ Pertanyaan ${aki.step + 1}:\n*${aki.question}*\n\n` +
    `📊 Progress: ${Math.round(aki.progress)}%\n\n` +
    `*Jawab dengan angka:*\n` +
    `1️⃣ Ya\n2️⃣ Tidak\n3️⃣ Tidak Tahu\n4️⃣ Mungkin\n5️⃣ Mungkin Tidak\n0️⃣ Kembali\n\n` +
    `> Ketik *${prefix}akistop* untuk berhenti`;

      await m.reply(txt);

    } catch (err) {
      console.error("[Akinator start error]", err.message);
      deleteGame(m.jid);
      await m.reply(`Gagal memulai Akinator 😢\n${err.message}`);
    }
  },
};

export const akistopCommand = {
  cmd : ["akistop"],
  tag : "game",
  desc: "Hentikan game Akinator yang sedang berjalan",

  async run(m) {
    const game = getGame(m.jid);

    if (!game || game.type !== "akinator") {
      return m.reply("Tidak ada game Akinator yang aktif di sini.");
    }

    deleteGame(m.jid);
    await m.reply(`Game Akinator dihentikan! 👋\n\nKetik *${prefix}akinator* untuk main lagi kapan saja.`);
  },
};
