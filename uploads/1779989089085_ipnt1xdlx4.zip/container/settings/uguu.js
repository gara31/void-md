import { fileTypeFromBuffer } from "file-type";
import FormData from "form-data";
import axios from "axios";

export const uguu = async (buffer) => {
  try {
    const { ext } = await fileTypeFromBuffer(buffer);
    const fd = new FormData();
    fd.append("files[]", buffer, Date.now() + "." + ext);

    const { data } = await axios.post("https://uguu.se/upload.php", fd, {
      headers: fd.getHeaders(),
    });

    return data?.files?.[0]?.url || "failed";
  } catch (e) {
    throw new Error(`Upload error: ${e.message}`);
  }
};