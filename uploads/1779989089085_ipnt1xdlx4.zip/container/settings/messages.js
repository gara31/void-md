global.msg = {};

global.msg.common = {
  onlyGroup    : "perintah ini cuma bisa dipake di grup bro",
  onlyPrivate  : "perintah ini cuma bisa dipake di private chat",
  onlyAdmin    : "lo bukan admin grup",
  onlyOwner    : "perintah ini khusus owner aja",
  botNotAdmin  : "bot harus jadi admin dulu",
  needQuoted   : "reply pesan dulu baru pake perintah ini",
  needMention  : "tag dulu orangnya",
  needMedia    : "kirim atau reply media dulu (foto/video/audio/stiker/dokumen)",
  needImage    : "kirim atau reply foto dulu",
  needVideo    : "kirim atau reply video dulu",
  needAudio    : "kirim atau reply audio dulu",
  needSticker  : "kirim atau reply stiker dulu",
  needArgs     : "isi dulu argumennya setelah perintah",
  error        : (e) => `${e?.message ?? e}`,
  wait         : "```Bentar```",
  success      : "berhasil!",
  notFound     : "nggak ketemu",
  invalidArgs  : "format perintahnya salah",
  noMention    : "tag atau reply orangnya dulu",
  cantSelf     : "nggak bisa ke diri sendiri",
  cantBot      : "nggak bisa ke bot",
};

global.msg.group = {
  promoteSuccess : (num) => `@${num} udah jadi admin`,
  promoteFail    : (e)   => `gagal promote\n${e?.message ?? e}`,
  demoteSuccess  : (num) => `@${num} udah dicopot dari admin`,
  demoteFail     : (e)   => `gagal demote\n${e?.message ?? e}`,
  kickSuccess    : (num) => `@${num} udah dikick`,
  kickFail       : (num, status) => `gagal kick @${num} (${status})`,
  cantKickSelf   : "nggak bisa kick diri sendiri",
  addSuccess     : (list) => `berhasil tambah: ${list}`,
  addFail        : (list) => `gagal tambah: ${list}`,
  addInvalid     : "nomornya nggak valid, contoh: !add 628xxx",
  tagallText     : (msg) => msg || "perhatian semua member!",
  openSuccess    : "grup dibuka, semua member bisa kirim pesan",
  closeSuccess   : "grup ditutup, cuma admin yang bisa kirim pesan",
  lockSuccess    : "info grup dikunci, cuma admin yang bisa ubah",
  unlockSuccess  : "info grup dibuka, semua member bisa ubah",
  settingFail    : (e) => `gagal ubah setting grup\n${e?.message ?? e}`,
  noAdmin        : "nggak ada admin di grup ini",
  adminFail      : (e) => `gagal ambil data admin\n${e?.message ?? e}`,
  metaFail       : "gagal ambil data grup",
};

global.msg.owner = {
  backupStart    : "lagi backup, tunggu ya...",
  backupSending  : (isGroup) => `lagi ngirim file backup${isGroup ? " ke private chat" : ""}...`,
  backupSuccess  : (sizeKB, isGroup) =>
    `backup selesai\nukuran: ${sizeKB} KB${isGroup ? "\nfile udah dikirim ke private chat" : ""}`,
  backupFail     : (e) => `backup gagal\n${e?.msg ?? e?.message ?? JSON.stringify(e)}`,
};

global.msg.info = {
  whoami: ({ pushName, num, role, isGroup, groupName, memberCount, isBotAdmin }) => {
    let text = `╭─「 info kamu 」\n│\n`;
    text += `├ nama    : ${pushName ?? "-"}\n`;
    text += `├ nomor   : ${num}\n`;
    text += `├ role    : ${role}\n`;
    text += `├ chat    : ${isGroup ? `grup (${groupName})` : "private"}\n`;
    if (isGroup) {
      text += `├ member  : ${memberCount} orang\n`;
      text += `├ bot     : ${isBotAdmin ? "admin" : "bukan admin"}\n`;
    }
    text += `│\n╰─ _${botfullname}_`;
    return text;
  },

  cekAdmin: ({ num, role, isBotAdmin }) =>
    `╭─「 cek admin 」\n│\n├ user   : @${num}\n├ status : ${role}\n├ bot    : ${isBotAdmin ? "admin" : "bukan admin"}\n│\n╰─ _${botfullname}_`,

  botAdmin: ({ botNum, status }) =>
    `╭─「 status bot 」\n│\n├ nomor  : @${botNum}\n├ status : ${status}\n│\n╰─ _${botfullname}_`,

  infoGrup: ({ groupName, memberCount, adminCount, memberOnly, isBotAdmin, isAdmin }) => {
    let text = `╭─「 info grup 」\n│\n`;
    text += `├ nama    : ${groupName}\n`;
    text += `├ total   : ${memberCount} orang\n`;
    text += `├ admin   : ${adminCount} orang\n`;
    text += `├ member  : ${memberOnly} orang\n`;
    text += `├ bot     : ${isBotAdmin ? "admin" : "bukan admin"}\n`;
    text += `├ kamu    : ${isAdmin ? "admin" : "member"}\n`;
    text += `│\n╰─ _${botfullname}_`;
    return text;
  },

  ping: ({ speed, bar, status, ramUsed, ramTot }) =>
    `╭─「 ping 」\n│\n├ speed  : ${speed}ms ${bar} ${status}\n├ ram    : ${ramUsed}MB / ${ramTot}MB\n├ node   : ${process.version}\n├ uptime : ${Math.floor(process.uptime())}s\n│\n╰─ _${botfullname}_`,

  menuCmdNotFound : (cmd) => `command *${cmd}* nggak ada`,
  menuFooter      : `├ prefix : *${global.prefix ?? "!"}*\n├ detail : *${global.prefix ?? "!"}menu [nama cmd]*`,
};

global.msg.debug = {
  notGroup : "khusus di grup",
  metaFail : "gagal ambil metadata grup",
};

export default true;
