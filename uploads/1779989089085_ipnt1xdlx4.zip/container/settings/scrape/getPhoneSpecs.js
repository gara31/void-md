const axios = (await import('axios')).default
const cheerio = await import('cheerio')

async function getPhoneSpecs(query) {
  try {
    const searchUrl = `https://www.gsmarena.com/results.php3?sQuickSearch=yes&sName=${encodeURIComponent(query)}`
    
    const searchResponse = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
      }
    })
    
    const $ = cheerio.load(searchResponse.data)
    let firstResult = $('.makers ul li').first().find('a').attr('href')
    
    if (!firstResult) {
      firstResult = $('div.makers ul li').first().find('a').attr('href')
    }
    
    if (!firstResult) return null
    
    const phoneUrl = firstResult.startsWith('http') ? firstResult : `https://www.gsmarena.com/${firstResult}`
    
    const phoneResponse = await axios.get(phoneUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Referer': 'https://www.gsmarena.com/'
      }
    })
    
    const phoneData = cheerio.load(phoneResponse.data)
    
    const specs = {}
    
    specs.name = phoneData('h1.specs-phone-name-title').text().trim() || 
                phoneData('.specs-phone-name-title').text().trim() ||
                phoneData('h1').first().text().trim()
                
    specs.image = phoneData('.specs-photo-main img').attr('src') || 
                  phoneData('img.center').attr('src')
    
    if (specs.image && !specs.image.startsWith('http')) {
      specs.image = `https://www.gsmarena.com/${specs.image}`
    }
    
    phoneData('#specs-list table, .specs-brief table').each((i, table) => {
      const category = phoneData(table).find('th').first().text().trim().toLowerCase()
      
      phoneData(table).find('tr').each((j, row) => {
        const key = phoneData(row).find('.ttl, td:first-child').text().trim()
        const value = phoneData(row).find('.nfo, td:last-child').text().trim()
        
        if (key && value && key !== value) {
          const keyLower = key.toLowerCase()
          
          if (keyLower.includes('technology')) specs.technology = value
          if (keyLower.includes('2g') && keyLower.includes('band')) specs.bands2g = value  
          if (keyLower.includes('3g') && keyLower.includes('band')) specs.bands3g = value
          if (keyLower.includes('4g') && keyLower.includes('band')) specs.bands4g = value
          if (keyLower.includes('speed')) specs.speed = value
          if (keyLower.includes('announced')) specs.announced = value
          if (keyLower.includes('status')) specs.status = value
          if (keyLower.includes('dimensions')) specs.dimensions = value
          if (keyLower.includes('weight')) specs.weight = value
          if (keyLower.includes('build')) specs.build = value
          if (keyLower.includes('sim')) specs.sim = value
          if (keyLower.includes('type') && !specs.displayType) specs.displayType = value
          if (keyLower.includes('size') && keyLower.includes('inch')) specs.displaySize = value
          if (keyLower.includes('resolution')) specs.resolution = value
          if (keyLower.includes('protection')) specs.protection = value
          if (keyLower.includes('os')) specs.os = value
          if (keyLower.includes('chipset')) specs.chipset = value
          if (keyLower.includes('cpu')) specs.cpu = value
          if (keyLower.includes('gpu')) specs.gpu = value
          if (keyLower.includes('card slot')) specs.cardSlot = value
          if (keyLower.includes('internal') && !specs.internal) specs.internal = value
          
        
          if (keyLower.includes('triple') || keyLower.includes('quad') || keyLower.includes('dual')) {
            if (!specs.mainCamera) specs.mainCamera = value
          }
          if (keyLower.includes('primary') || (keyLower.includes('main') && keyLower.includes('camera'))) {
            if (!specs.mainCamera) specs.mainCamera = value
          }
          if (keyLower.includes('secondary') || keyLower.includes('selfie') || keyLower.includes('front')) {
            if (!specs.selfieCamera) specs.selfieCamera = value
          }
          if (keyLower.includes('single') && category.includes('selfie')) {
            specs.selfieCamera = value
          }
        }
      })
    })
    
   
    if (!specs.mainCamera || !specs.selfieCamera) {
      phoneData('table').each((i, table) => {
        const tableText = phoneData(table).text().toLowerCase()
        
        if (tableText.includes('main camera') || tableText.includes('primary camera')) {
          phoneData(table).find('tr').each((j, row) => {
            const cells = phoneData(row).find('td')
            if (cells.length >= 2) {
              const key = phoneData(cells[0]).text().trim().toLowerCase()
              const value = phoneData(cells[1]).text().trim()
              
              if ((key.includes('triple') || key.includes('quad') || key.includes('dual') || key.includes('primary')) && value) {
                if (!specs.mainCamera) specs.mainCamera = value
              }
            }
          })
        }
        
        if (tableText.includes('selfie camera') || tableText.includes('secondary camera')) {
          phoneData(table).find('tr').each((j, row) => {
            const cells = phoneData(row).find('td')
            if (cells.length >= 2) {
              const key = phoneData(cells[0]).text().trim().toLowerCase()
              const value = phoneData(cells[1]).text().trim()
              
              if ((key.includes('single') || key.includes('secondary') || key.includes('selfie')) && value) {
                if (!specs.selfieCamera) specs.selfieCamera = value
              }
            }
          })
        }
      })
    }
    
    return specs
  } catch (error) {
    console.error('Error fetching phone specs:', error.message)
    throw new Error(`Gagal mengambil data: ${error.message}`)
  }
}

export { getPhoneSpecs }