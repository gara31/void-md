async function anime(query) {
  const url = 'https://graphql.anilist.co'

  const gqlQuery = `
  query ($search: String) {
    Media(search: $search, type: ANIME) {
      id
      title {
        romaji
        english
        native
      }
      description(asHtml: false)
      episodes
      duration
      status
      season
      seasonYear
      genres
      averageScore
      popularity
      studios {
        nodes {
          name
        }
      }
      coverImage {
        extraLarge
        large
        medium
      }
      bannerImage
      siteUrl
    }
  }
  `

  const variables = { search: query }
  const { data } = await axios.post(url, { query: gqlQuery, variables }, {
    headers: { 'Content-Type': 'application/json' }
  })

  return data.data.Media
}

export { anime }