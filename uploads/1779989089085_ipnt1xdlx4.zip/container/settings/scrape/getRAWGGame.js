const axios = (await import('axios')).default
const translate = await import('@vitalets/google-translate-api')

async function getRAWGGame(query) {
  try {
    const apiKey = "6dc0ad5a17da4266979daba28d46bc14"
    
    console.log('Mencari game via RAWG:', query)
    
  
    const searchUrl = `https://api.rawg.io/api/games?key=${apiKey}&search=${encodeURIComponent(query)}&page_size=10`
    
    const searchResponse = await axios.get(searchUrl, { 
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })

    const searchData = searchResponse.data

    if (!searchData.results || searchData.results.length === 0) {
      console.log('Game tidak ditemukan di RAWG')
      return null
    }

   
    const searchLower = query.toLowerCase()
    
  
    const calculateSimilarity = (gameName, searchQuery) => {
      const gameNameLower = gameName.toLowerCase()
      const queryWords = searchQuery.toLowerCase().split(' ')
      let score = 0
      
    
      if (gameNameLower === searchQuery) return 100
      
    
      if (searchQuery.includes('god of war 2') || searchQuery.includes('god of war ii')) {
      
        if (gameNameLower.includes('god of war ii') || 
            gameNameLower.includes('god of war 2') ||
            gameNameLower.match(/god of war\s*2(?!\d)/)) {
          score += 80
        }
    
        if (gameNameLower.includes('2018') || gameNameLower.includes('(2018)')) {
          score -= 30
        }
      }
      
   
      if (gameNameLower.includes(searchQuery)) score += 50
      
    
      queryWords.forEach(word => {
        if (gameNameLower.includes(word)) score += 10
      })
      
   
      if (searchQuery.includes('2') && gameNameLower.includes('ii')) score += 20
      if (searchQuery.includes('3') && gameNameLower.includes('iii')) score += 20
      if (searchQuery.includes('4') && gameNameLower.includes('iv')) score += 20
      
  
      const gameWords = gameNameLower.split(' ')
      const extraWords = gameWords.length - queryWords.length
      if (extraWords > 2) score -= extraWords * 5
      
      return score
    }
    
  
    const scoredResults = searchData.results.map(game => ({
      ...game,
      score: calculateSimilarity(game.name, searchLower)
    }))
    
  
    scoredResults.sort((a, b) => b.score - a.score)
    
    const bestMatch = scoredResults[0]
    
  
    console.log("Search results scoring:")
    scoredResults.slice(0, 5).forEach(game => {
      console.log(`${game.name}: ${game.score}`)
    })
    
   
    if (bestMatch.score < 15) {
      console.log('Tidak ada match yang cukup baik')
      return null
    }

  
    const gameUrl = `https://api.rawg.io/api/games/${bestMatch.slug}?key=${apiKey}`
    
    const gameResponse = await axios.get(gameUrl, { 
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })

    const game = gameResponse.data

   
    const gameData = {
      title: game.name || "Tidak diketahui",
      about: game.description_raw || game.description || "Deskripsi tidak tersedia",
      platform: game.platforms?.map(p => p.platform?.name).filter(Boolean) || [],
      metascore: game.metacritic || "Belum ada skor",
      genre: game.genres?.map(g => g.name).filter(Boolean) || [],
      releaseDate: game.released || "Tanggal rilis tidak diketahui",
      developer: game.developers?.map(d => d.name).filter(Boolean) || [],
      publisher: game.publishers?.map(p => p.name).filter(Boolean) || [],
      ageRating: game.esrb_rating?.name || "Belum ada rating",
      tags: game.tags?.slice(0, 8).map(t => t.name).filter(Boolean) || [],
      image: game.background_image || ""
    }

  
    let translatedAbout = gameData.about
    if (translatedAbout && translatedAbout.length > 50 && translatedAbout !== "Deskripsi tidak tersedia") {
      try {
       
        const maxLength = 1000
        let shortDesc = translatedAbout
        
        if (translatedAbout.length > maxLength) {
      
          const sentences = translatedAbout.match(/[^\.!?]+[\.!?]+/g)
          if (sentences) {
            let currentLength = 0
            let cutIndex = 0
            
            for (let i = 0; i < sentences.length; i++) {
              currentLength += sentences[i].length
              if (currentLength > maxLength) break
              cutIndex = currentLength
            }
            
            if (cutIndex > 0) {
              shortDesc = translatedAbout.substring(0, cutIndex).trim()
            } else {
              shortDesc = translatedAbout.substring(0, maxLength) + "..."
            }
          } else {
            shortDesc = translatedAbout.substring(0, maxLength) + "..."
          }
        }
        
        const translated = await translate.translate(shortDesc, { to: "id" })
        translatedAbout = translated.text
        
      
        if (translatedAbout.length > 500) {
          const lastPeriod = translatedAbout.lastIndexOf('.')
          const lastExclamation = translatedAbout.lastIndexOf('!')
          const lastQuestion = translatedAbout.lastIndexOf('?')
          const lastSentenceEnd = Math.max(lastPeriod, lastExclamation, lastQuestion)
          
          if (lastSentenceEnd > 300) {
            translatedAbout = translatedAbout.substring(0, lastSentenceEnd + 1)
          }
        }
        
      } catch (translateError) {
        console.warn("Translation failed:", translateError.message)
     
        if (translatedAbout.length > 800) {
          const lastPeriod = translatedAbout.lastIndexOf('.', 800)
          if (lastPeriod > 300) {
            translatedAbout = translatedAbout.substring(0, lastPeriod + 1)
          } else {
            translatedAbout = translatedAbout.substring(0, 800) + "..."
          }
        }
      }
    }


    gameData.translatedAbout = translatedAbout

    console.log('failed:', {
      title: gameData.title,
      platform: gameData.platform.length,
      hasDescription: !!gameData.translatedAbout,
      hasImage: !!gameData.image
    })

    return gameData

  } catch (error) {
    console.error('failed:', error.message)
    throw new Error(`failed: ${error.message}`)
  }
}

export { getRAWGGame }