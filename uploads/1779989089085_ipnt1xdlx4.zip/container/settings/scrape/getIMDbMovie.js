const axios = (await import('axios')).default
const translate = await import('@vitalets/google-translate-api')
const cheerio = await import('cheerio')

async function getIMDbMovie(query) {
  try {
   
    if (query.includes('imdb.com/title/')) {
      console.log('Menggunakan URL IMDb langsung:', query)
     
      const movieUrl = query.replace('m.imdb.com', 'www.imdb.com')
      return await scrapeIMDbPage(movieUrl)
    }
    
 
    const omdbApiKey = 'http://www.omdbapi.com/?apikey=trilogy&t='
    const omdbUrl = `${omdbApiKey}${encodeURIComponent(query)}`
    
    console.log('Mencari film via OMDB:', omdbUrl)
    
    const omdbResponse = await axios.get(omdbUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    })
    
    const omdbData = omdbResponse.data
    
    if (omdbData.Response === 'False') {
      console.log('Film tidak ditemukan di OMDB, coba IMDb scraping...')
      
    
      const searchUrl = `https://www.imdb.com/find/?q=${encodeURIComponent(query)}&s=tt&ttype=ft&ref_=fn_ft`
      
      const searchResponse = await axios.get(searchUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept-Encoding': 'gzip, deflate',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1'
        }
      })
      
      const $ = cheerio.load(searchResponse.data)
      let firstResult = $('.ipc-metadata-list-summary-item__t').first().attr('href') ||
                       $('.find-section .find-title-result').first().find('h3 a').attr('href') ||
                       $('.findResult').first().find('.result_text a').attr('href') ||
                       $('.titleResult').first().find('a').attr('href')
      
      if (!firstResult) return null
      
      const movieUrl = firstResult.startsWith('http') ? firstResult : `https://www.imdb.com${firstResult}`
      return await scrapeIMDbPage(movieUrl)
    }
    
   
    const movie = {
      title: omdbData.Title,
      year: omdbData.Year,
      rating: omdbData.imdbRating && omdbData.imdbRating !== 'N/A' ? omdbData.imdbRating : null,
      ratingCount: omdbData.imdbVotes,
      duration: omdbData.Runtime,
      genre: omdbData.Genre ? omdbData.Genre.split(', ') : [],
      plot: omdbData.Plot,
      director: omdbData.Director ? omdbData.Director.split(', ') : [],
      cast: omdbData.Actors ? omdbData.Actors.split(', ').slice(0, 5) : [],
      poster: omdbData.Poster && omdbData.Poster !== 'N/A' ? omdbData.Poster : null,
      releaseDate: omdbData.Released,
      country: omdbData.Country,
      language: omdbData.Language,
      budget: omdbData.BoxOffice,
      boxOffice: omdbData.BoxOffice
    }
    
    return movie
  } catch (error) {
    console.error('Error fetching movie:', error.message)
    throw new Error(`Gagal mengambil data film: ${error.message}`)
  }
}

async function scrapeIMDbPage(movieUrl) {
  try {
    console.log('Scraping IMDb URL:', movieUrl)
    
    const movieResponse = await axios.get(movieUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://www.imdb.com/',
        'Cache-Control': 'no-cache'
      }
    })
    
    const $ = cheerio.load(movieResponse.data)
    const movie = {}
    
   
    movie.title = $('h1[data-testid="hero-title-block__title"]').text().trim() ||
                  $('h1.titleBar h1').text().trim() ||
                  $('h1.sc-afe43def-0').text().trim() ||
                  $('.title_wrapper h1').text().trim() ||
                  $('h1').first().text().trim()
    
  
    movie.year = $('.sc-afe43def-0 a').first().text().trim() ||
                 $('[data-testid="hero-title-block__metadata"] a').first().text().trim() ||
                 $('.titleBar .subtext a').first().text().trim() ||
                 $('span.titleYear a').text().trim().replace(/[()]/g, '')
    
   
    movie.rating = $('[data-testid="hero-rating-bar__aggregate-rating__score"] span').first().text().trim() ||
                   $('.ratingValue strong span').text().trim() ||
                   $('.sc-bde20123-1').text().trim()
    
    
    movie.ratingCount = $('[data-testid="hero-rating-bar__aggregate-rating__score"]').next().text().trim() ||
                        $('.imdbRating .small').text().trim() ||
                        $('.sc-bde20123-3').text().trim()
    
 
    movie.duration = $('[data-testid="title-techspec_runtime"] .ipc-metadata-list-item__content-container').text().trim() ||
                     $('.subtext time').text().trim() ||
                     $('time[datetime]').text().trim()
    
 
    movie.genre = []
    $('[data-testid="genres"] .ipc-chip').each((i, elem) => {
      const genre = $(elem).text().trim()
      if (genre) movie.genre.push(genre)
    })
    
    if (movie.genre.length === 0) {
      $('.subtext a[href*="/genre/"]').each((i, elem) => {
        const genre = $(elem).text().trim()
        if (genre) movie.genre.push(genre)
      })
    }
    
 
    movie.plot = $('[data-testid="plot"] .sc-466bb6c-0').text().trim() ||
                 $('[data-testid="storyline-plot-summary"]').text().trim() ||
                 $('.summary_text').text().trim() ||
                 $('.plot_summary .summary_text').text().trim() ||
                 $('p[data-testid="plot"]').text().trim()
    
   
    movie.director = []
    $('[data-testid="title-pc-principal-credit"]:contains("Director") a').each((i, elem) => {
      const director = $(elem).text().trim()
      if (director) movie.director.push(director)
    })
    
    if (movie.director.length === 0) {
      $('.credit_summary_item h4:contains("Director")').next('p').find('a').each((i, elem) => {
        const director = $(elem).text().trim()
        if (director && !director.includes('more')) movie.director.push(director)
      })
    }
    

    movie.cast = []
    $('[data-testid="title-cast"] [data-testid="title-cast-item"] a[data-testid="title-cast-item__actor"]').each((i, elem) => {
      if (i < 5) {
        const actor = $(elem).text().trim()
        if (actor) movie.cast.push(actor)
      }
    })
    
    if (movie.cast.length === 0) {
      $('.cast_list .primary_photo + td a').each((i, elem) => {
        if (i < 5) {
          const actor = $(elem).text().trim()
          if (actor) movie.cast.push(actor)
        }
      })
    }
    
  
    movie.poster = $('[data-testid="hero-media__poster"] img').attr('src') ||
                   $('.poster img').attr('src') ||
                   $('img[alt*="Poster"]').attr('src') ||
                   $('.titlePoster img').attr('src')
    
  
    if (movie.poster && movie.poster.includes('@')) {
      movie.poster = movie.poster.split('@')[0] + '@._V1_UX300_CR0,0,300,444_AL_.jpg'
    }
    
    
    movie.releaseDate = $('[data-testid="title-details-releasedate"] a').text().trim() ||
                        $('.subtext a[title*="Release Info"]').text().trim()
    
    movie.country = $('[data-testid="title-details-origin"] .ipc-metadata-list-item__list-content-item').first().text().trim() ||
                    $('a[href*="/country/"]').first().text().trim()
    
    movie.language = $('[data-testid="title-details-languages"] .ipc-metadata-list-item__list-content-item').first().text().trim() ||
                     $('a[href*="/language/"]').first().text().trim()
    
    console.log('Scraped movie data:', {
      title: movie.title,
      year: movie.year,
      rating: movie.rating,
      hasGenres: movie.genre.length > 0,
      hasPlot: !!movie.plot,
      hasPoster: !!movie.poster
    })
    
    return movie
  } catch (error) {
    console.error('Error scraping IMDb page:', error.message)
    return null
  }
}

export { getIMDbMovie }
